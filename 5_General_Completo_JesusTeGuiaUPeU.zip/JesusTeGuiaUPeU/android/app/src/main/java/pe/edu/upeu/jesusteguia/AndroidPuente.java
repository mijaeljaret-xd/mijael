/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : AndroidPuente.java                                           │
 * │ CAPA    : App Android                                                  │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   "Puente" entre la página web y el celular. Desde JavaScript se       │
 * │   llama así:                                                           │
 * │      AndroidApp.notificar("Reserva de asiento", "texto…")              │
 * │      AndroidApp.imprimir("<html>…</html>", "Boleta_B001-00000001")     │
 * │      AndroidApp.abrir("https://wa.me/51917651371?text=…")              │
 * │      AndroidApp.httpGet(url, token)  → JSON de RENIEC / SUNAT          │
 * │   Solo los métodos con @JavascriptInterface son visibles para la web.  │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.jesusteguia;

import android.webkit.JavascriptInterface;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AndroidPuente {

    private final MainActivity actividad;

    AndroidPuente(MainActivity actividad) {
        this.actividad = actividad;
    }

    /** Aviso de reserva de asiento en la barra de notificaciones del taxista. */
    @JavascriptInterface
    public void notificar(String titulo, String texto) {
        actividad.runOnUiThread(() -> actividad.mostrarNotificacion(titulo, texto));
    }

    /** Imprime la boleta o factura (impresora Wi-Fi/Bluetooth o PDF). */
    @JavascriptInterface
    public void imprimir(String html, String nombre) {
        actividad.runOnUiThread(() -> actividad.imprimirHtml(html, nombre));
    }

    /** Abre WhatsApp, SMS o un enlace externo con la app que corresponde. */
    @JavascriptInterface
    public void abrir(String url) {
        actividad.runOnUiThread(() -> actividad.abrirFuera(url));
    }

    /**
     * Consulta RENIEC (DNI) o SUNAT (RUC) desde el celular: así no hay bloqueo del navegador.
     * Devuelve el JSON de la respuesta o "" si no se encontró / no hay internet.
     */
    @JavascriptInterface
    public String httpGet(String url, String token) {
        if (url == null || !url.startsWith("https://api.decolecta.com/")) return "";   // solo esta API
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(url).openConnection();
            con.setConnectTimeout(8000);
            con.setReadTimeout(10000);
            con.setRequestProperty("Authorization", "Bearer " + token);
            con.setRequestProperty("Accept", "application/json");
            if (con.getResponseCode() != 200) return "";
            try (InputStream in = con.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } catch (Exception e) {
            return "";
        } finally {
            if (con != null) con.disconnect();
        }
    }

    /** Versión de la app (la página puede mostrarla). */
    @JavascriptInterface
    public String version() {
        return BuildConfigInfo.VERSION;
    }

    /** Pequeña constante para no depender de BuildConfig. */
    static final class BuildConfigInfo {
        static final String VERSION = "3.2";
    }
}
