/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MainActivity.java                                            │
 * │ CAPA    : App Android                                                  │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Pantalla única de la app. Abre la página «Jesús te guía a la UPeU»   │
 * │   (app/src/main/assets/www/index.html) dentro de un WebView y le da    │
 * │   tres poderes del celular a través de AndroidPuente:                  │
 * │     1. Notificaciones  → el taxista recibe la reserva de asiento.      │
 * │     2. Impresión       → boleta / factura a impresora o PDF.           │
 * │     3. WhatsApp / SMS  → reenviar la reserva al celular del taxista.   │
 * │   ► Para cambiar el diseño o los datos NO se toca este archivo: se     │
 * │     edita index.html (es la misma página del sitio web).               │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.jesusteguia;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    /** Página que se abre al iniciar (copia de web/syspasajes.html). */
    private static final String PAGINA = "file:///android_asset/www/index.html";
    private static final String CANAL = "reservas";
    private static final int COLOR_DORADO = 0xFFD4A017;

    private WebView web;
    private WebView webImpresion;      // se guarda para que no se borre mientras imprime
    private int idNotificacion = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        crearCanalDeAvisos();
        pedirPermisoDeAvisos();

        web = new WebView(this);
        setContentView(web);

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);           // la página está hecha en JavaScript
        ws.setDomStorageEnabled(true);           // guarda los datos en el celular (modo sin internet)
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);   // sonido del aviso

        // "AndroidApp" es el nombre con el que la página llama al celular (ver index.html: EN_APP)
        web.addJavascriptInterface(new AndroidPuente(this), "AndroidApp");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return abrirFuera(request.getUrl().toString());
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(PAGINA);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /** Enlaces de WhatsApp, SMS, teléfono o páginas externas se abren con su propia app. */
    boolean abrirFuera(String url) {
        if (url.startsWith("file:")) return false;                     // páginas propias: se quedan en la app
        try {
            Intent i;
            if (url.startsWith("sms:")) i = new Intent(Intent.ACTION_SENDTO, Uri.parse(url));
            else i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));    // wa.me abre WhatsApp directamente
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No hay una app para abrir este enlace", Toast.LENGTH_LONG).show();
        }
        return true;
    }

    // ───────────────────────── 1. NOTIFICACIONES ─────────────────────────
    private void crearCanalDeAvisos() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel canal = new NotificationChannel(CANAL, getString(R.string.canal_avisos),
                    NotificationManager.IMPORTANCE_HIGH);
            canal.setDescription(getString(R.string.canal_avisos_desc));
            canal.enableVibration(true);
            canal.setLightColor(COLOR_DORADO);
            getSystemService(NotificationManager.class).createNotificationChannel(canal);
        }
    }

    private void pedirPermisoDeAvisos() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    /** Muestra la notificación "Reserva de asiento" en la barra del celular. */
    void mostrarNotificacion(String titulo, String texto) {
        Intent abrir = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, abrir,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CANAL)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_notificacion)
                .setColor(COLOR_DORADO)
                .setContentTitle(titulo)
                .setContentText(texto)
                .setStyle(new Notification.BigTextStyle().bigText(texto))
                .setAutoCancel(true)
                .setContentIntent(pi);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) b.setDefaults(Notification.DEFAULT_ALL);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(idNotificacion++, b.build());
    }

    // ───────────────────────── 2. IMPRESIÓN ─────────────────────────
    /** Imprime la boleta/factura (HTML) con el servicio de impresión del celular (o "Guardar como PDF"). */
    void imprimirHtml(String html, String nombre) {
        webImpresion = new WebView(this);
        webImpresion.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adaptador = view.createPrintDocumentAdapter(nombre);
                pm.print(nombre, adaptador, new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
            }
        });
        webImpresion.loadDataWithBaseURL("file:///android_asset/www/", html, "text/html", "UTF-8", null);
    }
}
