/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : AppContext.java                                              │
 * │ CAPA    : Configuración                                                │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Inyección de dependencias manual: crea los repositorios, servicios   │
 * │   y controladores y los conecta entre sí.                              │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.config;

import pe.edu.upeu.syspasajes.controller.*;
import pe.edu.upeu.syspasajes.repository.*;
import pe.edu.upeu.syspasajes.service.*;
import pe.edu.upeu.syspasajes.service.impl.*;
import pe.edu.upeu.syspasajes.utils.ConsultaDNI;
import pe.edu.upeu.syspasajes.utils.ConsultaRUC;

import java.util.HashMap;
import java.util.Map;

/**
 * Contenedor de Inyección de Dependencias manual (igual que en el ejemplo SysVentas).
 * Arma las tres capas: Repositorios -> Servicios -> Controladores.
 */
public class AppContext {

    // Singleton: una sola instancia en toda la app
    private static AppContext instance;

    public static synchronized AppContext getInstance() {
        if (instance == null) instance = new AppContext();
        return instance;
    }

    // El "directorio": Clase -> Objeto
    private final Map<Class<?>, Object> contenedor = new HashMap<>();

    private AppContext() {
        // Abre la BD y ejecuta el script DDL antes de crear cualquier repositorio
        DatabaseConfig.getDataSource();
        registrarRepositorios();
        registrarServicios();
        registrarControladores();
    }

    // CAPA 1 — REPOSITORIOS (cada uno habla con una tabla)
    private void registrarRepositorios() {
        registrar(UsuarioRepository.class,       new UsuarioRepository());
        registrar(MarcaRepository.class,         new MarcaRepository());
        registrar(ProductoRepository.class,      new ProductoRepository());
        registrar(VehiculoRepository.class,      new VehiculoRepository());
        registrar(ViajeRepository.class,         new ViajeRepository());
        registrar(ClienteRepository.class,      new ClienteRepository());
        registrar(VentaCarritoRepository.class, new VentaCarritoRepository());
        registrar(VentaPasajeRepository.class,   new VentaPasajeRepository());
        registrar(BoletoRepository.class,        new BoletoRepository());
    }

    // CAPA 2 — SERVICIOS (reciben sus repositorios por constructor)
    private void registrarServicios() {
        registrar(IUsuarioService.class,  new UsuarioServiceImp(getBean(UsuarioRepository.class)));
        registrar(IMenuMenuItemDao.class, new MenuMenuItemDaoImp());
        registrar(ConsultaDNI.class,      new ConsultaDNI());
        registrar(ConsultaRUC.class,      new ConsultaRUC(getBean(ConsultaDNI.class)));   // RUC en SUNAT

        registrar(IMarcaService.class,    new MarcaServiceImp(getBean(MarcaRepository.class)));
        registrar(IProductoService.class, new ProductoServiceImp(getBean(ProductoRepository.class)));
        registrar(IVehiculoService.class, new VehiculoServiceImp(getBean(VehiculoRepository.class)));
        registrar(IViajeService.class,    new ViajeServiceImp(getBean(ViajeRepository.class)));
        registrar(IClienteService.class, new ClienteServiceImp(getBean(ClienteRepository.class)));
        registrar(IVentaCarritoService.class, new VentaCarritoServiceImp(
                getBean(VentaCarritoRepository.class), getBean(ViajeRepository.class)));
        registrar(IVentaPasajeService.class, new VentaPasajeServiceImp(
                getBean(VentaPasajeRepository.class),
                getBean(BoletoRepository.class),
                getBean(VentaCarritoRepository.class),
                getBean(ClienteRepository.class),
                getBean(UsuarioRepository.class)));
    }

    // CAPA 3 — CONTROLADORES JavaFX (el FXMLLoader los pide con setControllerFactory)
    // NOTA: son singletons. Cada vista guarda su estado en sus @FXML, así que al
    // volver a abrir una pestaña el FXMLLoader reinyecta los nodos nuevos.
    private void registrarControladores() {
        registrar(LoginController.class, new LoginController(getBean(IUsuarioService.class)));
        registrar(MainguiController.class, new MainguiController(
                getBean(IMenuMenuItemDao.class),
                getBean(IViajeService.class),
                getBean(IVentaPasajeService.class)));
        registrar(MarcaController.class, new MarcaController(getBean(IMarcaService.class), getBean(IVehiculoService.class)));
        registrar(ProductoController.class, new ProductoController(getBean(IProductoService.class)));
        registrar(VehiculoController.class, new VehiculoController(
                getBean(IVehiculoService.class),
                getBean(IMarcaService.class)));
        registrar(ViajeController.class, new ViajeController(
                getBean(IViajeService.class),
                getBean(IVehiculoService.class),
                getBean(IProductoService.class)));
        registrar(ClienteController.class, new ClienteController(
                getBean(IClienteService.class),
                getBean(ConsultaDNI.class)));
        registrar(VentaCarritoController.class, new VentaCarritoController(getBean(IVentaCarritoService.class)));
        registrar(VentaPasajeController.class, new VentaPasajeController(
                getBean(IClienteService.class),
                getBean(IViajeService.class),
                getBean(IVentaCarritoService.class),
                getBean(IUsuarioService.class),
                getBean(IVentaPasajeService.class),
                getBean(ConsultaDNI.class),
                getBean(ConsultaRUC.class)));
        // Panel del cliente: el propio cliente compra su pasaje (usa los mismos servicios)
        registrar(PanelClienteController.class, new PanelClienteController(
                getBean(IClienteService.class),
                getBean(IViajeService.class),
                getBean(IVentaCarritoService.class),
                getBean(IUsuarioService.class),
                getBean(IVentaPasajeService.class),
                getBean(ConsultaDNI.class),
                getBean(ConsultaRUC.class)));
        registrar(HistorialController.class, new HistorialController(getBean(IVentaPasajeService.class)));
    }

    /** Guarda un objeto en el directorio, indexado por su tipo o interfaz. */
    private void registrar(Class<?> tipo, Object bean) {
        contenedor.put(tipo, bean);
    }

    /** Busca y devuelve un objeto por su tipo o interfaz. */
    @SuppressWarnings("unchecked")
    public <T> T getBean(Class<T> tipo) {
        Object bean = contenedor.get(tipo);
        if (bean == null) {
            bean = contenedor.values().stream()
                    .filter(b -> tipo.isAssignableFrom(b.getClass()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException(
                            "Bean no encontrado: " + tipo.getName() +
                                    "\n-> ¿Lo registraste en AppContext?"));
        }
        return (T) bean;
    }
}
