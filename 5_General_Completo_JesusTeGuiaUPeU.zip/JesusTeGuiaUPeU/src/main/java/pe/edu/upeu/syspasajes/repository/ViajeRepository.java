/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ViajeRepository.java                                         │
 * │ CAPA    : Repositorio (base de datos)                                  │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   SQL de salidas: por fecha, disponibles, y asientos ocupados.         │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.enums.EstadoViaje;
import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Vehiculo;
import pe.edu.upeu.syspasajes.model.Viaje;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

public class ViajeRepository extends AbstractJpaRepository<Viaje, Long> {

    @Override protected String getTableName() { return "viaje"; }
    @Override protected String getPkColumn()  { return "id_viaje"; }

    /**
     * Columnas del viaje (alias vi) + su vehículo (alias ve).
     * Se reutilizan en los JOIN del carrito y del boleto, por eso los campos
     * que se repiten (precio, estado) llevan alias.
     */
    public static final String VIAJE_COLS =
            "vi.id_viaje, vi.sentido, vi.fecha, vi.hora_salida, vi.precio AS vi_precio, vi.estado AS vi_estado, " +
            VehiculoRepository.VEHICULO_COLS;

    /** JOIN del viaje con su vehículo y la marca del vehículo (se usa en viaje, carrito y boleto). */
    public static final String JOIN_VEHICULO =
            "JOIN vehiculo ve ON vi.id_vehiculo = ve.id_vehiculo " +
            "LEFT JOIN marca ma ON ve.id_marca = ma.id_marca ";

    private static final String SELECT_JOIN =
            "SELECT " + VIAJE_COLS + ", " +
            "(SELECT COUNT(*) FROM boleto b WHERE b.id_viaje = vi.id_viaje) + " +
            "(SELECT COUNT(*) FROM venta_carrito c WHERE c.id_viaje = vi.id_viaje) AS ocupados " +
            "FROM viaje vi " + JOIN_VEHICULO;

    /** Arma un Viaje (con su Vehiculo) a partir de las columnas de VIAJE_COLS. */
    public static Viaje mapViaje(ResultSet rs, boolean conOcupados) throws SQLException {
        Vehiculo ve = VehiculoRepository.mapVehiculo(rs);
        return Viaje.builder()
                .idViaje(rs.getLong("id_viaje"))
                .vehiculo(ve)
                .sentido(Sentido.valueOf(rs.getString("sentido")))
                .fecha(rs.getObject("fecha", LocalDate.class))
                .horaSalida(rs.getObject("hora_salida", LocalTime.class))
                .precio(rs.getDouble("vi_precio"))
                .estado(EstadoViaje.valueOf(rs.getString("vi_estado")))
                .asientosOcupados(conOcupados ? rs.getInt("ocupados") : null)
                .build();
    }

    @Override
    protected Viaje mapRow(ResultSet rs) throws SQLException {
        return mapViaje(rs, true);
    }

    @Override
    public List<Viaje> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY vi.fecha DESC, vi.hora_salida, vi.sentido");
    }

    @Override
    public Optional<Viaje> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE vi.id_viaje = ?", id);
    }

    public List<Viaje> listarPorFecha(LocalDate fecha) {
        return executeQuery(SELECT_JOIN + "WHERE vi.fecha = ? ORDER BY vi.hora_salida, vi.sentido", fecha);
    }

    /** Salidas programadas de una fecha y sentido; tipo null = taxis y combis. */
    public List<Viaje> listarDisponibles(LocalDate fecha, Sentido sentido, TipoVehiculo tipo) {
        String sql = SELECT_JOIN + "WHERE vi.fecha = ? AND vi.sentido = ? AND vi.estado = 'PROGRAMADO' ";
        if (tipo == null) {
            return executeQuery(sql + "ORDER BY vi.hora_salida, ve.tipo_vehiculo DESC", fecha, sentido.name());
        }
        return executeQuery(sql + "AND ve.tipo_vehiculo = ? ORDER BY vi.hora_salida",
                fecha, sentido.name(), tipo.name());
    }

    /** Números de asiento vendidos (boleto) o reservados (carrito) de un viaje. */
    public Set<Integer> asientosOcupados(Long idViaje) {
        Set<Integer> ocupados = new TreeSet<>();
        String sql = "SELECT nro_asiento FROM boleto WHERE id_viaje = ? " +
                     "UNION SELECT nro_asiento FROM venta_carrito WHERE id_viaje = ?";
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idViaje);
            ps.setLong(2, idViaje);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ocupados.add(rs.getInt(1));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error consultando asientos ocupados", e);
        }
        return ocupados;
    }

    /** Cantidad de boletos vendidos de un viaje (para validar cambios de vehículo). */
    public int contarBoletos(Long idViaje) {
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM boleto WHERE id_viaje = ?")) {
            ps.setLong(1, idViaje);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error contando boletos", e);
        }
    }

    @Override
    protected Viaje insert(Connection conn, Viaje e) throws SQLException {
        long id = executeInsertGetKey(conn,
                // id_producto = la TARIFA (producto) que corresponde al tipo de vehículo y al sentido
                "INSERT INTO viaje(id_vehiculo,sentido,fecha,hora_salida,precio,estado,id_producto) VALUES(?,?,?,?,?,?," +
                "(SELECT p.id_producto FROM producto p JOIN vehiculo v ON v.tipo_vehiculo = p.tipo_vehiculo " +
                " WHERE v.id_vehiculo = ? AND p.sentido = ? AND p.estado = 'ACTIVO' FETCH FIRST 1 ROWS ONLY))",
                e.getVehiculo().getIdVehiculo(), e.getSentido().name(), e.getFecha(),
                e.getHoraSalida(), e.getPrecio(), e.getEstado().name(),
                e.getVehiculo().getIdVehiculo(), e.getSentido().name());
        e.setIdViaje(id);
        return e;
    }

    @Override
    protected Viaje updateRow(Connection conn, Viaje e) throws SQLException {
        executeUpdate(conn,
                "UPDATE viaje SET id_vehiculo=?,sentido=?,fecha=?,hora_salida=?,precio=?,estado=? WHERE id_viaje=?",
                e.getVehiculo().getIdVehiculo(), e.getSentido().name(), e.getFecha(),
                e.getHoraSalida(), e.getPrecio(), e.getEstado().name(), e.getIdViaje());
        return e;
    }
}
