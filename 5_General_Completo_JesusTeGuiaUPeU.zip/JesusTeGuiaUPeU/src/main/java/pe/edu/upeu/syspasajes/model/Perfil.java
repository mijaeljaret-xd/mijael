/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Perfil.java                                                  │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Perfil de usuario: Root, Administrador, Reporte o Taxista.           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Builder
@Getter
@Setter
public class Perfil {
    Long idPerfil;
    String nombre;
    String codigo;
    List<Acceso> accesos; //Agregacion
}
