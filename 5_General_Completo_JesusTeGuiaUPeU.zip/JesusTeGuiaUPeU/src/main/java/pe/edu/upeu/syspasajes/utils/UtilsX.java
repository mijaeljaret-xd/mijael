/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : UtilsX.java                                                  │
 * │ CAPA    : Utilidad                                                     │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Carga los textos del idioma elegido (español, inglés o francés).     │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public class UtilsX {

    public URL getFile(String ruta) {
        return this.getClass().getResource("/" + ruta);
    }

    public File getFileExterno(String carpeta, String filex) {
        File newFolder = new File(carpeta);
        String ruta = newFolder.getAbsolutePath();
        Path camino = Paths.get(ruta + "/" + filex);
        return camino.toFile();
    }

    public File getFolderExterno(String carpeta) {
        File newFolder = new File(carpeta);
        String ruta = newFolder.getAbsolutePath();
        Path camino = Paths.get(ruta + "/");
        return camino.toFile();
    }

    /**
     * Carga el archivo de idioma. Primero busca en la carpeta externa ./language
     * (como el ejemplo) y si no existe usa la copia incluida en resources/language.
     * Se lee en UTF-8 para que las tildes se vean bien.
     */
    public Properties detectLanguage(String idioma) {
        Properties props = new Properties();
        String archivo = "idiomas-" + idioma + ".properties";
        File externo = getFileExterno("language", archivo);
        try (InputStream in = externo.exists()
                ? new FileInputStream(externo)
                : getClass().getResourceAsStream("/language/" + archivo)) {
            if (in != null) {
                try (Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
                    props.load(r);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return props;
    }
}
