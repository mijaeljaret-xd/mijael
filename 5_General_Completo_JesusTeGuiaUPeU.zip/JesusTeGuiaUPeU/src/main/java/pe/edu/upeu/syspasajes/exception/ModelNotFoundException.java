/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ModelNotFoundException.java                                  │
 * │ CAPA    : Excepción                                                    │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Error que se lanza cuando se busca un registro que no existe.        │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.exception;

public class ModelNotFoundException extends RuntimeException {
    public ModelNotFoundException(String message) {
        super(message);
    }
}
