/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ProductoRepository.java                                      │
 * │ CAPA    : Repositorio (base de datos)                                  │
 * │ MÓDULO  : PRODUCTO                                                     │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   SQL de la tabla producto: tarifa por tipo y sentido, y cambio de     │
 * │   precio en salidas futuras.                                           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Producto;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/** MÓDULO PRODUCTO - acceso a la tabla producto (tarifas de pasaje). */
public class ProductoRepository extends AbstractJpaRepository<Producto, Long> {

    @Override protected String getTableName() { return "producto"; }
    @Override protected String getPkColumn()  { return "id_producto"; }

    @Override
    public List<Producto> findAll() {
        return executeQuery("SELECT * FROM producto ORDER BY tipo_vehiculo DESC, sentido, nombre");
    }

    public List<Producto> listarActivos() {
        return executeQuery("SELECT * FROM producto WHERE estado = 'ACTIVO' ORDER BY tipo_vehiculo DESC, sentido, nombre");
    }

    /** Tarifa activa para un tipo de vehículo y sentido. */
    public Optional<Producto> buscarTarifa(TipoVehiculo tipo, Sentido sentido) {
        return executeQueryOne("SELECT * FROM producto WHERE estado = 'ACTIVO' AND tipo_vehiculo = ? AND sentido = ? " +
                "ORDER BY id_producto", tipo.name(), sentido.name());
    }

    /**
     * Cambia el precio de las salidas que aún no ocurren (desde hoy) de ese tipo y sentido.
     * Los boletos ya vendidos conservan su precio (cada boleto guarda el suyo).
     */
    public int aplicarPrecioASalidasFuturas(TipoVehiculo tipo, Sentido sentido, double precio) {
        return executeUpdateStandalone(
                "UPDATE viaje SET precio = ? WHERE sentido = ? AND fecha >= ? AND estado = 'PROGRAMADO' " +
                "AND id_vehiculo IN (SELECT id_vehiculo FROM vehiculo WHERE tipo_vehiculo = ?)",
                precio, sentido.name(), LocalDate.now(), tipo.name());
    }

    @Override
    protected Producto mapRow(ResultSet rs) throws SQLException {
        return Producto.builder()
                .idProducto(rs.getLong("id_producto"))
                .nombre(rs.getString("nombre"))
                .tipoVehiculo(TipoVehiculo.valueOf(rs.getString("tipo_vehiculo")))
                .sentido(Sentido.valueOf(rs.getString("sentido")))
                .precio(rs.getDouble("precio"))
                .descripcion(rs.getString("descripcion"))
                .estado(rs.getString("estado"))
                .build();
    }

    @Override
    protected Producto insert(Connection conn, Producto e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO producto(nombre,tipo_vehiculo,sentido,precio,descripcion,estado) VALUES(?,?,?,?,?,?)",
                e.getNombre(), e.getTipoVehiculo().name(), e.getSentido().name(), e.getPrecio(),
                e.getDescripcion(), e.getEstado());
        e.setIdProducto(id);
        return e;
    }

    @Override
    protected Producto updateRow(Connection conn, Producto e) throws SQLException {
        executeUpdate(conn,
                "UPDATE producto SET nombre=?,tipo_vehiculo=?,sentido=?,precio=?,descripcion=?,estado=? WHERE id_producto=?",
                e.getNombre(), e.getTipoVehiculo().name(), e.getSentido().name(), e.getPrecio(),
                e.getDescripcion(), e.getEstado(), e.getIdProducto());
        return e;
    }

    /** Cuántas salidas (viajes) usan esta tarifa: no se elimina si tiene salidas. */
    public int contarViajes(Long idProducto) {
        try (Connection conn = openConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM viaje WHERE id_producto = ?")) {
            ps.setLong(1, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error contando salidas del producto", e);
        }
    }
}
