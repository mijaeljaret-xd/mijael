/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : AvisoTaxista.java                                            │
 * │ CAPA    : Utilidades                                                   │
 * │ MÓDULO  : VENTA CARRITO (aviso de reserva)                             │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Cada vez que se vende un pasaje arma el MENSAJE DE RESERVA DE        │
 * │   ASIENTO para el taxista del vehículo, lo guarda en la tabla          │
 * │   NOTIFICACION y permite enviárselo por WhatsApp a su celular.         │
 * │   ► Para cambiar el texto del mensaje edite el método mensaje().       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.edu.upeu.syspasajes.config.DatabaseConfig;
import pe.edu.upeu.syspasajes.model.Boleto;
import pe.edu.upeu.syspasajes.model.Vehiculo;
import pe.edu.upeu.syspasajes.model.VentaPasaje;
import pe.edu.upeu.syspasajes.model.Viaje;

import java.awt.Desktop;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class AvisoTaxista {

    private static final Logger LOG = LoggerFactory.getLogger(AvisoTaxista.class);

    /** Un aviso = un taxista + su celular + el texto que le llega. */
    public record Aviso(String placa, String conductor, String telefono, String mensaje) {
        /** Enlace de WhatsApp con el mensaje ya escrito (código de Perú 51). */
        public String linkWhatsApp() {
            String num = telefono == null ? "" : telefono.replaceAll("\\D", "");
            if (num.length() > 9) num = num.substring(num.length() - 9);
            return "https://wa.me/51" + num + "?text=" + URLEncoder.encode(mensaje, StandardCharsets.UTF_8).replace("+", "%20");
        }
    }

    private AvisoTaxista() {
    }

    /** Agrupa los boletos de la venta por vehículo y arma un aviso para cada taxista. */
    public static List<Aviso> avisosDe(VentaPasaje v) {
        Map<String, List<Boleto>> porPlaca = new LinkedHashMap<>();
        if (v.getBoletos() != null) {
            for (Boleto b : v.getBoletos()) {
                if (b.getViaje() == null) continue;
                porPlaca.computeIfAbsent(b.getViaje().getPlaca(), k -> new ArrayList<>()).add(b);
            }
        }
        List<Aviso> avisos = new ArrayList<>();
        porPlaca.forEach((placa, boletos) -> {
            Vehiculo ve = boletos.get(0).getViaje().getVehiculo();
            String conductor = ve == null ? "" : ve.getConductor();
            String telefono = ve == null ? null : ve.getTelefonoConductor();
            avisos.add(new Aviso(placa, conductor, telefono, mensaje(v, boletos)));
        });
        return avisos;
    }

    /** Texto de la reserva que recibe el taxista. */
    public static String mensaje(VentaPasaje v, List<Boleto> boletos) {
        StringBuilder sb = new StringBuilder();
        sb.append("🚖 RESERVA DE ASIENTO · Jesús te guía a la UPeU\n");
        sb.append("Pasajero: ").append(v.getCliente().getNombres()).append(" (DNI ").append(v.getCliente().getDni()).append(")\n");
        String cel = v.getCliente().getTelefono();
        if (cel != null && !cel.isBlank()) sb.append("Celular del pasajero: ").append(cel).append("\n");
        double total = 0;
        for (Boleto b : boletos) {
            Viaje vi = b.getViaje();
            sb.append("• Asiento ").append(b.getNroAsiento()).append(" · ").append(vi.getFechaTexto()).append(" ")
              .append(vi.getHoraTexto()).append(" · ").append(vi.getRutaTexto()).append("\n");
            total += b.getPrecio() == null ? 0 : b.getPrecio();
        }
        sb.append("Vehículo: ").append(boletos.get(0).getViaje().getPlaca()).append(" · ")
          .append(boletos.get(0).getViaje().getTipoTexto()).append("\n");
        sb.append(v.esFactura() ? "Factura " : "Boleta ").append(v.getSerie()).append("-").append(v.getNumDoc())
          .append(String.format(" · S/ %.2f", total)).append("\n");
        if (v.esFactura()) sb.append("RUC: ").append(v.getRuc()).append(" · ").append(v.getRazonSocial()).append("\n");
        // ---- Datos del PAGO ----
        String metodo = v.getMetodoPago() == null ? "Efectivo" : v.getMetodoPago().getDescripcion();
        sb.append("💳 PAGO: ").append(metodo);
        if (v.getNroOperacion() != null && !v.getNroOperacion().isBlank()) sb.append(" · N° operación ").append(v.getNroOperacion());
        sb.append(String.format(" · Total de la venta S/ %.2f", v.getPrecioTotal()));
        return sb.toString();
    }

    /** Guarda los avisos en la tabla NOTIFICACION (historial de reservas para cada taxista). */
    public static void registrar(VentaPasaje v) {
        // id_venta = la venta que generó el aviso · id_vehiculo = el vehículo del taxista (por su placa)
        String sql = "INSERT INTO notificacion(placa,conductor,telefono,mensaje,comprobante,fecha_reg,leido,id_venta,id_vehiculo) "
                + "VALUES(?,?,?,?,?,?,FALSE,?,(SELECT id_vehiculo FROM vehiculo WHERE placa = ?))";
        try (Connection cn = DatabaseConfig.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
            for (Aviso a : avisosDe(v)) {
                ps.setString(1, a.placa());
                ps.setString(2, a.conductor());
                ps.setString(3, a.telefono());
                ps.setString(4, a.mensaje().length() > 1000 ? a.mensaje().substring(0, 1000) : a.mensaje());
                ps.setString(5, v.getSerie() + "-" + v.getNumDoc());
                ps.setTimestamp(6, Timestamp.valueOf(LocalDateTime.now().withNano(0)));
                ps.setObject(7, v.getId());
                ps.setString(8, a.placa());
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (Exception e) {
            // El aviso nunca debe impedir la venta
            LOG.warn("No se pudo guardar el aviso al taxista: {}", e.getMessage());
        }
    }

    /**
     * ENVÍO AUTOMÁTICO: después de cada venta se abre WhatsApp con la reserva y el pago
     * para el celular de cada taxista/dueño del vehículo (solo falta pulsar "Enviar").
     * ► Para desactivarlo ponga ENVIO_AUTOMATICO = false.
     */
    public static final boolean ENVIO_AUTOMATICO = true;

    public static void enviarAutomatico(VentaPasaje v) {
        if (!ENVIO_AUTOMATICO) return;
        for (Aviso a : avisosDe(v)) {
            if (a.telefono() != null && !a.telefono().isBlank()) abrirWhatsApp(a);
        }
    }

    /** Abre WhatsApp (app de escritorio o WhatsApp Web) con el mensaje listo para enviar. */
    public static boolean abrirWhatsApp(Aviso a) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(new URI(a.linkWhatsApp()));
                return true;
            }
        } catch (Exception e) {
            LOG.warn("No se pudo abrir WhatsApp: {}", e.getMessage());
        }
        return false;
    }
}
