/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : DatosIniciales.java                                          │
 * │ CAPA    : Configuración                                                │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Carga los datos iniciales: 4 marcas, 4 productos y 4 vehículos       │
 * │   (2 autos de 5 asientos y 2 vans de 11) con sus taxistas, y programa  │
 * │   las salidas de hoy y mañana.                                         │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.edu.upeu.syspasajes.enums.EstadoViaje;
import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Marca;
import pe.edu.upeu.syspasajes.model.Producto;
import pe.edu.upeu.syspasajes.model.Vehiculo;
import pe.edu.upeu.syspasajes.model.Viaje;
import pe.edu.upeu.syspasajes.service.IMarcaService;
import pe.edu.upeu.syspasajes.service.IProductoService;
import pe.edu.upeu.syspasajes.service.IVehiculoService;
import pe.edu.upeu.syspasajes.service.IVentaCarritoService;
import pe.edu.upeu.syspasajes.service.IViajeService;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * Datos de ejemplo para que el sistema se pueda probar apenas se instala:
 *  - 4 marcas, 4 productos (tarifas) y 4 vehículos: 2 autos de 5 asientos y 2 vans de 11 asientos.
 *  - Programación de salidas para HOY y MAÑANA (si ese día aún no tiene salidas).
 * Todo se puede modificar después desde los menús Catálogo y Flota.
 * Se hace desde Java (con los repositorios) para que los ID autogenerados no choquen.
 */
public final class DatosIniciales {

    private static final Logger LOG = LoggerFactory.getLogger(DatosIniciales.class);

    /** Horario base de salidas (aplica en ambos sentidos). */
    private static final String[] HORAS_TAXI  = {"07:00", "09:00", "11:00", "13:00", "15:00", "17:00", "19:00", "21:00"};
    private static final String[] HORAS_COMBI = {"06:30", "08:00", "10:00", "12:30", "14:00", "16:30", "18:00", "20:00"};

    private DatosIniciales() {
    }

    public static void cargar(AppContext ctx) {
        try {
            IMarcaService ms = ctx.getBean(IMarcaService.class);
            IProductoService ps = ctx.getBean(IProductoService.class);
            IVehiculoService vs = ctx.getBean(IVehiculoService.class);
            IViajeService vjs = ctx.getBean(IViajeService.class);

            // ---- MARCAS ----
            if (ms.findAll().isEmpty()) {
                ms.save(marca("Toyota"));
                ms.save(marca("Hyundai"));
                ms.save(marca("Kia"));
                ms.save(marca("Nissan"));
                LOG.info("Marcas de ejemplo registradas");
            }

            // ---- PRODUCTOS (tarifas del pasaje) ----
            if (ps.findAll().isEmpty()) {
                ps.save(producto("Pasaje Auto UPeU → Plaza", TipoVehiculo.TAXI, Sentido.UPEU_PLAZA, 3.00));
                ps.save(producto("Pasaje Auto Plaza → UPeU", TipoVehiculo.TAXI, Sentido.PLAZA_UPEU, 3.00));
                ps.save(producto("Pasaje Van UPeU → Plaza", TipoVehiculo.COMBI, Sentido.UPEU_PLAZA, 1.50));
                ps.save(producto("Pasaje Van Plaza → UPeU", TipoVehiculo.COMBI, Sentido.PLAZA_UPEU, 1.50));
                LOG.info("Productos de ejemplo registrados");
            }

            // ---- 4 VEHÍCULOS = 4 TAXISTAS ----
            // Para cambiar un taxista edite su nombre y celular aquí (o desde el menú Flota → Vehículos y conductores).
            // Ronaldo Pablo Sucasaca Mamani maneja la VAN-404 y además es el ADMINISTRADOR del sistema.
            if (vs.findAll().isEmpty()) {
                //                 placa      tipo (5 u 11 asientos)  marca      modelo    taxista                            celular      color
                vs.save(vehiculo(ms, "TAX-101", TipoVehiculo.TAXI,  "Toyota",  "Yaris",  "Mijael Jaret Quispe Vargas",     "917651371", "Azul"));
                vs.save(vehiculo(ms, "TAX-202", TipoVehiculo.TAXI,  "Hyundai", "Accent", "Álvaro Layme Urviola",           "940997634", "Blanco"));
                vs.save(vehiculo(ms, "VAN-303", TipoVehiculo.COMBI, "Toyota",  "Hiace",  "Heans Gary Livisi Huaynasi",     "992754434", "Amarillo taxi"));
                vs.save(vehiculo(ms, "VAN-404", TipoVehiculo.COMBI, "Nissan",  "Urvan",  "Ronaldo Pablo Sucasaca Mamani",  "940375781", "Azul marino"));
                LOG.info("4 vehículos registrados (2 autos de 5 asientos y 2 vans de 11 asientos)");
            }

            List<Vehiculo> taxis = vs.listarActivos().stream()
                    .filter(v -> v.getTipoVehiculo() == TipoVehiculo.TAXI).toList();
            List<Vehiculo> combis = vs.listarActivos().stream()
                    .filter(v -> v.getTipoVehiculo() == TipoVehiculo.COMBI).toList();

            for (LocalDate dia : List.of(LocalDate.now(), LocalDate.now().plusDays(1))) {
                if (!vjs.listarPorFecha(dia).isEmpty()) continue;
                programarDia(vjs, ps, dia, taxis, HORAS_TAXI);
                programarDia(vjs, ps, dia, combis, HORAS_COMBI);
                LOG.info("Salidas programadas para {}", dia);
            }

            // Limpia reservas de carrito abandonadas
            ctx.getBean(IVentaCarritoService.class).liberarReservasVencidas();
        } catch (Exception e) {
            // Los datos de ejemplo no deben impedir que el sistema arranque
            LOG.error("No se pudieron cargar los datos iniciales", e);
        }
    }

    /** Reparte los vehículos entre los horarios: cada salida alterna el sentido. */
    private static void programarDia(IViajeService vjs, IProductoService ps, LocalDate dia,
                                     List<Vehiculo> flota, String[] horas) {
        if (flota.isEmpty()) return;
        for (int i = 0; i < horas.length; i++) {
            LocalTime hora = LocalTime.parse(horas[i]);
            for (Sentido sentido : Sentido.values()) {
                // Vehículo distinto por sentido para que no "esté en dos lugares a la vez"
                Vehiculo v = flota.get((i + sentido.ordinal()) % flota.size());
                vjs.save(Viaje.builder()
                        .vehiculo(v)
                        .sentido(sentido)
                        .fecha(dia)
                        .horaSalida(hora)
                        .precio(ps.precioPara(v.getTipoVehiculo(), sentido))
                        .estado(EstadoViaje.PROGRAMADO)
                        .build());
            }
        }
    }

    private static Marca marca(String nombre) {
        return Marca.builder().nombre(nombre).estado("ACTIVO").build();
    }

    private static Producto producto(String nombre, TipoVehiculo tipo, Sentido sentido, double precio) {
        return Producto.builder()
                .nombre(nombre)
                .tipoVehiculo(tipo)
                .sentido(sentido)
                .precio(precio)
                .descripcion("Ruta " + sentido.getDescripcion() + " en " + tipo.getDescripcion().toLowerCase())
                .estado("ACTIVO")
                .build();
    }

    private static Vehiculo vehiculo(IMarcaService ms, String placa, TipoVehiculo tipo, String marca, String modelo,
                                     String conductor, String telefono, String color) {
        Marca m = ms.buscarPorNombre(marca).orElseGet(() -> ms.save(marca(marca)));
        return Vehiculo.builder()
                .placa(placa)
                .tipoVehiculo(tipo)
                .marca(m)
                .modelo(modelo)
                .conductor(conductor)
                .telefonoConductor(telefono)
                .color(color)
                .asientos(tipo.getAsientos())
                .estado("ACTIVO")
                .build();
    }
}
