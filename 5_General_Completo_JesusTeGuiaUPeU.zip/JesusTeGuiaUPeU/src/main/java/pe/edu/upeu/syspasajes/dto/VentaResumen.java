/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VentaResumen.java                                            │
 * │ CAPA    : DTO                                                          │
 * │ MÓDULO  : Venta                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Fila del historial: comprobante, tipo, forma de pago, cliente,       │
 * │   cantidad de pasajes y total.                                         │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Fila del historial de ventas (consulta con JOIN, no es una tabla). */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VentaResumen {
    private Long idVenta;
    private String comprobante;
    private String tipoComprobante;
    private String metodoPago;
    private LocalDateTime fechaVenta;
    private String dni;
    private String cliente;
    private String vendedor;
    private Integer cantidadPasajes;
    private Double descuento;
    private Double total;

    public String getFechaTexto() {
        return fechaVenta == null ? "" : fechaVenta.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }

    public String getTotalTexto() {
        return String.format("S/ %.2f", total == null ? 0.0 : total);
    }
}
