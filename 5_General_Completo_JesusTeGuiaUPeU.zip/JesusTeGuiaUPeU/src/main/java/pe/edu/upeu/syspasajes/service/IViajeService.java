/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IViajeService.java                                           │
 * │ CAPA    : Servicio (interfaz)                                          │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Salidas por fecha, disponibles y asientos ocupados.                  │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Viaje;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface IViajeService extends ICrudGenericoService<Viaje, Long> {
    List<Viaje> listarPorFecha(LocalDate fecha);
    List<Viaje> listarDisponibles(LocalDate fecha, Sentido sentido, TipoVehiculo tipo);
    Set<Integer> asientosOcupados(Long idViaje);
    int contarBoletos(Long idViaje);
}
