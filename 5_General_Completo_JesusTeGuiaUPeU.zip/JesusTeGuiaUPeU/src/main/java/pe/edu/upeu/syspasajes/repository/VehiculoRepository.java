/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VehiculoRepository.java                                      │
 * │ CAPA    : Repositorio (base de datos)                                  │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   SQL de la tabla vehiculo unida a su marca.                           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Marca;
import pe.edu.upeu.syspasajes.model.Vehiculo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class VehiculoRepository extends AbstractJpaRepository<Vehiculo, Long> {

    @Override protected String getTableName() { return "vehiculo"; }
    @Override protected String getPkColumn()  { return "id_vehiculo"; }

    /** Columnas del vehículo (alias ve) + su marca (alias ma). Se reutilizan en los JOIN de viaje. */
    public static final String VEHICULO_COLS =
            "ve.id_vehiculo, ve.placa, ve.tipo_vehiculo, ve.id_marca, ve.modelo, ve.conductor, " +
            "ve.telefono_conductor, ve.color, ve.asientos, ve.estado AS ve_estado, " +
            "ma.nombre AS marca_nombre, ma.estado AS marca_estado ";

    private static final String SELECT_JOIN =
            "SELECT " + VEHICULO_COLS +
            "FROM vehiculo ve LEFT JOIN marca ma ON ve.id_marca = ma.id_marca ";

    /** Arma un Vehiculo (con su Marca) a partir de VEHICULO_COLS. */
    public static Vehiculo mapVehiculo(ResultSet rs) throws SQLException {
        Marca marca = Marca.builder()
                .idMarca(rs.getLong("id_marca"))
                .nombre(rs.getString("marca_nombre"))
                .estado(rs.getString("marca_estado"))
                .build();
        return Vehiculo.builder()
                .idVehiculo(rs.getLong("id_vehiculo"))
                .placa(rs.getString("placa"))
                .tipoVehiculo(TipoVehiculo.valueOf(rs.getString("tipo_vehiculo")))
                .marca(marca)
                .modelo(rs.getString("modelo"))
                .conductor(rs.getString("conductor"))
                .telefonoConductor(rs.getString("telefono_conductor"))
                .color(rs.getString("color"))
                .asientos(rs.getInt("asientos"))
                .estado(rs.getString("ve_estado"))
                .build();
    }

    @Override
    public List<Vehiculo> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY ve.tipo_vehiculo DESC, ve.placa");
    }

    @Override
    public Optional<Vehiculo> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE ve.id_vehiculo = ?", id);
    }

    public List<Vehiculo> listarActivos() {
        return executeQuery(SELECT_JOIN + "WHERE ve.estado = 'ACTIVO' ORDER BY ve.tipo_vehiculo DESC, ve.placa");
    }

    /** Los vehículos de una marca (para las tarjetas de la pantalla Marca). */
    public List<Vehiculo> listarPorMarca(Long idMarca) {
        return executeQuery(SELECT_JOIN + "WHERE ve.id_marca = ? ORDER BY ve.placa", idMarca);
    }

    public Optional<Vehiculo> findByPlaca(String placa) {
        return executeQueryOne(SELECT_JOIN + "WHERE ve.placa = ?", placa);
    }

    @Override
    protected Vehiculo insert(Connection conn, Vehiculo e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO vehiculo(placa,tipo_vehiculo,id_marca,modelo,conductor,telefono_conductor,color,asientos,estado) " +
                "VALUES(?,?,?,?,?,?,?,?,?)",
                e.getPlaca(), e.getTipoVehiculo().name(), e.getMarca().getIdMarca(), e.getModelo(), e.getConductor(),
                e.getTelefonoConductor(), e.getColor(), e.getTipoVehiculo().getAsientos(), e.getEstado());
        e.setIdVehiculo(id);
        e.setAsientos(e.getTipoVehiculo().getAsientos());
        return e;
    }

    @Override
    protected Vehiculo updateRow(Connection conn, Vehiculo e) throws SQLException {
        executeUpdate(conn,
                "UPDATE vehiculo SET placa=?,tipo_vehiculo=?,id_marca=?,modelo=?,conductor=?,telefono_conductor=?," +
                "color=?,asientos=?,estado=? WHERE id_vehiculo=?",
                e.getPlaca(), e.getTipoVehiculo().name(), e.getMarca().getIdMarca(), e.getModelo(), e.getConductor(),
                e.getTelefonoConductor(), e.getColor(), e.getTipoVehiculo().getAsientos(), e.getEstado(),
                e.getIdVehiculo());
        e.setAsientos(e.getTipoVehiculo().getAsientos());
        return e;
    }

    @Override
    protected Vehiculo mapRow(ResultSet rs) throws SQLException {
        return mapVehiculo(rs);
    }
}
