/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ViajeController.java                                         │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Programar salidas: vehículo, sentido, fecha, hora y precio           │
 * │   (sugerido por el producto).                                          │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.syspasajes.components.ColumnInfo;
import pe.edu.upeu.syspasajes.components.TableViewHelper;
import pe.edu.upeu.syspasajes.components.Toast;
import pe.edu.upeu.syspasajes.components.ToltipCustom;
import pe.edu.upeu.syspasajes.dto.ComboBoxOption;
import pe.edu.upeu.syspasajes.enums.EstadoViaje;
import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.model.Vehiculo;
import pe.edu.upeu.syspasajes.model.Viaje;
import pe.edu.upeu.syspasajes.service.IProductoService;
import pe.edu.upeu.syspasajes.service.IVehiculoService;
import pe.edu.upeu.syspasajes.service.IViajeService;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.function.Consumer;

/** Programación de salidas: qué vehículo sale, en qué sentido, fecha, hora y precio. */
@RequiredArgsConstructor
public class ViajeController {

    private final IViajeService vjs;
    private final IVehiculoService vs;
    private final IProductoService ps;

    @FXML ComboBox<ComboBoxOption> cbxVehiculo;
    @FXML ComboBox<Sentido> cbxSentido;
    @FXML ComboBox<EstadoViaje> cbxEstado;
    @FXML ComboBox<String> cbxHora;
    @FXML DatePicker dpFecha, dpFiltroFecha;
    @FXML TextField txtPrecio;
    @FXML CheckBox chkTodasFechas;
    @FXML Label lbnMsg;
    @FXML Button btnGuardar;
    @FXML private TableView<Viaje> tableView;
    @FXML private AnchorPane miContenedor;

    private Validator validator;
    private final ToltipCustom ttc = new ToltipCustom();
    private Viaje formulario;
    private Long idViajeCE = 0L;
    private List<Vehiculo> vehiculos = new ArrayList<>();

    @FXML
    public void initialize() {
        idViajeCE = 0L;
        validator = Validation.buildDefaultValidatorFactory().getValidator();

        cargarVehiculos();
        cbxSentido.getItems().setAll(Sentido.values());
        cbxEstado.getItems().setAll(EstadoViaje.values());
        cbxEstado.getSelectionModel().select(EstadoViaje.PROGRAMADO);
        // Horas sugeridas cada 30 minutos (el combo es editable: se puede escribir otra hora HH:mm)
        List<String> horas = new ArrayList<>();
        for (LocalTime t = LocalTime.of(6, 0); !t.isAfter(LocalTime.of(22, 0)); t = t.plusMinutes(30)) {
            horas.add(t.toString());
        }
        cbxHora.getItems().setAll(horas);
        cbxHora.setEditable(true);
        dpFecha.setValue(LocalDate.now());
        dpFiltroFecha.setValue(LocalDate.now());

        // Al elegir vehículo y sentido se sugiere el precio del PRODUCTO (tarifa) que corresponde
        cbxVehiculo.setOnAction(e -> sugerirPrecio());
        cbxSentido.setOnAction(e -> sugerirPrecio());
        dpFiltroFecha.setOnAction(e -> listar());
        chkTodasFechas.setOnAction(e -> {
            dpFiltroFecha.setDisable(chkTodasFechas.isSelected());
            listar();
        });

        TableViewHelper<Viaje> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("ID", new ColumnInfo("idViaje", 50.0));
        columns.put("Fecha", new ColumnInfo("fechaTexto", 90.0));
        columns.put("Hora", new ColumnInfo("horaTexto", 60.0));
        columns.put("Ruta", new ColumnInfo("rutaTexto", 260.0));
        columns.put("Tipo", new ColumnInfo("tipoTexto", 65.0));
        columns.put("Placa", new ColumnInfo("placa", 80.0));
        columns.put("Libres", new ColumnInfo("libresTexto", 65.0));
        columns.put("Precio", new ColumnInfo("precioTexto", 75.0));
        columns.put("Estado", new ColumnInfo("estadoTexto", 90.0));

        Consumer<Viaje> updateAction = this::editForm;
        Consumer<Viaje> deleteAction = v -> {
            if (!confirmar("¿Eliminar la salida de las " + v.getHoraTexto() + " (" + v.getRutaTexto() + ")?")) return;
            try {
                vjs.delete(v.getIdViaje());
                Toast.mostrar(stage(), "Salida eliminada correctamente", Toast.EXITO);
                if (Objects.equals(idViajeCE, v.getIdViaje())) clearForm();
            } catch (Exception ex) {
                Toast.mostrar(stage(), "No se puede eliminar: la salida tiene pasajes vendidos o reservados. "
                        + "Cámbiele el estado a CANCELADO.", Toast.ERROR);
            }
            listar();
        };
        helper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        tableView.setTableMenuButtonVisible(true);
        lbnMsg.setText("");
        listar();
    }

    private void cargarVehiculos() {
        vehiculos = vs.listarActivos();
        cbxVehiculo.getItems().setAll(vs.listarCombobox());
    }

    private Vehiculo vehiculoSeleccionado() {
        ComboBoxOption op = cbxVehiculo.getSelectionModel().getSelectedItem();
        if (op == null) return null;
        Long id = Long.parseLong(op.getKey());
        return vehiculos.stream().filter(v -> v.getIdVehiculo().equals(id)).findFirst()
                .orElseGet(() -> vs.findById(id));
    }

    @FXML
    public void listar() {
        List<Viaje> lista = chkTodasFechas.isSelected() || dpFiltroFecha.getValue() == null
                ? vjs.findAll()
                : vjs.listarPorFecha(dpFiltroFecha.getValue());
        tableView.setItems(FXCollections.observableArrayList(lista));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Viaje();
        formulario.setVehiculo(vehiculoSeleccionado());
        formulario.setSentido(cbxSentido.getSelectionModel().getSelectedItem());
        formulario.setEstado(cbxEstado.getSelectionModel().getSelectedItem());
        formulario.setFecha(dpFecha.getValue());
        formulario.setHoraSalida(parseHora(cbxHora.getEditor().getText()));
        formulario.setPrecio(parseDoubleSafe(txtPrecio.getText()));

        List<ConstraintViolation<Viaje>> violaciones = validator.validate(formulario).stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();
        if (!violaciones.isEmpty()) {
            mostrarErroresValidacion(violaciones);
            return;
        }
        // Regla: no programar salidas en fechas pasadas (solo al registrar una nueva)
        if (idViajeCE == 0L && formulario.getFecha().isBefore(LocalDate.now())) {
            marcarUnError(dpFecha, "No se pueden programar salidas en fechas pasadas");
            return;
        }
        // Regla: si ya hay boletos vendidos no se puede cambiar a un vehículo con menos asientos
        if (idViajeCE > 0L) {
            Viaje original = vjs.findById(idViajeCE);
            int vendidos = vjs.contarBoletos(idViajeCE);
            if (vendidos > 0 && !original.getVehiculo().getIdVehiculo().equals(formulario.getVehiculo().getIdVehiculo())) {
                marcarUnError(cbxVehiculo, "La salida ya tiene " + vendidos
                        + " pasaje(s) vendido(s): no se puede cambiar el vehículo");
                return;
            }
        }
        // Regla: el mismo vehículo no puede tener dos salidas a la misma fecha y hora
        boolean choque = vjs.listarPorFecha(formulario.getFecha()).stream()
                .anyMatch(v -> !v.getIdViaje().equals(idViajeCE)
                        && v.getVehiculo().getIdVehiculo().equals(formulario.getVehiculo().getIdVehiculo())
                        && v.getHoraSalida().equals(formulario.getHoraSalida())
                        && v.getEstado() != EstadoViaje.CANCELADO);
        if (choque) {
            marcarUnError(cbxHora, "Ese vehículo ya tiene una salida a las " + formulario.getHoraTexto());
            return;
        }
        procesarFormulario();
    }

    private void marcarUnError(Control c, String msg) {
        limpiarError();
        ttc.marcarError(c, msg);
        lbnMsg.setText(msg);
        lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
        Platform.runLater(c::requestFocus);
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Viaje>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("vehiculo", cbxVehiculo);
        campos.put("sentido", cbxSentido);
        campos.put("fecha", dpFecha);
        campos.put("horaSalida", cbxHora);
        campos.put("precio", txtPrecio);
        campos.put("estado", cbxEstado);

        String primerMensaje = null;
        Control primerCtrl = null;
        for (Map.Entry<String, Control> campo : campos.entrySet()) {
            Optional<ConstraintViolation<Viaje>> v = violaciones.stream()
                    .filter(x -> x.getPropertyPath().toString().equals(campo.getKey())).findFirst();
            if (v.isPresent()) {
                ttc.marcarError(campo.getValue(), v.get().getMessage());
                if (primerMensaje == null) {
                    primerMensaje = v.get().getMessage();
                    primerCtrl = campo.getValue();
                }
            }
        }
        if (primerMensaje != null) {
            lbnMsg.setText(primerMensaje);
            lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
            Control foco = primerCtrl;
            Platform.runLater(foco::requestFocus);
        }
    }

    private void procesarFormulario() {
        try {
            if (idViajeCE > 0L) {
                formulario.setIdViaje(idViajeCE);
                vjs.update(idViajeCE, formulario);
                Toast.mostrar(stage(), "Salida actualizada correctamente", Toast.EXITO);
            } else {
                vjs.save(formulario);
                Toast.mostrar(stage(), "Salida programada correctamente", Toast.EXITO);
            }
            dpFiltroFecha.setValue(formulario.getFecha());
            clearForm();
            lbnMsg.setText("Formulario guardado");
            lbnMsg.setStyle("-fx-text-fill: #1553c7; -fx-font-size: 14px;");
            listar();
        } catch (Exception ex) {
            lbnMsg.setText("Error al guardar: " + ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
        }
    }

    public void editForm(Viaje v) {
        limpiarError();
        cargarVehiculos();
        idViajeCE = v.getIdViaje();
        ComboBoxOption opVeh = cbxVehiculo.getItems().stream()
                .filter(o -> Long.parseLong(o.getKey()) == v.getVehiculo().getIdVehiculo())
                .findFirst().orElse(null);
        if (opVeh == null) {
            // Vehículo inactivo: se agrega al combo para poder editar la salida
            opVeh = new ComboBoxOption(String.valueOf(v.getVehiculo().getIdVehiculo()), v.getVehiculo().getDescripcionCorta());
            cbxVehiculo.getItems().add(opVeh);
            vehiculos.add(v.getVehiculo());
        }
        cbxVehiculo.getSelectionModel().select(opVeh);
        cbxSentido.getSelectionModel().select(v.getSentido());
        cbxEstado.getSelectionModel().select(v.getEstado());
        dpFecha.setValue(v.getFecha());
        cbxHora.getEditor().setText(v.getHoraTexto());
        cbxHora.setValue(v.getHoraTexto());
        txtPrecio.setText(String.format(Locale.US, "%.2f", v.getPrecio()));
        btnGuardar.setText("Actualizar");
        lbnMsg.setText("Editando salida #" + v.getIdViaje());
        lbnMsg.setStyle("-fx-text-fill: #1565c0; -fx-font-size: 14px;");
    }

    @FXML
    public void clearForm() {
        cargarVehiculos();
        cbxVehiculo.getSelectionModel().clearSelection();
        cbxSentido.getSelectionModel().clearSelection();
        cbxEstado.getSelectionModel().select(EstadoViaje.PROGRAMADO);
        cbxHora.setValue(null);
        cbxHora.getEditor().clear();
        dpFecha.setValue(LocalDate.now());
        txtPrecio.clear();
        idViajeCE = 0L;
        btnGuardar.setText("Guardar");
        lbnMsg.setText("");
        limpiarError();
    }

    public void limpiarError() {
        List.of(cbxVehiculo, cbxSentido, cbxEstado, cbxHora, dpFecha, txtPrecio).forEach(ttc::limpiarCampo);
    }

    private LocalTime parseHora(String texto) {
        if (texto == null || texto.isBlank()) return null;
        try {
            String t = texto.trim();
            if (t.length() == 4 && t.charAt(1) == ':') t = "0" + t; // 7:30 -> 07:30
            return LocalTime.parse(t);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try {
            return Double.parseDouble(value.trim().replace(",", "."));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private boolean confirmar(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, mensaje, ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Confirmación");
        alert.setHeaderText(null);
        return alert.showAndWait().filter(b -> b == ButtonType.OK).isPresent();
    }

    private Stage stage() {
        return (Stage) miContenedor.getScene().getWindow();
    }

    /** Pone el precio del producto (tarifa) según el tipo de vehículo y el sentido elegidos. */
    private void sugerirPrecio() {
        if (idViajeCE > 0L) return; // al editar se respeta el precio guardado
        Vehiculo v = vehiculoSeleccionado();
        Sentido sentido = cbxSentido.getSelectionModel().getSelectedItem();
        if (v != null) {
            txtPrecio.setText(String.format(Locale.US, "%.2f", ps.precioPara(v.getTipoVehiculo(), sentido)));
        }
    }
}
