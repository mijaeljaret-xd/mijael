/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : DibujoVehiculo.java                                          │
 * │ CAPA    : COMPONENTES visuales                                         │
 * │ MÓDULO  : MARCA (imagen de cada vehículo)                              │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   DIBUJA el vehículo con figuras de JavaFX (no necesita archivos de    │
 * │   imagen):  AUTO → sedán de 5 asientos · VAN → van de 11 asientos.     │
 * │   El color de la carrocería es el que el usuario elige.                │
 * │   ► Para cambiar la forma, edita las coordenadas de CARROCERIA_AUTO /  │
 * │     CARROCERIA_VAN (están en un lienzo de 200 x 95 puntos).            │
 * │   ► Para cambiar la franja, las ventanas o las llantas, edita los      │
 * │     colores de las constantes de abajo.                                │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.scene.shape.Shape;

public final class DibujoVehiculo {

    // ───── PASO 1: colores fijos del dibujo ─────
    private static final Color CONTORNO = Color.web("#1F2937");   // línea oscura alrededor
    private static final Color VIDRIO = Color.web("#CFE3FF");     // ventanas celestes
    private static final Color LLANTA = Color.web("#222222");
    private static final Color ARO = Color.web("#BBBBBB");
    private static final Color FARO = Color.web("#FFE58A");
    private static final Color STOP = Color.web("#E53935");
    private static final Color DORADO = Color.web("#D4A017");
    private static final Color AZUL = Color.web("#0A2A66");

    // ───── PASO 2: la forma de la carrocería (mismo formato que un "path" de SVG) ─────
    // M = mover · L = línea · Q = curva · Z = cerrar
    private static final String CARROCERIA_AUTO =
            "M12,72 L12,55 Q14,46 30,44 L52,42 L72,22 Q76,18 84,18 L128,18 Q136,18 142,24 "
          + "L160,42 L178,46 Q192,50 192,60 L192,72 Z";
    private static final String CARROCERIA_VAN =
            "M10,74 L10,20 Q10,14 18,14 L150,14 Q160,14 166,22 L188,46 Q192,50 192,56 L192,74 Z";

    private DibujoVehiculo() {
    }

    /**
     * ───── PASO 3: crear el dibujo ─────
     * @param tipo   "AUTO" o "VAN"
     * @param color  color de la carrocería
     * @param ancho  ancho en pantalla (el dibujo se escala proporcionalmente)
     */
    public static Node crear(String tipo, Color color, double ancho) {
        Group g = crearSinEscala(tipo, color);
        double escala = ancho / 200.0;           // el lienzo original mide 200 de ancho
        g.setScaleX(escala);
        g.setScaleY(escala);
        return new Group(g);                     // el Group exterior respeta el tamaño escalado
    }

    /** El dibujo en su tamaño original (200 x 95). */
    public static Group crearSinEscala(String tipo, Color color) {
        return "VAN".equals(tipo) ? van(color) : auto(color);
    }

    // ───── PASO 4: el AUTO (sedán, 5 asientos) ─────
    private static Group auto(Color color) {
        return new Group(
                sombra(100, 88),
                carroceria(CARROCERIA_AUTO, color),
                vidrio(new Polygon(58, 42, 76, 24, 104, 24, 104, 42)),       // ventana delantera
                vidrio(new Polygon(110, 42, 110, 24, 130, 24, 152, 42)),     // ventana trasera
                linea(107, 44, 107, 70),                                     // línea de la puerta
                franja(16, 57, 172, color),                                  // franja decorativa
                faro(186, 53), stop(12, 50, 7),
                llanta(52, 72), llanta(152, 72));
    }

    // ───── PASO 5: la VAN (11 asientos) ─────
    private static Group van(Color color) {
        return new Group(
                sombra(100, 90),
                carroceria(CARROCERIA_VAN, color),
                vidrio(ventana(20)), vidrio(ventana(56)), vidrio(ventana(92)), // ventanas de pasajeros
                vidrio(new Polygon(128, 22, 152, 22, 172, 44, 128, 44)),       // parabrisas
                linea(125, 46, 125, 72),                                       // puerta corrediza
                franja(14, 52, 174, color),
                faro(187, 58), stop(10, 50, 8),
                llanta(45, 74), llanta(158, 74));
    }

    // ───── Piezas reutilizables (cada una es una figura de JavaFX) ─────
    private static Shape carroceria(String path, Color color) {
        SVGPath p = new SVGPath();
        p.setContent(path);
        p.setFill(color);
        p.setStroke(CONTORNO);
        p.setStrokeWidth(1.4);
        return p;
    }

    private static Shape vidrio(Shape s) {
        s.setFill(VIDRIO);
        s.setStroke(CONTORNO);
        s.setStrokeWidth(1);
        return s;
    }

    private static Rectangle ventana(double x) {
        Rectangle r = new Rectangle(x, 22, 30, 20);
        r.setArcWidth(4);
        r.setArcHeight(4);
        return r;
    }

    private static Line linea(double x1, double y1, double x2, double y2) {
        Line l = new Line(x1, y1, x2, y2);
        l.setStroke(CONTORNO);
        return l;
    }

    /** Franja dorada; si el vehículo es claro o dorado, la franja sale azul para que se vea. */
    private static Rectangle franja(double x, double y, double largo, Color color) {
        Rectangle r = new Rectangle(x, y, largo, 3);
        r.setFill(color.getBrightness() > 0.6 ? AZUL : DORADO);
        return r;
    }

    private static Ellipse faro(double x, double y) {
        Ellipse e = new Ellipse(x, y, 4, 3);
        e.setFill(FARO);
        e.setStroke(CONTORNO);
        e.setStrokeWidth(0.8);
        return e;
    }

    private static Rectangle stop(double x, double y, double alto) {
        Rectangle r = new Rectangle(x, y, 4, alto);
        r.setFill(STOP);
        return r;
    }

    private static Group llanta(double x, double y) {
        return new Group(new Circle(x, y, 14, LLANTA), new Circle(x, y, 6, ARO));
    }

    private static Ellipse sombra(double x, double y) {
        Ellipse e = new Ellipse(x, y, 86, 5);
        e.setFill(Color.rgb(0, 0, 0, 0.15));
        return e;
    }
}
