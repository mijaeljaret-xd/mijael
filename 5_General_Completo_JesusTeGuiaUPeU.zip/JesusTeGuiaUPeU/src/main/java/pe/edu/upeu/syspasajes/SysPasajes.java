/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : SysPasajes.java                                              │
 * │ CAPA    : Arranque                                                     │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Aplicación JavaFX: crea la base de datos, carga los datos            │
 * │   iniciales y muestra la ventana de ingreso con el logo de Jesús.      │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import pe.edu.upeu.syspasajes.config.AppContext;
import pe.edu.upeu.syspasajes.config.DatabaseConfig;
import pe.edu.upeu.syspasajes.config.DatosIniciales;

import java.io.IOException;

/**
 * SysPasajes UPeU — Venta de pasajes de taxi y combi
 * Ruta: Universidad UPeU  <->  C.C. Plaza de Armas
 */
public class SysPasajes extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        AppContext context = AppContext.getInstance();
        // Carga vehiculos de ejemplo y la programacion de salidas de hoy y mañana
        DatosIniciales.cargar(context);

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/login.fxml"));
        fxmlLoader.setControllerFactory(context::getBean);
        Scene scene = new Scene(fxmlLoader.load());
        scene.getStylesheets().add(getClass().getResource("/css/login.css").toExternalForm());

        stage.getIcons().add(new Image(getClass().getResourceAsStream("/img/logo_jesus.png")));
        stage.setTitle("Jesús te guía a la UPeU - Ingreso");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }

    @Override
    public void stop() {
        // Libera las conexiones del pool al cerrar la ventana.
        DatabaseConfig.shutdown();
    }
}
