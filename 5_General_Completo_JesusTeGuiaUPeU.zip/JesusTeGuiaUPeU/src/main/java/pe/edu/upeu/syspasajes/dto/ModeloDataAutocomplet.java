/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ModeloDataAutocomplet.java                                   │
 * │ CAPA    : DTO                                                          │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Dato que muestra el autocompletado de clientes (DNI y nombre).       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.dto;

import lombok.Data;

/**
 * DTO para autocompletado de combos/búsquedas.
 * No requiere cambios — es un POJO simple.
 */

@Data
public class ModeloDataAutocomplet {
    private String idx;
    private String nameDysplay;
    private String otherData;

    @Override
    public String toString()
    {
        return idx+" - "+nameDysplay;
    }
}
