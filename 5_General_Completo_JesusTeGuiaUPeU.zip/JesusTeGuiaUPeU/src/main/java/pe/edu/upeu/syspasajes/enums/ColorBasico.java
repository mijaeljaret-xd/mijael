/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ColorBasico.java                                             │
 * │ CAPA    : Enumeración                                                  │
 * │ MÓDULO  : MARCA / Flota (colores permitidos)                           │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Lista FIJA de colores básicos de vehículos (los más usados en Perú). │
 * │   En la base de datos se guarda el NOMBRE ("Azul", "Blanco"…) y aquí   │
 * │   está el código de color con el que se pinta el dibujo.               │
 * │   ► Para agregar un color: añade una línea  NOMBRE("Texto", "#RRGGBB") │
 * │     y aparece solo en los selectores de color.                         │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.enums;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.Comparator;

public enum ColorBasico {

    //            nombre visible      código
    BLANCO       ("Blanco",           "#F5F5F5"),
    PLATA        ("Plata",            "#C0C0C0"),
    GRIS         ("Gris",             "#707070"),
    NEGRO        ("Negro",            "#1C1C1C"),
    ROJO         ("Rojo",             "#C62828"),
    AZUL         ("Azul",             "#1553C7"),
    AZUL_MARINO  ("Azul marino",      "#0A2A66"),
    VERDE        ("Verde",            "#2E7D32"),
    AMARILLO     ("Amarillo taxi",    "#F9C80E"),
    GUINDA       ("Guinda",           "#6D1A2B");

    // ───── PASO 1: datos de cada color ─────
    private final String nombre;
    private final String hex;

    ColorBasico(String nombre, String hex) {
        this.nombre = nombre;
        this.hex = hex;
    }

    public String getNombre() { return nombre; }
    public String getHex() { return hex; }

    // ───── PASO 2: convertir lo guardado en la BD a un color de la lista ─────
    /**
     * Acepta el nombre ("azul", "Amarillo"…) o un código "#RRGGBB".
     * Si no lo reconoce devuelve BLANCO (así los datos antiguos no fallan).
     */
    public static ColorBasico desdeTexto(String texto) {
        if (texto == null || texto.isBlank()) return BLANCO;
        String t = sinTildes(texto.trim());
        if (t.startsWith("#")) return masCercano(t);
        // 1) nombre exacto
        for (ColorBasico c : values()) if (sinTildes(c.nombre).equals(t)) return c;
        // 2) nombre parecido: "amarillo" → Amarillo taxi, "azul oscuro" → Azul marino
        if (t.contains("marino") || t.contains("oscuro")) return AZUL_MARINO;
        if (t.contains("dorado")) return AMARILLO;
        if (t.startsWith("plat")) return PLATA;
        for (ColorBasico c : values()) if (sinTildes(c.nombre).startsWith(t) || t.startsWith(sinTildes(c.nombre))) return c;
        return BLANCO;
    }

    /** El color de la lista más parecido a un código #RRGGBB. */
    public static ColorBasico masCercano(String hex) {
        int[] a = rgb(hex);
        return Arrays.stream(values())
                .min(Comparator.comparingInt(c -> distancia(a, rgb(c.hex))))
                .orElse(BLANCO);
    }

    private static String sinTildes(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase();
    }

    private static int[] rgb(String hex) {
        try {
            int v = Integer.parseInt(hex.replace("#", ""), 16);
            return new int[]{(v >> 16) & 255, (v >> 8) & 255, v & 255};
        } catch (RuntimeException e) {
            return new int[]{245, 245, 245};
        }
    }

    private static int distancia(int[] a, int[] b) {
        int r = a[0] - b[0], g = a[1] - b[1], bl = a[2] - b[2];
        return r * r + g * g + bl * bl;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
