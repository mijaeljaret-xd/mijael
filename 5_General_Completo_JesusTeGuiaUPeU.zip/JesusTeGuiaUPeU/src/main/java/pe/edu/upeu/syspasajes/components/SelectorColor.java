/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : SelectorColor.java                                           │
 * │ CAPA    : Componentes visuales                                         │
 * │ MÓDULO  : MARCA / Flota                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Lista desplegable que SOLO muestra los colores básicos (ColorBasico) │
 * │   con un cuadradito del color y su nombre:  ■ Rojo                     │
 * │   Se usa en las tarjetas de la pantalla Marca y en el formulario de    │
 * │   Vehículos.                                                           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.scene.control.ComboBox;
import javafx.scene.control.ListCell;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import pe.edu.upeu.syspasajes.enums.ColorBasico;

public class SelectorColor extends ComboBox<ColorBasico> {   // HERENCIA: es un ComboBox

    /** @param colorGuardado lo que está en la BD ("Azul", "Blanco"…); se marca ese color. */
    public SelectorColor(String colorGuardado) {
        configurar(this);
        setValue(ColorBasico.desdeTexto(colorGuardado));
        setPrefWidth(160);
    }

    /** Prepara cualquier ComboBox (por ejemplo uno del FXML) con los colores básicos. */
    public static void configurar(ComboBox<ColorBasico> combo) {
        combo.getItems().setAll(ColorBasico.values());
        combo.setCellFactory(lista -> new Celda());   // cómo se ve cada opción de la lista
        combo.setButtonCell(new Celda());             // cómo se ve la opción elegida
    }

    /** Fila de la lista: cuadradito de color + nombre (POLIMORFISMO: sobrescribe updateItem). */
    private static class Celda extends ListCell<ColorBasico> {
        @Override
        protected void updateItem(ColorBasico c, boolean vacio) {
            super.updateItem(c, vacio);
            if (vacio || c == null) {
                setText(null);
                setGraphic(null);
            } else {
                Rectangle cuadro = new Rectangle(16, 16, Color.web(c.getHex()));
                cuadro.setArcWidth(4);
                cuadro.setArcHeight(4);
                cuadro.setStroke(Color.web("#8A94A8"));
                setGraphic(cuadro);
                setText(c.getNombre());
            }
        }
    }
}
