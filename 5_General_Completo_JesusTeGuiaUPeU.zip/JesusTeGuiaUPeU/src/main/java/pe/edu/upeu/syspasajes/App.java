/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : App.java                                                     │
 * │ CAPA    : Arranque                                                     │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Punto de entrada: ejecuta este archivo en IntelliJ para abrir el     │
 * │   sistema. Llama a SysPasajes.                                         │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes;

import javafx.application.Application;

/** Punto de entrada (lanzador) de la aplicación. */
public class App {
    public static void main(String[] args) {
        Application.launch(SysPasajes.class, args);
    }
}
