/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Menus.java                                                   │
 * │ CAPA    : Enumeración                                                  │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Nombres de los grupos de menú.                                       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.enums;

public enum Menus {
    PRINCIPAL,
    FLOTA,
    PASAJES,
    REPORTES
}
