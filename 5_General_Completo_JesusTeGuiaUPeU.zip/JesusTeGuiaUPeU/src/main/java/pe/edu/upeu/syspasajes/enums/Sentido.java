/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Sentido.java                                                 │
 * │ CAPA    : Enumeración                                                  │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Los dos sentidos de la ruta: UPeU → Plaza de Armas y Plaza de        │
 * │   Armas → UPeU.                                                        │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.enums;

import lombok.Getter;

/** Sentido del traslado: de la universidad al centro comercial o viceversa. */
@Getter
public enum Sentido {
    UPEU_PLAZA("Universidad UPeU", "C.C. Plaza de Armas"),
    PLAZA_UPEU("C.C. Plaza de Armas", "Universidad UPeU");

    private final String origen;
    private final String destino;

    Sentido(String origen, String destino) {
        this.origen = origen;
        this.destino = destino;
    }

    public String getDescripcion() {
        return origen + " → " + destino;
    }

    @Override
    public String toString() {
        return getDescripcion();
    }
}
