/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Marca.java                                                   │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Marca de vehículo: nombre y estado (ya no lleva país).               │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** MÓDULO MARCA: marca de los vehículos de la flota (Toyota, Hyundai, Kia, Nissan...). */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Marca {

    private Long idMarca;

    @NotBlank(message = "El nombre de la marca es obligatorio")
    @Size(max = 30, message = "La marca admite máximo 30 caracteres")
    private String nombre;

    @NotBlank(message = "El estado es obligatorio")
    private String estado;

    /** El ComboBox muestra el nombre de la marca. */
    @Override
    public String toString() {
        return nombre;
    }
}
