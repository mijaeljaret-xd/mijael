/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Cifrado.java                                                 │
 * │ CAPA    : Utilidades                                                   │
 * │ MÓDULO  : General (seguridad)                                          │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   INVESTIGACIÓN ADICIONAL: ENCRIPTAR LAS CONTRASEÑAS.                  │
 * │   Las contraseñas NUNCA se guardan tal cual en la base de datos.       │
 * │   Se guarda su "huella" SHA-256 (64 letras/números). Es de un solo     │
 * │   sentido: con la huella no se puede saber la contraseña.              │
 * │     clave_guardada = SHA-256( usuario_en_minúsculas + ":" + clave )    │
 * │   Se mezcla con el usuario (SAL) para que dos personas con la misma    │
 * │   contraseña tengan huellas distintas.                                 │
 * │   Al iniciar sesión se calcula la huella de lo escrito y se compara.   │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.utils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

public final class Cifrado {

    private Cifrado() {
    }

    // ───── PASO 1: huella SHA-256 de un texto (en hexadecimal) ─────
    public static String sha256(String texto) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] huella = md.digest(texto.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(huella);   // 32 bytes → 64 caracteres
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 no disponible", e);
        }
    }

    // ───── PASO 2: cifrar la contraseña de un usuario (con su SAL) ─────
    public static String cifrarClave(String usuario, String clave) {
        return sha256(usuario.trim().toLowerCase() + ":" + clave);
    }

    // ───── PASO 3: ¿ya está cifrada? (64 caracteres hexadecimales) ─────
    /** Evita cifrar dos veces una clave que ya viene cifrada. */
    public static boolean estaCifrada(String clave) {
        return clave != null && clave.matches("[0-9a-f]{64}");
    }
}
