/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MainguiController.java                                       │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Ventana principal: arma los menús según el perfil, abre las          │
 * │   pestañas, cambia el tema de colores y el idioma.                     │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.syspasajes.components.StageManager;
import pe.edu.upeu.syspasajes.config.AppContext;
import pe.edu.upeu.syspasajes.dto.MenuMenuItenTO;
import pe.edu.upeu.syspasajes.dto.SessionManager;
import pe.edu.upeu.syspasajes.dto.VentaResumen;
import pe.edu.upeu.syspasajes.service.IMenuMenuItemDao;
import pe.edu.upeu.syspasajes.service.IVentaPasajeService;
import pe.edu.upeu.syspasajes.service.IViajeService;
import pe.edu.upeu.syspasajes.utils.UtilsX;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.prefs.Preferences;

@RequiredArgsConstructor
public class MainguiController {

    @FXML BorderPane bp;
    @FXML MenuBar menuBar;
    @FXML TabPane tabPane;
    @FXML Tab tabInicio;
    @FXML Label lblBienvenida, lblFecha, lblViajesHoy, lblPasajesHoy, lblRecaudadoHoy, lblPerfil;

    private final IMenuMenuItemDao mmiDao;
    private final IViajeService viajeService;
    private final IVentaPasajeService ventaService;

    private static final Preferences userPrefs = Preferences.userRoot().node("syspasajes-upeu");
    private static final String PREF_TEMA = "TEMA_V3";   // v3: arranca con el tema azul, blanco y dorado
    private static final String PREF_IDIOMA = "IDIOMAX";

    /** Temas de color disponibles: nombre visible -> hoja de estilos. */
    private static final LinkedHashMap<String, String> TEMAS = new LinkedHashMap<>();
    static {
        TEMAS.put("Azul, Blanco y Dorado (por defecto)", "/css/tema-azul-dorado.css");
        TEMAS.put("Gris Sobrio", "/css/tema-sobrio.css");
        TEMAS.put("Taxi Amarillo", "/css/tema-taxi.css");
        TEMAS.put("Azul UPeU", "/css/tema-upeu.css");
        TEMAS.put("Noche Urbana (oscuro)", "/css/tema-noche.css");
        TEMAS.put("Turquesa Titicaca", "/css/tema-turquesa.css");
        TEMAS.put("Atardecer Naranja", "/css/tema-atardecer.css");
        TEMAS.put("Lavanda Andina", "/css/tema-lavanda.css");
    }

    private final UtilsX util = new UtilsX();
    private Properties myresources = new Properties();
    private List<MenuMenuItenTO> lista;

    private final Menu menuEstilo = new Menu("Cambiar Estilo");
    private final ComboBox<String> comboBoxEstilo = new ComboBox<>(FXCollections.observableArrayList(TEMAS.keySet()));
    private final CustomMenuItem customItem = new CustomMenuItem(comboBoxEstilo);

    private final Menu menuIdioma = new Menu("Idioma");
    private final ComboBox<String> comboBoxIdioma = new ComboBox<>(
            FXCollections.observableArrayList("Español", "Ingles", "Frances"));
    private final CustomMenuItem customItemIdioma = new CustomMenuItem(comboBoxIdioma);

    @FXML
    public void initialize() {
        comboBoxEstilo.setPromptText("Elegir tema...");
        comboBoxEstilo.getSelectionModel().select(nombreTemaGuardado());
        comboBoxEstilo.setOnAction(e -> cambiarEstilo());
        customItem.setHideOnClick(false);

        comboBoxIdioma.setPromptText("Elegir idioma...");
        comboBoxIdioma.setOnAction(e -> cambiarIdioma());
        customItemIdioma.setHideOnClick(false);

        graficarMenus();
        tabInicio.setClosable(false);
        tabInicio.setOnSelectionChanged(e -> {
            if (tabInicio.isSelected()) actualizarInicio();
        });
        actualizarInicio();
    }

    // ------------------------------------------------------------------
    //  PANTALLA DE INICIO (resumen del día)
    // ------------------------------------------------------------------
    private void actualizarInicio() {
        SessionManager s = SessionManager.getInstance();
        lblBienvenida.setText("¡Hola, " + s.getUserName() + "!");
        lblPerfil.setText("Perfil: " + s.getUserPerfil());
        lblFecha.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE dd 'de' MMMM 'de' yyyy",
                Locale.of("es", "PE"))));
        try {
            LocalDate hoy = LocalDate.now();
            int viajes = viajeService.listarPorFecha(hoy).size();
            List<VentaResumen> ventas = ventaService.listarResumen(hoy, hoy);
            int pasajes = ventas.stream().mapToInt(VentaResumen::getCantidadPasajes).sum();
            double recaudado = ventas.stream().mapToDouble(VentaResumen::getTotal).sum();
            lblViajesHoy.setText(String.valueOf(viajes));
            lblPasajesHoy.setText(String.valueOf(pasajes));
            lblRecaudadoHoy.setText(String.format("S/ %.2f", recaudado));
        } catch (Exception ex) {
            lblViajesHoy.setText("-");
            lblPasajesHoy.setText("-");
            lblRecaudadoHoy.setText("-");
        }
    }

    // ------------------------------------------------------------------
    //  TEMAS DE COLOR
    // ------------------------------------------------------------------
    private static String nombreTemaGuardado() {
        String guardado = userPrefs.get(PREF_TEMA, "");
        return TEMAS.containsKey(guardado) ? guardado : TEMAS.keySet().iterator().next();
    }

    /** Aplica a la escena la hoja común + el tema elegido (por defecto Azul, Blanco y Dorado). */
    public static void aplicarTema(Scene escena, String nombreTema) {
        String css = TEMAS.getOrDefault(nombreTema, TEMAS.values().iterator().next());
        escena.getStylesheets().clear();
        escena.getStylesheets().add(MainguiController.class.getResource("/css/comun.css").toExternalForm());
        escena.getStylesheets().add(MainguiController.class.getResource(css).toExternalForm());
    }

    public static void aplicarTemaGuardado(Scene escena) {
        aplicarTema(escena, nombreTemaGuardado());
    }

    private void cambiarEstilo() {
        String estilo = comboBoxEstilo.getSelectionModel().getSelectedItem();
        if (estilo == null || bp.getScene() == null) return;
        aplicarTema(bp.getScene(), estilo);
        userPrefs.put(PREF_TEMA, estilo);
    }

    // ------------------------------------------------------------------
    //  IDIOMA Y MENÚS
    // ------------------------------------------------------------------
    private void cambiarIdioma() {
        String idioma = comboBoxIdioma.getSelectionModel().getSelectedItem();
        if (idioma == null) return;
        switch (idioma) {
            case "Ingles":  userPrefs.put(PREF_IDIOMA, "en"); break;
            case "Frances": userPrefs.put(PREF_IDIOMA, "fr"); break;
            default:        userPrefs.put(PREF_IDIOMA, "es"); break;
        }
        graficarMenus();
    }

    private List<MenuMenuItenTO> listaAccesos() {
        myresources = util.detectLanguage(userPrefs.get(PREF_IDIOMA, "es"));
        return mmiDao.listaAccesos(SessionManager.getInstance().getUserPerfil(), myresources);
    }

    /** Construye la barra de menús según el perfil del usuario (agrupa por nombre de menú). */
    private void graficarMenus() {
        lista = listaAccesos();
        Map<String, String[]> menuConfig = mmiDao.accesosAutorizados(lista);

        menuBar.getMenus().clear();
        Map<String, Menu> menus = new LinkedHashMap<>();
        for (MenuMenuItenTO mmi : lista) {
            Menu menu = menus.computeIfAbsent(mmi.getMenunombre(), nombre -> {
                Menu m = new Menu(nombre);
                m.setId("m" + mmi.getIdNombreObj());
                return m;
            });
            if (mmi.getMenuitemnombre() != null && !mmi.getMenuitemnombre().isEmpty()) {
                MenuItem item = new MenuItem(mmi.getMenuitemnombre());
                item.setId("mi" + mmi.getIdNombreObj());
                item.setOnAction(e -> manejarMenu(e, menuConfig));
                menu.getItems().add(item);
            }
        }
        menuBar.getMenus().addAll(menus.values());

        menuEstilo.setText(myresources.getProperty("menu.nombre.estilo", "Cambiar Estilo"));
        menuEstilo.getItems().setAll(customItem);
        menuIdioma.setText(myresources.getProperty("menu.nombre.idioma", "Idioma"));
        menuIdioma.getItems().setAll(customItemIdioma);
        menuBar.getMenus().addAll(menuEstilo, menuIdioma);
        bp.setTop(menuBar);
    }

    private void manejarMenu(ActionEvent e, Map<String, String[]> menuConfig) {
        String id = ((MenuItem) e.getSource()).getId();
        String[] items = menuConfig.get(id);
        if (items == null) return;
        switch (items[2]) {
            case "C" -> cerrarSesion(items[0]);
            case "I" -> tabPane.getSelectionModel().select(tabInicio);
            default -> abrirTabPaneFXML(items[0], items[1]);
        }
    }

    private void cerrarSesion(String fxmlPath) {
        try {
            SessionManager.getInstance().cerrarSesion();
            Stage stage = StageManager.getPrimaryStage() != null
                    ? StageManager.getPrimaryStage() : (Stage) bp.getScene().getWindow();
            AppContext ctx = AppContext.getInstance();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
            fxmlLoader.setControllerFactory(ctx::getBean);
            Parent parent = fxmlLoader.load();
            Scene scene = new Scene(parent);
            scene.getStylesheets().add(getClass().getResource("/css/login.css").toExternalForm());
            stage.setScene(scene);
            stage.setResizable(false);
            stage.sizeToScene();
            stage.centerOnScreen();
            stage.setTitle("Jesús te guía a la UPeU - Ingreso");
            stage.show();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    /** Abre la vista en una pestaña; si ya está abierta solo la selecciona. */
    private void abrirTabPaneFXML(String fxmlPath, String titulo) {
        for (Tab t : tabPane.getTabs()) {
            if (fxmlPath.equals(t.getId())) {
                t.setText(titulo);
                tabPane.getSelectionModel().select(t);
                return;
            }
        }
        try {
            AppContext context = AppContext.getInstance();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
            fxmlLoader.setControllerFactory(context::getBean);
            Parent root = fxmlLoader.load();

            ScrollPane scrollPane = new ScrollPane(root);
            scrollPane.setFitToWidth(true);
            scrollPane.setFitToHeight(true);
            Tab newTab = new Tab(titulo, scrollPane);
            newTab.setId(fxmlPath);
            newTab.setClosable(true);
            tabPane.getTabs().add(newTab);
            tabPane.getSelectionModel().select(newTab);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
