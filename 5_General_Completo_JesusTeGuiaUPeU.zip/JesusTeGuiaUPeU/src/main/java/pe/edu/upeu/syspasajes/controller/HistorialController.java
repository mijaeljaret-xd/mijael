/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : HistorialController.java                                     │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : Venta                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Historial de ventas por fechas: lista boletas y facturas, sus        │
 * │   pasajes y permite volver a ver el comprobante.                       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.syspasajes.components.ColumnInfo;
import pe.edu.upeu.syspasajes.components.TableViewHelper;
import pe.edu.upeu.syspasajes.components.Toast;
import pe.edu.upeu.syspasajes.dto.VentaResumen;
import pe.edu.upeu.syspasajes.model.Boleto;
import pe.edu.upeu.syspasajes.model.VentaPasaje;
import pe.edu.upeu.syspasajes.service.IVentaPasajeService;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;

/** Consulta de ventas por rango de fechas con el detalle de boletos. */
@RequiredArgsConstructor
public class HistorialController {

    private final IVentaPasajeService ventaService;

    @FXML DatePicker dpDesde, dpHasta;
    @FXML TableView<VentaResumen> tableVentas;
    @FXML TableView<Boleto> tableBoletos;
    @FXML Label lblTotalVentas, lblTotalPasajes, lblTotalRecaudado, lblDetalle;
    @FXML Button btnVerBoleta;
    @FXML private AnchorPane miContenedor;

    @FXML
    public void initialize() {
        dpDesde.setValue(LocalDate.now());
        dpHasta.setValue(LocalDate.now());

        TableViewHelper<VentaResumen> hv = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> cv = new LinkedHashMap<>();
        cv.put("Comprobante", new ColumnInfo("comprobante", 120.0));
        cv.put("Tipo", new ColumnInfo("tipoComprobante", 75.0));
        cv.put("Fecha y hora", new ColumnInfo("fechaTexto", 130.0));
        cv.put("DNI", new ColumnInfo("dni", 85.0));
        cv.put("Cliente", new ColumnInfo("cliente", 230.0));
        cv.put("Pasajes", new ColumnInfo("cantidadPasajes", 70.0));
        cv.put("Total", new ColumnInfo("totalTexto", 90.0));
        cv.put("Pago", new ColumnInfo("metodoPago", 120.0));
        cv.put("Vendedor", new ColumnInfo("vendedor", 100.0));
        hv.addColumnsInOrderWithSize(tableVentas, cv);
        tableVentas.setPlaceholder(new Label("No hay ventas en el rango de fechas"));

        TableViewHelper<Boleto> hb = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> cb = new LinkedHashMap<>();
        cb.put("Asiento", new ColumnInfo("nroAsiento", 70.0));
        cb.put("Ruta", new ColumnInfo("rutaTexto", 280.0));
        cb.put("Salida", new ColumnInfo("salidaTexto", 130.0));
        cb.put("Vehículo", new ColumnInfo("vehiculoTexto", 130.0));
        cb.put("Precio", new ColumnInfo("precioTexto", 90.0));
        hb.addColumnsInOrderWithSize(tableBoletos, cb);
        tableBoletos.setPlaceholder(new Label("Seleccione una venta para ver sus boletos"));

        tableVentas.getSelectionModel().selectedItemProperty().addListener((obs, a, venta) -> {
            btnVerBoleta.setDisable(venta == null);
            if (venta == null) {
                tableBoletos.getItems().clear();
                lblDetalle.setText("Detalle de la venta");
            } else {
                lblDetalle.setText("Boletos de " + venta.getComprobante() + " - " + venta.getCliente());
                tableBoletos.setItems(FXCollections.observableArrayList(ventaService.listarBoletos(venta.getIdVenta())));
            }
        });
        btnVerBoleta.setDisable(true);
        buscar();
    }

    @FXML
    public void buscar() {
        LocalDate desde = dpDesde.getValue(), hasta = dpHasta.getValue();
        if (desde == null || hasta == null || hasta.isBefore(desde)) {
            Toast.mostrar(stage(), "Rango de fechas no válido", Toast.AVISO);
            return;
        }
        List<VentaResumen> lista = ventaService.listarResumen(desde, hasta);
        tableVentas.setItems(FXCollections.observableArrayList(lista));
        tableBoletos.getItems().clear();
        lblTotalVentas.setText(String.valueOf(lista.size()));
        lblTotalPasajes.setText(String.valueOf(lista.stream().mapToInt(VentaResumen::getCantidadPasajes).sum()));
        lblTotalRecaudado.setText(String.format("S/ %.2f", lista.stream().mapToDouble(VentaResumen::getTotal).sum()));
    }

    @FXML
    public void hoy() {
        dpDesde.setValue(LocalDate.now());
        dpHasta.setValue(LocalDate.now());
        buscar();
    }

    @FXML
    public void ultimos7() {
        dpDesde.setValue(LocalDate.now().minusDays(6));
        dpHasta.setValue(LocalDate.now());
        buscar();
    }

    @FXML
    public void verBoleta() {
        VentaResumen r = tableVentas.getSelectionModel().getSelectedItem();
        if (r == null) return;
        VentaPasaje v = ventaService.findById(r.getIdVenta());
        v.setBoletos(ventaService.listarBoletos(r.getIdVenta()));
        // Ventana con Imprimir y reenvío por WhatsApp al taxista
        pe.edu.upeu.syspasajes.components.DialogoComprobante.mostrar(v, ventaService.generarTextoBoleta(v),
                v.esFactura() ? "Factura" : "Boleta", (v.esFactura() ? "Factura " : "Boleta ") + r.getComprobante(), stage());
    }

    private Stage stage() {
        return (Stage) miContenedor.getScene().getWindow();
    }
}
