/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : UsuarioServiceImp.java                                       │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Valida usuario y contraseña al iniciar sesión. La contraseña escrita │
 * │   se CIFRA con SHA-256 (utils/Cifrado) y se compara con la guardada.   │
 * │   Al guardar o modificar un usuario la clave también se cifra.         │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.repository.ICrudGenericoRepository;
import pe.edu.upeu.syspasajes.repository.UsuarioRepository;
import pe.edu.upeu.syspasajes.service.IUsuarioService;
import pe.edu.upeu.syspasajes.utils.Cifrado;

import java.util.Optional;

public class UsuarioServiceImp extends CrudGenericoServiceImp<Usuario,Long> implements IUsuarioService {
    private final UsuarioRepository repo;

    public UsuarioServiceImp(UsuarioRepository repo) {
        this.repo = repo;
    }

    @Override
    protected ICrudGenericoRepository<Usuario, Long> getRepo() {
        return repo;
    }

    // ───── LOGIN: se compara la clave CIFRADA, nunca el texto ─────
    @Override
    public Optional<Usuario> loginUsuario(String usuario, String clave) {
        return repo.findByUsuarioAndClave(usuario, Cifrado.cifrarClave(usuario, clave));
    }

    // ───── GUARDAR / MODIFICAR: la clave se guarda cifrada ─────
    @Override
    public Usuario save(Usuario u) {
        cifrar(u);
        return super.save(u);
    }

    @Override
    public Usuario update(Long id, Usuario u) {
        cifrar(u);
        return super.update(id, u);
    }

    private void cifrar(Usuario u) {
        if (u.getClave() != null && !Cifrado.estaCifrada(u.getClave())) {
            u.setClave(Cifrado.cifrarClave(u.getUsuario(), u.getClave()));
        }
    }


}
