/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MenuMenuItemDaoImp.java                                      │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Define los menús y qué ve cada perfil: Root y Administrador todo;    │
 * │   Taxista clientes, venta, carrito e historial.                        │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import pe.edu.upeu.syspasajes.dto.MenuMenuItenTO;
import pe.edu.upeu.syspasajes.service.IMenuMenuItemDao;

import java.util.*;

/**
 * Define los menús del sistema y qué perfil puede ver cada opción.
 * Tipo de opción: "T" = abre una pestaña, "C" = cierra sesión, "I" = vuelve a la pestaña de inicio.
 */
public class MenuMenuItemDaoImp implements IMenuMenuItemDao {

    @Override
    public List<MenuMenuItenTO> listaAccesos(String perfil, Properties idioma) {
        List<MenuMenuItenTO> lista = new ArrayList<>();

        lista.add(new MenuMenuItenTO("inicio", "",
                txt(idioma, "menu.nombre.principal", "Principal"), txt(idioma, "menuitem.nombre.inicio", "Inicio"),
                txt(idioma, "tab.inicio", "Inicio"), "I"));                                        // 0
        lista.add(new MenuMenuItenTO("principal", "/view/login.fxml",
                txt(idioma, "menu.nombre.principal", "Principal"), txt(idioma, "menuitem.nombre.salir", "Cerrar sesión"),
                "Salir", "C"));                                                                     // 1
        lista.add(new MenuMenuItenTO("marca", "/view/main_marca.fxml",
                txt(idioma, "menu.nombre.catalogo", "Catálogo"), txt(idioma, "menuitem.nombre.marca", "Marcas"),
                txt(idioma, "tab.marca", "Gestión de Marcas"), "T"));                               // 2
        lista.add(new MenuMenuItenTO("producto", "/view/main_producto.fxml",
                txt(idioma, "menu.nombre.catalogo", "Catálogo"), txt(idioma, "menuitem.nombre.producto", "Productos (tarifas)"),
                txt(idioma, "tab.producto", "Gestión de Productos"), "T"));                         // 3
        lista.add(new MenuMenuItenTO("vehiculo", "/view/main_vehiculo.fxml",
                txt(idioma, "menu.nombre.flota", "Flota"), txt(idioma, "menuitem.nombre.vehiculo", "Vehículos y conductores"),
                txt(idioma, "tab.vehiculo", "Gestión de Vehículos"), "T"));                         // 4
        lista.add(new MenuMenuItenTO("viaje", "/view/main_viaje.fxml",
                txt(idioma, "menu.nombre.flota", "Flota"), txt(idioma, "menuitem.nombre.viaje", "Salidas / Viajes"),
                txt(idioma, "tab.viaje", "Programación de Salidas"), "T"));                         // 5
        lista.add(new MenuMenuItenTO("cliente", "/view/main_cliente.fxml",
                txt(idioma, "menu.nombre.pasajes", "Pasajes"), txt(idioma, "menuitem.nombre.cliente", "Clientes"),
                txt(idioma, "tab.cliente", "Gestión de Clientes"), "T"));                           // 6
        lista.add(new MenuMenuItenTO("venta", "/view/main_venta.fxml",
                txt(idioma, "menu.nombre.pasajes", "Pasajes"), txt(idioma, "menuitem.nombre.venta", "Vender pasaje"),
                txt(idioma, "tab.venta", "Venta de Pasajes"), "T"));                                // 7
        lista.add(new MenuMenuItenTO("carrito", "/view/main_carrito.fxml",
                txt(idioma, "menu.nombre.pasajes", "Pasajes"), txt(idioma, "menuitem.nombre.carrito", "Venta carrito (reservas)"),
                txt(idioma, "tab.carrito", "Venta Carrito"), "T"));                                 // 8
        lista.add(new MenuMenuItenTO("historial", "/view/main_historial.fxml",
                txt(idioma, "menu.nombre.pasajes", "Pasajes"), txt(idioma, "menuitem.nombre.historial", "Historial de ventas"),
                txt(idioma, "tab.historial", "Historial de Ventas"), "T"));                         // 9

        List<MenuMenuItenTO> accesoReal = new ArrayList<>();
        accesoReal.add(lista.get(0));
        accesoReal.add(lista.get(1));
        switch (perfil == null ? "" : perfil) {
            case "Root":
            case "Administrador":
                // Root y Administrador ven y modifican todo
                accesoReal = lista;
                break;
            case "Taxista":
            case "Usuario":
                // Taxista (usuario): clientes, cobrar pasaje, carrito e historial
                accesoReal.add(lista.get(6));
                accesoReal.add(lista.get(7));
                accesoReal.add(lista.get(8));
                accesoReal.add(lista.get(9));
                break;
            case "Reporte":
                accesoReal.add(lista.get(9)); // historial
                break;
            default:
                // Perfil desconocido: solo Inicio y Salir
                break;
        }
        return accesoReal;
    }

    @Override
    public Map<String, String[]> accesosAutorizados(List<MenuMenuItenTO> accesos) {
        Map<String, String[]> menuConfig = new HashMap<>();
        for (MenuMenuItenTO menu : accesos) {
            menuConfig.put("mi" + menu.getIdNombreObj(),
                    new String[]{menu.getRutaFile(), menu.getNombreTab(), menu.getTipoTab()});
        }
        return menuConfig;
    }

    private String txt(Properties p, String clave, String porDefecto) {
        return p == null ? porDefecto : p.getProperty(clave, porDefecto);
    }
}
