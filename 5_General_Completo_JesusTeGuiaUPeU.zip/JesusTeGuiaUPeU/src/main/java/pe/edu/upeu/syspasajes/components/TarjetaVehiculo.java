/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : TarjetaVehiculo.java                                         │
 * │ CAPA    : Componentes visuales                                         │
 * │ MÓDULO  : MARCA (tarjeta de cada vehículo)                             │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Tarjeta que se ve debajo de la tabla de marcas:                      │
 * │     ┌─────────────────────────────┐                                    │
 * │     │   [ dibujo del vehículo ]   │  ← DibujoVehiculo (con su color)   │
 * │     │   [ TAX-101 ]               │  ← placa (sin país)                │
 * │     │   👤 Mijael … · 917651371   │  ← ícono del PROPIETARIO           │
 * │     │   Yaris · Auto · 5 asientos │                                    │
 * │     │   Color: [■ Azul ▾]         │  ← solo colores básicos            │
 * │     └─────────────────────────────┘                                    │
 * │   Al cambiar el color avisa al controlador (Consumer), que lo guarda.  │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.SVGPath;
import pe.edu.upeu.syspasajes.enums.ColorBasico;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Vehiculo;

import java.util.function.BiConsumer;

public class TarjetaVehiculo extends VBox {   // HERENCIA: la tarjeta "es un" VBox

    private static final double ANCHO_DIBUJO = 210;
    private final StackPane marcoImagen = new StackPane();
    private final Vehiculo vehiculo;

    /**
     * @param v             el vehículo a mostrar
     * @param cambiarColor  qué hacer cuando el usuario elige otro color (lo da el controlador)
     */
    public TarjetaVehiculo(Vehiculo v, BiConsumer<Vehiculo, ColorBasico> cambiarColor) {
        this.vehiculo = v;
        getStyleClass().add("tarjeta-vehiculo");
        setSpacing(8);
        setAlignment(Pos.TOP_CENTER);
        setPrefWidth(250);

        // ───── PASO 1: el dibujo del vehículo con su color ─────
        marcoImagen.setPrefSize(ANCHO_DIBUJO + 10, 110);
        marcoImagen.getStyleClass().add("marco-imagen");
        refrescarDibujo();

        // ───── PASO 2: la placa ─────
        Node placa = crearPlaca(v.getPlaca());

        // ───── PASO 3: el propietario (conductor) con su ícono ─────
        Label nombre = new Label(v.getConductor());
        nombre.getStyleClass().add("propietario");
        nombre.setWrapText(true);
        Label celular = new Label(v.getTelefonoTexto().isEmpty() ? "Propietario" : "Propietario · Cel. " + v.getTelefonoTexto());
        celular.getStyleClass().add("dato");
        HBox propietario = new HBox(8, crearIconoPropietario(), new VBox(1, nombre, celular));
        propietario.setAlignment(Pos.CENTER_LEFT);

        Label modelo = new Label(v.getModelo() + " · " + v.getTipoTexto() + " · "
                + (v.getTipoVehiculo() == null ? "" : v.getTipoVehiculo().getAsientosTotales() + " asientos"));
        modelo.getStyleClass().add("dato");

        // ───── PASO 4: el selector de color (solo colores básicos) ─────
        SelectorColor selector = new SelectorColor(v.getColor());
        selector.valueProperty().addListener((obs, antes, nuevo) -> {
            if (nuevo == null || nuevo == antes) return;
            v.setColor(nuevo.getNombre());
            refrescarDibujo();                     // se redibuja al instante
            cambiarColor.accept(v, nuevo);         // el controlador lo guarda en la BD
        });
        HBox filaColor = new HBox(8, new Label("Color:"), selector);
        filaColor.setAlignment(Pos.CENTER_LEFT);

        getChildren().addAll(marcoImagen, placa, propietario, modelo, filaColor);
    }

    /** Vuelve a dibujar el vehículo con su color actual. */
    private void refrescarDibujo() {
        String tipo = vehiculo.getTipoVehiculo() == TipoVehiculo.COMBI ? "VAN" : "AUTO";
        Color color = Color.web(ColorBasico.desdeTexto(vehiculo.getColor()).getHex());
        marcoImagen.getChildren().setAll(DibujoVehiculo.crear(tipo, color, ANCHO_DIBUJO));
    }

    /** Placa: franja de color arriba (sin país) y el número en grande. */
    private static Node crearPlaca(String numero) {
        Region franja = new Region();
        franja.getStyleClass().add("placa-franja");
        franja.setPrefHeight(6);
        franja.setMaxWidth(Double.MAX_VALUE);
        Label num = new Label(numero);
        num.getStyleClass().add("placa-numero");
        VBox placa = new VBox(franja, num);
        placa.setAlignment(Pos.CENTER);
        placa.getStyleClass().add("placa");
        placa.setMaxWidth(130);
        return placa;
    }

    /** Ícono de persona (cabeza + hombros) dentro de un círculo dorado. */
    private static Node crearIconoPropietario() {
        SVGPath persona = new SVGPath();
        persona.setContent("M12 12a5 5 0 1 0 0-10a5 5 0 0 0 0 10zm0 2c-5 0-9 2.5-9 6v2h18v-2c0-3.5-4-6-9-6z");
        persona.setFill(Color.WHITE);
        persona.setScaleX(0.9);
        persona.setScaleY(0.9);
        Circle fondo = new Circle(17, Color.web("#D4A017"));
        return new StackPane(fondo, persona);
    }
}
