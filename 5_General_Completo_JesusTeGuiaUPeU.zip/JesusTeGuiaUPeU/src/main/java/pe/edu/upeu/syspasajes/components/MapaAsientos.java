/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MapaAsientos.java                                            │
 * │ CAPA    : Componente visual                                            │
 * │ MÓDULO  : Venta                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Dibuja el croquis del vehículo (auto de 5 o van de 11 asientos) y    │
 * │   permite hacer clic en los asientos libres.                           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;

import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

/**
 * Dibuja el croquis del vehículo (vista desde arriba) con sus asientos.
 *  - Auto (5 asientos): chofer + 1 copiloto adelante, 3 atrás = 4 pasajeros.
 *  - Van (11 asientos) : chofer + 2 adelante y filas de 3 atrás = 10 pasajeros.
 * Verde = libre, Amarillo = seleccionado, Rojo = ocupado (vendido o reservado).
 *
 * Los colores se aplican con estilo en línea para que se vean igual con
 * cualquier tema de color que elija el usuario.
 */
public class MapaAsientos extends VBox {

    // Paleta azul / blanco / dorado (cámbiala aquí si quieres otros colores)
    private static final String COLOR_LIBRE = "#1553C7";      // azul  = asiento libre
    private static final String COLOR_SELECCION = "#D4A017";  // dorado = asiento elegido
    private static final String COLOR_OCUPADO = "#8A94A8";    // gris  = asiento ocupado

    private final Set<Integer> seleccionados = new TreeSet<>();
    private Runnable onCambioSeleccion;

    public MapaAsientos() {
        setAlignment(Pos.TOP_CENTER);
        setSpacing(10);
        setPadding(new Insets(10));
        mostrarMensaje("Seleccione una salida de la lista\npara ver sus asientos");
    }

    public void setOnCambioSeleccion(Runnable accion) {
        this.onCambioSeleccion = accion;
    }

    public Set<Integer> getSeleccionados() {
        return Collections.unmodifiableSet(seleccionados);
    }

    public void mostrarMensaje(String mensaje) {
        seleccionados.clear();
        getChildren().clear();
        Label lbl = new Label(mensaje);
        lbl.setWrapText(true);
        lbl.setStyle("-fx-font-size: 14px; -fx-text-alignment: center; -fx-opacity: 0.75;");
        lbl.setPadding(new Insets(60, 10, 60, 10));
        getChildren().add(lbl);
        notificar();
    }

    /**
     * @param tipo       taxi o combi (define colores y distribución)
     * @param capacidad  cantidad de asientos para clientes
     * @param ocupados   asientos ya vendidos o reservados
     * @param placa      placa del vehículo (se muestra en el letrero)
     */
    public void dibujar(TipoVehiculo tipo, int capacidad, Set<Integer> ocupados, String placa) {
        seleccionados.clear();
        getChildren().clear();

        boolean esTaxi = tipo == TipoVehiculo.TAXI;
        String colorCarroceria = esTaxi ? "#FFFFFF" : "#E3ECFC";
        String colorBorde = esTaxi ? "#0A2A66" : "#1553C7";

        // Letrero del techo
        Label letrero = new Label((esTaxi ? "TAXI" : "COMBI") + " UPeU  •  " + placa);
        letrero.setFont(Font.font("System", FontWeight.BOLD, 13));
        letrero.setStyle("-fx-background-color: #0A2A66; -fx-text-fill: " + (esTaxi ? "#D4A017" : "#FFFFFF") + ";"
                + "-fx-padding: 4 14 4 14; -fx-background-radius: 10 10 0 0;");

        // Franja a cuadros (solo taxi)
        Region cuadros = new Region();
        cuadros.setPrefHeight(10);
        cuadros.setMaxWidth(Double.MAX_VALUE);
        cuadros.setStyle(esTaxi
                ? "-fx-background-color: linear-gradient(from 0px 0px to 20px 0px, repeat, #0A2A66 50%, #D4A017 50%);"
                : "-fx-background-color: #D4A017;");

        // Parabrisas
        Region parabrisas = new Region();
        parabrisas.setPrefHeight(26);
        parabrisas.setMaxWidth(Double.MAX_VALUE);
        parabrisas.setStyle("-fx-background-color: linear-gradient(to bottom, #B3E5FC, #4FC3F7);"
                + "-fx-background-radius: 30 30 6 6;");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);

        // Fila 0: chofer a la izquierda (como en Perú)
        grid.add(crearChofer(), 0, 0);

        int adelante = esTaxi ? 1 : 2;
        int nro = 1;
        if (esTaxi) {
            // Taxi: copiloto a la derecha, queda un espacio al centro
            Region espacio = new Region();
            espacio.setPrefSize(56, 56);
            grid.add(espacio, 1, 0);
            grid.add(crearAsiento(nro++, ocupados), 2, 0);
        } else {
            for (int c = 1; c <= adelante && nro <= capacidad; c++) {
                grid.add(crearAsiento(nro++, ocupados), c, 0);
            }
        }
        // Filas traseras de 3 asientos
        int fila = 1;
        while (nro <= capacidad) {
            for (int c = 0; c < 3 && nro <= capacidad; c++) {
                grid.add(crearAsiento(nro++, ocupados), c, fila);
            }
            fila++;
        }

        VBox carroceria = new VBox(8, cuadros, parabrisas, grid);
        carroceria.setAlignment(Pos.TOP_CENTER);
        carroceria.setPadding(new Insets(10, 16, 18, 16));
        carroceria.setMaxWidth(Region.USE_PREF_SIZE);
        carroceria.setStyle("-fx-background-color: " + colorCarroceria + ";"
                + "-fx-background-radius: 34 34 18 18;"
                + "-fx-border-color: " + colorBorde + "; -fx-border-width: 3;"
                + "-fx-border-radius: 34 34 18 18;"
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.35), 12, 0, 0, 4);");

        VBox vehiculo = new VBox(0, letrero, carroceria);
        vehiculo.setAlignment(Pos.TOP_CENTER);

        getChildren().addAll(vehiculo, crearLeyenda());
        notificar();
    }

    private StackPane crearChofer() {
        // Timón dibujado con figuras
        Circle aro = new Circle(17, Color.TRANSPARENT);
        aro.setStroke(Color.web("#424242"));
        aro.setStrokeWidth(4);
        Circle centro = new Circle(5, Color.web("#424242"));
        Line radio1 = new Line(-15, 0, 15, 0);
        radio1.setStrokeWidth(3);
        radio1.setStroke(Color.web("#424242"));
        Line radio2 = new Line(0, 0, 0, 15);
        radio2.setStrokeWidth(3);
        radio2.setStroke(Color.web("#424242"));
        StackPane timon = new StackPane(aro, radio1, radio2, centro);
        StackPane.setAlignment(radio2, Pos.BOTTOM_CENTER);
        timon.setMaxSize(40, 40);

        Label lbl = new Label("Chofer");
        lbl.setStyle("-fx-font-size: 10px; -fx-text-fill: #424242; -fx-font-weight: bold;");
        VBox caja = new VBox(2, timon, lbl);
        caja.setAlignment(Pos.CENTER);

        StackPane chofer = new StackPane(caja);
        chofer.setPrefSize(56, 56);
        chofer.setStyle("-fx-background-color: #BDBDBD; -fx-background-radius: 12 12 6 6;");
        Tooltip.install(chofer, new Tooltip("Asiento del conductor (no se vende)"));
        GridPane.setHalignment(chofer, HPos.CENTER);
        return chofer;
    }

    private Button crearAsiento(int numero, Set<Integer> ocupados) {
        Button b = new Button(String.valueOf(numero));
        b.setFocusTraversable(false);
        b.setPrefSize(56, 56);
        b.setMinSize(56, 56);
        if (ocupados != null && ocupados.contains(numero)) {
            b.setStyle(estilo(COLOR_OCUPADO, "white"));
            b.setDisable(true);
            Tooltip.install(b, new Tooltip("Asiento " + numero + ": ocupado"));
        } else {
            b.setStyle(estilo(COLOR_LIBRE, "white"));
            b.setTooltip(new Tooltip("Asiento " + numero + ": libre (clic para elegir)"));
            b.setOnAction(e -> {
                if (seleccionados.contains(numero)) {
                    seleccionados.remove(numero);
                    b.setStyle(estilo(COLOR_LIBRE, "white"));
                } else {
                    seleccionados.add(numero);
                    b.setStyle(estilo(COLOR_SELECCION, "#212121"));
                }
                notificar();
            });
        }
        return b;
    }

    /** -fx-opacity: 1 evita que el asiento ocupado (deshabilitado) se vea transparente. */
    private String estilo(String fondo, String texto) {
        return "-fx-background-color: " + fondo + "; -fx-text-fill: " + texto + ";"
                + "-fx-font-size: 16px; -fx-font-weight: bold; -fx-opacity: 1;"
                + "-fx-background-radius: 14 14 6 6; -fx-border-radius: 14 14 6 6;"
                + "-fx-border-color: rgba(0,0,0,0.35); -fx-border-width: 2;"
                + "-fx-padding: 0; -fx-cursor: hand;";
    }

    private HBox crearLeyenda() {
        HBox leyenda = new HBox(14,
                itemLeyenda(COLOR_LIBRE, "Libre"),
                itemLeyenda(COLOR_SELECCION, "Seleccionado"),
                itemLeyenda(COLOR_OCUPADO, "Ocupado"));
        leyenda.setAlignment(Pos.CENTER);
        return leyenda;
    }

    private HBox itemLeyenda(String color, String texto) {
        Region cuadro = new Region();
        cuadro.setPrefSize(16, 16);
        cuadro.setMinSize(16, 16);
        cuadro.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 4;");
        HBox h = new HBox(5, cuadro, new Label(texto));
        h.setAlignment(Pos.CENTER_LEFT);
        return h;
    }

    private void notificar() {
        if (onCambioSeleccion != null) onCambioSeleccion.run();
    }
}
