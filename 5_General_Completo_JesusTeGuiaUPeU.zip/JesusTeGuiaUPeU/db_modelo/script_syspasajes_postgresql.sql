-- =====================================================================
--  SysPasajes UPeU "Jesús te guía a la UPeU" - Venta de pasajes Auto y Van
--  Ruta: Universidad UPeU <-> C.C. Plaza de Armas
--  Script GENERADO a partir del modelo modelo_syspasajes.architect
--  (SQL Power Architect -> Tools -> Forward Engineer -> PostgreSQL)
--  11 tablas: perfil, usuario, marca, vehiculo, producto, viaje, cliente,
--             venta_carrito, venta_pasaje, boleto, notificacion
--  Las contraseñas se guardan CIFRADAS con SHA-256 (64 caracteres).
-- =====================================================================

-- Para volver a ejecutar el script desde cero (descomentar):
-- DROP TABLE IF EXISTS public.boleto, public.venta_pasaje, public.venta_carrito, public.notificacion,
--     public.cliente, public.viaje, public.producto, public.vehiculo, public.marca,
--     public.usuario, public.perfil CASCADE;


-- Perfiles de acceso (Root, Administrador, Reporte, Taxista)
CREATE SEQUENCE public.perfil_id_perfil_seq;

CREATE TABLE public.perfil (
                id_perfil INTEGER NOT NULL DEFAULT nextval('public.perfil_id_perfil_seq'),
                nombre VARCHAR(20) NOT NULL,
                codigo VARCHAR(60) NOT NULL,
                CONSTRAINT perfil_pk PRIMARY KEY (id_perfil)
);

ALTER SEQUENCE public.perfil_id_perfil_seq OWNED BY public.perfil.id_perfil;


-- Usuarios del sistema. La clave se guarda CIFRADA con SHA-256
CREATE SEQUENCE public.usuario_id_usuario_seq;

CREATE TABLE public.usuario (
                id_usuario INTEGER NOT NULL DEFAULT nextval('public.usuario_id_usuario_seq'),
                usuario VARCHAR(20) NOT NULL,
                clave VARCHAR(64) NOT NULL,
                estado VARCHAR(10) NOT NULL,
                id_perfil INTEGER NOT NULL,
                CONSTRAINT usuario_pk PRIMARY KEY (id_usuario)
);

ALTER SEQUENCE public.usuario_id_usuario_seq OWNED BY public.usuario.id_usuario;


-- MODULO MARCA: marca del vehiculo (Toyota, Hyundai, Kia, Nissan)
CREATE SEQUENCE public.marca_id_marca_seq;

CREATE TABLE public.marca (
                id_marca INTEGER NOT NULL DEFAULT nextval('public.marca_id_marca_seq'),
                nombre VARCHAR(30) NOT NULL,
                estado VARCHAR(10) NOT NULL,
                CONSTRAINT marca_pk PRIMARY KEY (id_marca)
);

ALTER SEQUENCE public.marca_id_marca_seq OWNED BY public.marca.id_marca;

CREATE UNIQUE INDEX marca_nombre_uk
 ON public.marca
 ( nombre );


-- Flota: auto 5 asientos o van 11 asientos con su propietario
CREATE SEQUENCE public.vehiculo_id_vehiculo_seq;

CREATE TABLE public.vehiculo (
                id_vehiculo INTEGER NOT NULL DEFAULT nextval('public.vehiculo_id_vehiculo_seq'),
                placa VARCHAR(10) NOT NULL,
                tipo_vehiculo VARCHAR(10) NOT NULL,
                id_marca INTEGER NOT NULL,
                modelo VARCHAR(30) NOT NULL,
                conductor VARCHAR(60) NOT NULL,
                telefono_conductor VARCHAR(15),
                color VARCHAR(20) NOT NULL,
                asientos INTEGER NOT NULL,
                estado VARCHAR(10) NOT NULL,
                CONSTRAINT vehiculo_pk PRIMARY KEY (id_vehiculo)
);

ALTER SEQUENCE public.vehiculo_id_vehiculo_seq OWNED BY public.vehiculo.id_vehiculo;

CREATE UNIQUE INDEX vehiculo_placa_uk
 ON public.vehiculo
 ( placa );


-- MODULO PRODUCTO: tarifa del pasaje (tipo de vehiculo + sentido + precio)
CREATE SEQUENCE public.producto_id_producto_seq;

CREATE TABLE public.producto (
                id_producto INTEGER NOT NULL DEFAULT nextval('public.producto_id_producto_seq'),
                nombre VARCHAR(60) NOT NULL,
                tipo_vehiculo VARCHAR(10) NOT NULL,
                sentido VARCHAR(20) NOT NULL,
                precio NUMERIC(10, 2) NOT NULL,
                descripcion VARCHAR(120),
                estado VARCHAR(10) NOT NULL,
                CONSTRAINT producto_pk PRIMARY KEY (id_producto)
);

ALTER SEQUENCE public.producto_id_producto_seq OWNED BY public.producto.id_producto;


-- Salidas programadas de cada vehiculo
CREATE SEQUENCE public.viaje_id_viaje_seq;

CREATE TABLE public.viaje (
                id_viaje INTEGER NOT NULL DEFAULT nextval('public.viaje_id_viaje_seq'),
                id_vehiculo INTEGER NOT NULL,
                sentido VARCHAR(20) NOT NULL,
                fecha DATE NOT NULL,
                hora_salida TIME NOT NULL,
                precio NUMERIC(10, 2) NOT NULL,
                estado VARCHAR(15) NOT NULL,
                id_producto INTEGER,
                CONSTRAINT viaje_pk PRIMARY KEY (id_viaje)
);

ALTER SEQUENCE public.viaje_id_viaje_seq OWNED BY public.viaje.id_viaje;


-- MODULO CLIENTE: persona que compra (DNI consultado en RENIEC)
CREATE TABLE public.cliente (
                dni VARCHAR(12) NOT NULL,
                nombres VARCHAR(80) NOT NULL,
                telefono VARCHAR(15),
                email VARCHAR(80),
                direccion VARCHAR(120),
                tipo_documento VARCHAR(12) NOT NULL,
                CONSTRAINT cliente_pk PRIMARY KEY (dni)
);


-- MODULO VENTA CARRITO: reserva temporal de asientos (15 minutos)
CREATE SEQUENCE public.venta_carrito_id_carrito_seq;

CREATE TABLE public.venta_carrito (
                id_carrito INTEGER NOT NULL DEFAULT nextval('public.venta_carrito_id_carrito_seq'),
                dni VARCHAR(12) NOT NULL,
                id_viaje INTEGER NOT NULL,
                nro_asiento INTEGER NOT NULL,
                precio NUMERIC(10, 2) NOT NULL,
                estado INTEGER NOT NULL,
                id_usuario INTEGER NOT NULL,
                fecha_reg TIMESTAMP NOT NULL,
                CONSTRAINT venta_carrito_pk PRIMARY KEY (id_carrito)
);

ALTER SEQUENCE public.venta_carrito_id_carrito_seq OWNED BY public.venta_carrito.id_carrito;

CREATE UNIQUE INDEX uq_carrito_asiento
 ON public.venta_carrito
 ( id_viaje, nro_asiento );


-- Cabecera de la BOLETA o FACTURA (RUC consultado en SUNAT)
CREATE SEQUENCE public.venta_pasaje_id_venta_seq;

CREATE TABLE public.venta_pasaje (
                id_venta INTEGER NOT NULL DEFAULT nextval('public.venta_pasaje_id_venta_seq'),
                precio_base NUMERIC(10, 2) NOT NULL,
                igv NUMERIC(10, 2) NOT NULL,
                descuento NUMERIC(10, 2) NOT NULL,
                precio_total NUMERIC(10, 2) NOT NULL,
                serie VARCHAR(10) NOT NULL,
                num_doc VARCHAR(12) NOT NULL,
                tipo_doc VARCHAR(20) NOT NULL,
                ruc VARCHAR(11),
                razon_social VARCHAR(100),
                metodo_pago VARCHAR(20) NOT NULL,
                nro_operacion VARCHAR(30),
                monto_recibido NUMERIC(10, 2) NOT NULL,
                vuelto NUMERIC(10, 2) NOT NULL,
                fecha_venta TIMESTAMP NOT NULL,
                dni VARCHAR(12) NOT NULL,
                id_usuario INTEGER NOT NULL,
                CONSTRAINT venta_pasaje_pk PRIMARY KEY (id_venta)
);

ALTER SEQUENCE public.venta_pasaje_id_venta_seq OWNED BY public.venta_pasaje.id_venta;

CREATE UNIQUE INDEX uq_venta_comprobante
 ON public.venta_pasaje
 ( serie, num_doc );


-- Detalle de la venta: un boleto por asiento vendido
CREATE SEQUENCE public.boleto_id_boleto_seq;

CREATE TABLE public.boleto (
                id_boleto INTEGER NOT NULL DEFAULT nextval('public.boleto_id_boleto_seq'),
                id_venta INTEGER NOT NULL,
                id_viaje INTEGER NOT NULL,
                nro_asiento INTEGER NOT NULL,
                precio NUMERIC(10, 2) NOT NULL,
                CONSTRAINT boleto_pk PRIMARY KEY (id_boleto)
);

ALTER SEQUENCE public.boleto_id_boleto_seq OWNED BY public.boleto.id_boleto;

CREATE UNIQUE INDEX uq_boleto_asiento
 ON public.boleto
 ( id_viaje, nro_asiento );


-- Avisos al taxista: mensaje de asiento reservado por cada venta
CREATE SEQUENCE public.notificacion_id_notificacion_seq;

CREATE TABLE public.notificacion (
                id_notificacion INTEGER NOT NULL DEFAULT nextval('public.notificacion_id_notificacion_seq'),
                placa VARCHAR(10) NOT NULL,
                conductor VARCHAR(60) NOT NULL,
                telefono VARCHAR(15),
                mensaje VARCHAR(1000) NOT NULL,
                comprobante VARCHAR(25) NOT NULL,
                fecha_reg TIMESTAMP NOT NULL,
                leido BOOLEAN NOT NULL,
                id_venta INTEGER,
                id_vehiculo INTEGER,
                CONSTRAINT notificacion_pk PRIMARY KEY (id_notificacion)
);

ALTER SEQUENCE public.notificacion_id_notificacion_seq OWNED BY public.notificacion.id_notificacion;


-- ===================== LLAVES FORÁNEAS =====================
ALTER TABLE public.usuario ADD CONSTRAINT perfil_usuario_fk
FOREIGN KEY (id_perfil)
REFERENCES public.perfil (id_perfil)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.vehiculo ADD CONSTRAINT marca_vehiculo_fk
FOREIGN KEY (id_marca)
REFERENCES public.marca (id_marca)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.viaje ADD CONSTRAINT vehiculo_viaje_fk
FOREIGN KEY (id_vehiculo)
REFERENCES public.vehiculo (id_vehiculo)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.venta_carrito ADD CONSTRAINT viaje_venta_carrito_fk
FOREIGN KEY (id_viaje)
REFERENCES public.viaje (id_viaje)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.venta_carrito ADD CONSTRAINT usuario_venta_carrito_fk
FOREIGN KEY (id_usuario)
REFERENCES public.usuario (id_usuario)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.venta_pasaje ADD CONSTRAINT cliente_venta_pasaje_fk
FOREIGN KEY (dni)
REFERENCES public.cliente (dni)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.venta_pasaje ADD CONSTRAINT usuario_venta_pasaje_fk
FOREIGN KEY (id_usuario)
REFERENCES public.usuario (id_usuario)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.boleto ADD CONSTRAINT venta_pasaje_boleto_fk
FOREIGN KEY (id_venta)
REFERENCES public.venta_pasaje (id_venta)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.boleto ADD CONSTRAINT viaje_boleto_fk
FOREIGN KEY (id_viaje)
REFERENCES public.viaje (id_viaje)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.viaje ADD CONSTRAINT producto_viaje_fk
FOREIGN KEY (id_producto)
REFERENCES public.producto (id_producto)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.notificacion ADD CONSTRAINT venta_pasaje_notificacion_fk
FOREIGN KEY (id_venta)
REFERENCES public.venta_pasaje (id_venta)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.notificacion ADD CONSTRAINT vehiculo_notificacion_fk
FOREIGN KEY (id_vehiculo)
REFERENCES public.vehiculo (id_vehiculo)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

-- ===================== DATOS INICIALES =====================
INSERT INTO public.perfil (id_perfil, nombre, codigo) VALUES
 (1, 'Root', 'ROOT'), (2, 'Administrador', 'ADM'), (3, 'Reporte', 'REP'), (4, 'Taxista', 'TAX');

-- Claves CIFRADAS: SHA-256(usuario_en_minusculas + ':' + clave). Nunca se guarda la clave en texto.
INSERT INTO public.usuario (id_usuario, usuario, clave, estado, id_perfil) VALUES
 (1, 'Ronaldo', 'ba99343cbef0f0331ae110c32349c78338d544e634c2d5c0a7c5a0209c285a7e', 'ACTIVO', 1),
 (2, 'mijael',  '4450f3663c65c8cfb55ef95ce372e783f7779640b6171650512fef66b57f4485', 'ACTIVO', 4),
 (3, 'alvaro',  'c92a53abbb36451e21f85c05a5267246924bd87f65b3e8bf95718663d6e9e2c8', 'ACTIVO', 4),
 (4, 'heans',   'e44ccfe4a5c89aecef764e0a5a0344f7c312affa72515a17de56a50b8e2fc193', 'ACTIVO', 4);

INSERT INTO public.marca (id_marca, nombre, estado) VALUES
 (1, 'Toyota', 'ACTIVO'), (2, 'Hyundai', 'ACTIVO'), (3, 'Kia', 'ACTIVO'), (4, 'Nissan', 'ACTIVO');

INSERT INTO public.vehiculo (id_vehiculo, placa, tipo_vehiculo, id_marca, modelo, conductor, telefono_conductor, color, asientos, estado) VALUES
 (1, 'TAX-101', 'TAXI',  1, 'Yaris',  'Mijael Jaret Quispe Vargas',    '917651371', 'Azul',          4,  'ACTIVO'),
 (2, 'TAX-202', 'TAXI',  2, 'Accent', 'Álvaro Layme Urviola',          '940997634', 'Blanco',        4,  'ACTIVO'),
 (3, 'VAN-303', 'COMBI', 1, 'Hiace',  'Heans Gary Livisi Huaynasi',    '992754434', 'Amarillo taxi', 10, 'ACTIVO'),
 (4, 'VAN-404', 'COMBI', 4, 'Urvan',  'Ronaldo Pablo Sucasaca Mamani', '940375781', 'Azul marino',   10, 'ACTIVO');

INSERT INTO public.producto (nombre, tipo_vehiculo, sentido, precio, descripcion, estado) VALUES
 ('Pasaje Auto UPeU -> Plaza', 'TAXI',  'UPEU_PLAZA', 3.00, 'Auto de 5 asientos', 'ACTIVO'),
 ('Pasaje Auto Plaza -> UPeU', 'TAXI',  'PLAZA_UPEU', 3.00, 'Auto de 5 asientos', 'ACTIVO'),
 ('Pasaje Van UPeU -> Plaza',  'COMBI', 'UPEU_PLAZA', 1.50, 'Van de 11 asientos', 'ACTIVO'),
 ('Pasaje Van Plaza -> UPeU',  'COMBI', 'PLAZA_UPEU', 1.50, 'Van de 11 asientos', 'ACTIVO');

-- Ajusta las secuencias despues de insertar con id fijo
SELECT setval('public.perfil_id_perfil_seq', 4);
SELECT setval('public.usuario_id_usuario_seq', 4);
SELECT setval('public.marca_id_marca_seq', 4);
SELECT setval('public.vehiculo_id_vehiculo_seq', 4);

-- ===================== CONSULTAS DE EJEMPLO =====================
-- Vehiculos de cada marca con su propietario
SELECT m.nombre AS marca, v.placa, v.modelo, v.conductor AS propietario, v.color
FROM public.vehiculo v JOIN public.marca m ON m.id_marca = v.id_marca ORDER BY m.nombre, v.placa;

-- Login: se compara la clave CIFRADA
SELECT u.usuario, p.nombre AS perfil FROM public.usuario u JOIN public.perfil p ON p.id_perfil = u.id_perfil
WHERE u.usuario = 'Ronaldo' AND u.clave = 'ba99343cbef0f0331ae110c32349c78338d544e634c2d5c0a7c5a0209c285a7e';
