# Módulo MARCA · Jesús te guía a la UPeU (proyecto independiente)

Este módulo **funciona solo**: tiene su propio `pom.xml`, su propia base de datos H2 y su propia ventana.

**Qué hace:**
- **Pantalla de ingreso** con usuario, contraseña y un **candado animado**: al abrirse se cierra solo con un «clic»;
  si la contraseña es correcta se abre y entra; si es incorrecta tiembla en rojo. Botón **🔒 Salir** para volver.
- CRUD de marcas (solo **nombre** y **estado**; ya no se pide el país): guardar, modificar, eliminar y buscar.
- Al elegir una marca en la tabla, abajo aparecen **sus vehículos** en tarjetas con:
  - el **dibujo del vehículo** (auto de 5 asientos o van de 11 asientos), o una **foto** si se le pone una;
  - la **placa** (sin país: franja de color + número);
  - el **ícono del propietario** con su nombre y celular;
  - un selector para **cambiar el color del vehículo** con **solo colores básicos** (los más usados en el Perú), que se guarda en la base de datos;
  - botones **📷 Foto…** (foto real), **Sin foto** (vuelve al dibujo) y **🗑 Quitar** (saca el vehículo).
- Botón **«+ Agregar vehículo»**: registra un vehículo nuevo en la marca elegida (placa, modelo, tipo auto/van,
  propietario, celular y color), con **vista previa del dibujo**.
- Si una marca no tiene vehículos (por ejemplo, **Kia**), se muestra un aviso con el botón para agregar uno.
- Arriba, el selector **«Color del tablero»** (también con colores básicos) cambia el color de la cabecera, la tabla, los botones y las tarjetas, y lo recuerda.

## Cómo ejecutarlo
1. IntelliJ → **File → Open** → elige la carpeta **04_Marca** (la que tiene el `pom.xml`).
2. Espera a que Maven cargue. Si pregunta, elige **Trust Project**.
3. **File → Project Structure → Project**: SDK **21** y Language level **21** (sin «Preview»).
4. Abre `Launcher.java` → ▶ verde → **Run 'Launcher.main()'**.
5. Sale la pantalla del candado. Ingresa con uno de estos usuarios:

| Usuario | Contraseña | Perfil |
|---|---|---|
| Ronaldo | 1234567 | ADMINISTRADOR |
| mijael | mijael101 | TAXISTA |
| alvaro | alvaro202 | TAXISTA |
| heans | heans303 | TAXISTA |

(El usuario no distingue mayúsculas: `ronaldo` también funciona; la contraseña sí.)

La primera vez se crea `data/marca_v2.mv.db` con 4 marcas y los 4 vehículos de la flota:

| Placa | Marca | Tipo | Propietario | Color inicial |
|---|---|---|---|---|
| TAX-101 | Toyota | Auto · 5 asientos | Mijael Jaret Quispe Vargas | azul |
| TAX-202 | Hyundai | Auto · 5 asientos | Álvaro Layme Urviola | blanco |
| VAN-303 | Toyota | Van · 11 asientos | Heans Gary Livisi Huaynasi | amarillo taxi |
| VAN-404 | Nissan | Van · 11 asientos | Ronaldo Pablo Sucasaca Mamani | azul marino |

## Archivos y para qué sirve cada uno (orden para explicarlo)
| # | Archivo | Capa | Para qué sirve |
|---|---------|------|----------------|
| 0 | `tabla.sql` | Base de datos | Tablas `usuario`, `marca`, `vehiculo` (con color y foto) y `config` |
| 1 | `config/ConexionBD.java` | Configuración | Abre H2, crea las tablas y carga usuarios y datos de ejemplo |
| 1b | `config/Cifrado.java` | Configuración | Cifra las contraseñas con SHA-256 (nunca se guardan en texto) |
| 1c | `model/Usuario.java` · `repository/UsuarioRepository.java` | Model / Repository | El usuario y su búsqueda por nombre de ingreso |
| 1d | `service/ILoginService` + `impl/LoginServiceImp` | Service | Reglas del ingreso (obligatorios, existe, contraseña igual) |
| 1e | `components/Candado.java` | Componente | **Dibuja y anima** el candado (cerrar solo, abrir, temblar) |
| 1f | `controller/LoginController.java` + `view/login.fxml` | Controller / View | La pantalla de ingreso |
| 2 | `model/Marca.java` | Model | Datos de una marca + `validar()` |
| 3 | `model/Vehiculo.java` | Model | Placa, propietario, tipo, color y foto de un vehículo |
| 3b | `model/ColorBasico.java` | Model | **Lista fija de colores básicos** (vehículo y tablero) |
| 4 | `repository/MarcaRepository.java` | Repository | SQL de marcas (listar, guardar, actualizar, eliminar, contar vehículos) |
| 5 | `repository/VehiculoRepository.java` | Repository | Vehículos de una marca, cambiar color, cambiar foto |
| 6 | `repository/ConfigRepository.java` | Repository | Guarda y lee el color del tablero |
| 7 | `service/IMarcaService` + `impl/MarcaServiceImp` | Service | Las 3 reglas de Marca |
| 8 | `service/IVehiculoService` + `impl/VehiculoServiceImp` | Service | Reglas de color (solo colores básicos) y de foto (solo imágenes) |
| 9 | `components/DibujoVehiculo.java` | Componente | **Dibuja** el auto o la van con figuras de JavaFX |
| 10 | `components/TarjetaVehiculo.java` | Componente | Tarjeta: dibujo o foto, placa, ícono del propietario y selectores |
| 10b | `components/DialogoVehiculo.java` | Componente | Ventana «Agregar vehículo» con vista previa del dibujo |
| 10c | `components/SelectorColor.java` | Componente | Lista desplegable con cuadrito de color + nombre (Blanco, Rojo…) |
| 11 | `controller/MarcaController.java` | Controller | Botones, tabla, tarjetas y color del tablero |
| 12 | `resources/view/main_marca.fxml` | View | La pantalla: cabecera, formulario, tabla y zona de vehículos |
| 13 | `resources/css/marca.css` | Estilos | Colores (variable `-color-tablero`) |
| 14 | `MarcaApp.java` + `Launcher.java` | Arranque | Crea los servicios, muestra el **ingreso** y luego la pantalla de marcas |

Cada archivo tiene comentarios **PASO 1, PASO 2…** que explican cada parte.

## CÓMO MODIFICAR TODO (guía para explicar al profesor)

### A) Desde la pantalla, sin tocar código
| Quiero… | Cómo |
|---|---|
| Cambiar el **color de un vehículo** | En su tarjeta, toca el selector **Color** y elige uno de la lista (Blanco, Plata, Gris, Negro, Rojo, Azul, Azul marino, Verde, Amarillo taxi, Guinda). Se redibuja al instante y se guarda en la tabla `vehiculo` (columna `color`). |
| Poner una **foto real** del vehículo | En la tarjeta, toca **📷 Foto…** y elige un .png o .jpg. Para volver al dibujo, toca **Sin foto**. |
| Cambiar el **color del tablero** | Arriba a la derecha, en **Color del tablero**, elige un color (Gris, Negro, Rojo, Azul, Azul marino, Verde, Guinda). Cambian la cabecera, la tabla, los botones y el borde de las tarjetas. **Restablecer** vuelve al azul original. |
| Agregar, cambiar o eliminar una **marca** | Usa el formulario de la izquierda y los botones **Modificar** / **Eliminar** de la tabla. |
| **Agregar un vehículo** a una marca | Elige la marca en la tabla → **+ Agregar vehículo** → llena los datos (la vista previa cambia con el tipo y el color) → **Guardar**. |
| **Salir** / cambiar de usuario | Botón **🔒 Salir** arriba a la derecha: vuelve a la pantalla del candado. |
| **Quitar un vehículo** | En su tarjeta, toca **🗑 Quitar** y confirma. Si la marca se queda sin vehículos, ya se puede eliminar. |

### B) En el código
| Quiero cambiar… | Archivo | Qué editar |
|---|---|---|
| **Agregar o quitar un color básico** | `model/ColorBasico.java` | Agrega una línea, ej. `NARANJA("Naranja", "#EF6C00", true, false),` → (nombre, color, ¿para vehículo?, ¿para tablero?). Aparece solo en las listas. |
| Los **usuarios y contraseñas** | `config/ConexionBD.java` | Las líneas `crearUsuario(cn, "Ronaldo", …, "1234567", "ADMINISTRADOR")`. Luego borra la carpeta `data/` para que se vuelvan a crear. |
| Los **colores o tamaño del candado** | `components/Candado.java` | Constantes `AZUL`, `DORADO`, `ROJO`, `VERDE` y `ESCALA` (PASO 1). |
| La **velocidad de la animación** | `components/Candado.java` | Los `Duration.millis(…)` de `cerrarAuto()`, `abrir()` y `sacudir()`. |
| El **fondo y la tarjeta del ingreso** | `resources/css/marca.css` | Clases `.fondo-login` y `.tarjeta-login`. |
| Los **mensajes del ingreso** | `service/impl/LoginServiceImp.java` | `"Escribe tu usuario"`, `DATOS_INCORRECTOS`… |
| Los **vehículos y propietarios** de ejemplo | `config/ConexionBD.java` | El `INSERT INTO vehiculo …` del PASO 3. Luego borra la carpeta `data/` para que se vuelva a crear. |
| Agregar un **dato nuevo al vehículo** (ej. año) | `tabla.sql` / `ConexionBD` → `Vehiculo.java` → `VehiculoRepository.mapear()` → `TarjetaVehiculo` | Agrega la columna, el atributo con get/set, léelo en `mapear()` y muéstralo con un `Label` en la tarjeta. Cambia `marca_v2` → `marca_v3` en `ConexionBD` para que se cree la base nueva. |
| La **forma** del auto o de la van | `components/DibujoVehiculo.java` | Las cadenas `CARROCERIA_AUTO` / `CARROCERIA_VAN` (coordenadas en un lienzo de 200 × 95) y las ventanas del PASO 4/5. |
| Las **ventanas, llantas o franja** del dibujo | `components/DibujoVehiculo.java` | Constantes `VIDRIO`, `LLANTA`, `DORADO`… del PASO 1. |
| El **tamaño** del dibujo | `components/TarjetaVehiculo.java` | `ANCHO_DIBUJO = 210`. |
| El **ícono del propietario** | `components/TarjetaVehiculo.java` | `crearIconoPropietario()`: el texto del `SVGPath` es el dibujo de la persona; su fondo usa `.icono-fondo` del CSS. |
| La **placa** (colores, letra) | `resources/css/marca.css` | Clases `.placa`, `.placa-franja`, `.placa-numero`. |
| El **color del tablero por defecto** | `service/IVehiculoService.java` y `marca.css` | `COLOR_TABLERO_DEFECTO = "#0A2A66"` y `-color-tablero` en `.raiz`. |
| El **dorado** de los detalles | `resources/css/marca.css` | `-color-dorado: #D4A017;` |
| Qué partes cambian con el color del tablero | `resources/css/marca.css` | Todo lo que dice `-color-tablero` (cabecera, tabla, botones, tarjetas). |
| Una **regla** de marcas | `service/impl/MarcaServiceImp.java` | `validar()` (regla 1 y 2) y `eliminar()` (regla 3). |
| Una **regla** de vehículos (placa, celular…) | `service/impl/VehiculoServiceImp.java` | Método `agregar()` (PASO 5.2). |
| Los **campos** de «Agregar vehículo» | `components/DialogoVehiculo.java` | PASO 1 (campos) y PASO 3 (filas de la cuadrícula). |
| La **pantalla** (ordenar, agregar campos) | `resources/view/main_marca.fxml` | Ábrelo con **Scene Builder**. Si agregas un control con `fx:id`, declara la misma variable con `@FXML` en el controlador. |

### C) Cómo funciona el color del tablero (para explicarlo)
1. En `marca.css` se define una **variable**: `.raiz { -color-tablero: #0A2A66; }`.
2. La cabecera, la tabla y los botones usan esa variable: `-fx-background-color: -color-tablero;`.
3. El selector (`SelectorColor`) solo ofrece `ColorBasico.paraTablero()`. Al elegir un color, el controlador ejecuta `raiz.setStyle("-color-tablero: #XXXXXX;")`. Como todo depende de esa variable, todo cambia a la vez.
4. El servicio lo guarda en la tabla `config` (`clave = color_tablero`), y al abrir de nuevo se lee con `colorTablero()`.

### D) Cómo funciona el color del vehículo
1. La tarjeta tiene un `SelectorColor` con `ColorBasico.paraVehiculo()`. Al elegir un color, llama a `MarcaController.cambiarColor()`.
2. El controlador llama a `VehiculoServiceImp.cambiarColor()`, que **solo acepta colores de la lista básica** y lo guarda con `VehiculoRepository`.
   Si en la base hay un color antiguo que no está en la lista, el selector muestra el básico **más parecido** (`ColorBasico.masCercano`).
3. La tarjeta vuelve a llamar a `DibujoVehiculo.crear(tipo, color, ancho)` y el dibujo sale con el color nuevo.

### E) Cómo funciona el ingreso con candado (para explicarlo)
1. `MarcaApp` muestra primero `login.fxml` con `LoginController`.
2. Al cargar, `LoginController.initialize()` pone el `Candado` y llama a `cerrarAuto()`: el arco baja y se cierra **solo** (animación con `Timeline`).
3. Al presionar **Ingresar** (o Enter), `LoginServiceImp.ingresar()` busca el usuario, cifra la contraseña escrita con SHA-256 y la compara con `clave_hash`.
4. Correcto → `candado.abrir(...)`: el arco sube y gira, y al terminar `MarcaApp` muestra la pantalla de marcas con `setSesion(nombre, perfil, alSalir)`.
5. Incorrecto → mensaje rojo y `candado.sacudir()` (tiembla con `TranslateTransition`).
6. **🔒 Salir** ejecuta `alSalir` y vuelve al ingreso.

## Reglas al agregar un vehículo (VehiculoServiceImp.agregar)
- Placa con formato **ABC-123** y que no se repita.
- Modelo y propietario obligatorios.
- Celular opcional; si se escribe: 9 dígitos que empiezan con 9.
- Tipo AUTO o VAN y un color de la lista básica.
Si algo falla, el mensaje sale en rojo **dentro de la ventana** y no se pierde lo escrito.

## Las 3 reglas del negocio de Marca
1. Los datos deben ser válidos: nombre obligatorio (máx. 30) y estado ACTIVO/INACTIVO.
2. No puede haber dos marcas con el mismo nombre (sin importar mayúsculas).
3. No se elimina una marca que tiene vehículos: se pone **INACTIVO**. Prueba: *Toyota* tiene 2 vehículos y no se puede eliminar; *Kia* sí.

## Conceptos de POO que se ven aquí
| Concepto | Dónde |
|---|---|
| Encapsulamiento | Atributos `private` + get/set en `Marca` y `Vehiculo` |
| Herencia | `TarjetaVehiculo extends VBox`, `Candado extends Group`, `SelectorColor extends ComboBox`, `MarcaApp extends Application` |
| Polimorfismo | `toString()` en `Marca`; `updateItem()` en la celda de botones |
| Interfaces | `IMarcaService`, `IVehiculoService`, `ILoginService`, `TarjetaVehiculo.Acciones` (la tarjeta avisa al controlador), `Consumer<Vehiculo>` en `DialogoVehiculo` |
| Inyección de dependencias | `MarcaApp` crea Repository → Service → Controller y los pasa por el constructor |

## Errores comunes y solución
| Error | Solución |
|-------|----------|
| `invalid source release 21 with --enable-preview` | Project Structure → Language level **21** (no «Preview»). En Settings → Compiler → Java Compiler, borra `--enable-preview`. |
| `faltan los componentes de JavaFX runtime` | Ejecuta **Launcher** (no MarcaApp) o usa `javafx:run`. |
| Clases en rojo / `package javafx does not exist` | Panel Maven → 🔄 **Reload All Maven Projects**. |
| `Database may be already in use` | Cierra la otra ventana del módulo que esté abierta. |
| «Usuario o contraseña incorrectos» | Revisa la tabla de usuarios de arriba (la contraseña distingue mayúsculas). |
| No aparecen las columnas nuevas | Borra la carpeta `data/` (o cambia `marca_v2` por `marca_v3`). |
