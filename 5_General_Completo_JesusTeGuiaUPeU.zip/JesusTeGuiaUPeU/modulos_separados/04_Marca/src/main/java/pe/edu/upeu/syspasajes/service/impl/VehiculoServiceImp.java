/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VehiculoServiceImp.java                                      │
 * │ CAPA    : SERVICE (implementación = reglas)                            │
 * │ MÓDULO  : MARCA (vehículos y apariencia)                               │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Reglas antes de guardar:                                             │
 * │     · el color debe ser uno de los COLORES BÁSICOS (ColorBasico)       │
 * │     · la foto debe ser .png, .jpg, .jpeg o .gif                        │
 * │     · vehículo nuevo: placa ABC-123 sin repetir, modelo y propietario  │
 * │       obligatorios, celular de 9 dígitos que empieza con 9 (opcional), │
 * │       tipo AUTO o VAN                                                  │
 * │   y guarda el color del tablero en la tabla config.                    │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import pe.edu.upeu.syspasajes.model.ColorBasico;
import pe.edu.upeu.syspasajes.model.Vehiculo;
import pe.edu.upeu.syspasajes.repository.ConfigRepository;
import pe.edu.upeu.syspasajes.repository.VehiculoRepository;
import pe.edu.upeu.syspasajes.service.IVehiculoService;

import java.util.List;

public class VehiculoServiceImp implements IVehiculoService {

    private static final String CLAVE_TABLERO = "color_tablero";

    // ───── PASO 1: repositorios por el constructor (inyección de dependencias) ─────
    private final VehiculoRepository vehiculos;
    private final ConfigRepository config;

    public VehiculoServiceImp(VehiculoRepository vehiculos, ConfigRepository config) {
        this.vehiculos = vehiculos;
        this.config = config;
    }

    // ───── PASO 2: listar ─────
    @Override
    public List<Vehiculo> listarPorMarca(Long idMarca) {
        return idMarca == null ? List.of() : vehiculos.listarPorMarca(idMarca);
    }

    // ───── PASO 3: cambiar color (regla: formato #RRGGBB) ─────
    @Override
    public void cambiarColor(Vehiculo v, String colorHex) {
        validarColor(colorHex);
        vehiculos.cambiarColor(v.getIdVehiculo(), colorHex.toUpperCase());
        v.setColor(colorHex.toUpperCase());
    }

    // ───── PASO 4: cambiar o quitar foto (regla: solo imágenes) ─────
    @Override
    public void cambiarFoto(Vehiculo v, String rutaFoto) {
        if (rutaFoto != null && !rutaFoto.toLowerCase().matches(".*\\.(png|jpg|jpeg|gif)$")) {
            throw new IllegalArgumentException("La foto debe ser una imagen .png, .jpg o .gif");
        }
        vehiculos.cambiarFoto(v.getIdVehiculo(), rutaFoto);
        v.setFoto(rutaFoto);
    }

    // ───── PASO 5: AGREGAR un vehículo (con sus reglas) ─────
    @Override
    public Vehiculo agregar(Vehiculo v) {
        // 5.1 limpiar lo escrito (espacios y mayúsculas en la placa)
        v.setPlaca(texto(v.getPlaca()).toUpperCase());
        v.setModelo(texto(v.getModelo()));
        v.setPropietario(texto(v.getPropietario()));
        String cel = texto(v.getCelular());
        v.setCelular(cel.isEmpty() ? null : cel);
        // 5.2 reglas
        if (v.getIdMarca() == null) throw new IllegalArgumentException("Primero elige una marca en la tabla");
        if (!v.getPlaca().matches("[A-Z0-9]{3}-[A-Z0-9]{3}")) throw new IllegalArgumentException("La placa debe tener el formato ABC-123");
        if (vehiculos.existePlaca(v.getPlaca())) throw new IllegalArgumentException("Ya existe un vehículo con la placa " + v.getPlaca());
        if (v.getModelo().isEmpty()) throw new IllegalArgumentException("Escribe el modelo (ej. Yaris)");
        if (v.getPropietario().isEmpty()) throw new IllegalArgumentException("Escribe el nombre del propietario");
        if (v.getCelular() != null && !v.getCelular().matches("9\\d{8}")) throw new IllegalArgumentException("El celular debe tener 9 dígitos y empezar con 9");
        if (!"AUTO".equals(v.getTipo()) && !"VAN".equals(v.getTipo())) throw new IllegalArgumentException("El tipo debe ser AUTO o VAN");
        validarColor(v.getColor());
        v.setColor(v.getColor().toUpperCase());
        // 5.3 guardar
        return vehiculos.guardar(v);
    }

    // ───── PASO 6: QUITAR un vehículo ─────
    @Override
    public void eliminar(Vehiculo v) {
        vehiculos.eliminar(v.getIdVehiculo());
    }

    private static String texto(String s) {
        return s == null ? "" : s.trim();
    }

    // ───── PASO 7: color del tablero ─────
    @Override
    public String colorTablero() {
        return config.leer(CLAVE_TABLERO, COLOR_TABLERO_DEFECTO);
    }

    @Override
    public void guardarColorTablero(String colorHex) {
        validarColor(colorHex);
        config.guardar(CLAVE_TABLERO, colorHex.toUpperCase());
    }

    /** Regla: solo se aceptan los colores básicos de la lista ColorBasico. */
    private void validarColor(String c) {
        boolean esBasico = c != null && java.util.Arrays.stream(ColorBasico.values())
                .anyMatch(b -> b.getHex().equalsIgnoreCase(c));
        if (!esBasico) {
            throw new IllegalArgumentException("Elige uno de los colores básicos de la lista");
        }
    }
}
