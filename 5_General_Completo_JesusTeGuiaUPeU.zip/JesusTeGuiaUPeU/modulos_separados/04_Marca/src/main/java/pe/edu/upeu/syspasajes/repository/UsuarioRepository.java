/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : UsuarioRepository.java                                       │
 * │ CAPA    : REPOSITORY                                                   │
 * │ MÓDULO  : INGRESO (login)                                              │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Busca un usuario por su nombre de ingreso en la tabla "usuario".     │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.config.ConexionBD;
import pe.edu.upeu.syspasajes.model.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

public class UsuarioRepository {

    /** Sin importar mayúsculas: "ronaldo" encuentra "Ronaldo". */
    public Optional<Usuario> buscarPorUsuario(String usuario) {
        String sql = "SELECT * FROM usuario WHERE UPPER(usuario) = UPPER(?)";
        try (Connection cn = ConexionBD.abrir(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, usuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return Optional.empty();
                return Optional.of(new Usuario(rs.getLong("id_usuario"), rs.getString("usuario"),
                        rs.getString("nombre"), rs.getString("clave_hash"), rs.getString("perfil")));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar el usuario: " + e.getMessage(), e);
        }
    }
}
