/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : LoginServiceImp.java                                         │
 * │ CAPA    : SERVICE (implementación)                                     │
 * │ MÓDULO  : INGRESO (login)                                              │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Reglas del ingreso:                                                  │
 * │     1) usuario y contraseña obligatorios                               │
 * │     2) el usuario debe existir                                         │
 * │     3) se cifra la contraseña escrita y se compara con la guardada     │
 * │   Por seguridad, si falla 2 o 3 el mensaje es el mismo: así nadie      │
 * │   puede adivinar qué usuarios existen.                                 │
 * │   Usuarios: Ronaldo / 1234567 · mijael / mijael101 · alvaro / …       │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import pe.edu.upeu.syspasajes.config.Cifrado;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.repository.UsuarioRepository;
import pe.edu.upeu.syspasajes.service.ILoginService;

public class LoginServiceImp implements ILoginService {

    private static final String DATOS_INCORRECTOS = "Usuario o contraseña incorrectos";
    private final UsuarioRepository repo;

    public LoginServiceImp(UsuarioRepository repo) {
        this.repo = repo;
    }

    @Override
    public Usuario ingresar(String usuario, String clave) {
        // PASO 1: obligatorios
        String u = usuario == null ? "" : usuario.trim();
        if (u.isEmpty()) throw new IllegalArgumentException("Escribe tu usuario");
        if (clave == null || clave.isEmpty()) throw new IllegalArgumentException("Escribe tu contraseña");
        // PASO 2: ¿existe?
        Usuario encontrado = repo.buscarPorUsuario(u)
                .orElseThrow(() -> new IllegalArgumentException(DATOS_INCORRECTOS));
        // PASO 3: comparar contraseñas cifradas
        String hashEscrito = Cifrado.sha256(encontrado.getUsuario().toLowerCase() + ":" + clave);
        if (!hashEscrito.equals(encontrado.getClaveHash())) throw new IllegalArgumentException(DATOS_INCORRECTOS);
        return encontrado;
    }
}
