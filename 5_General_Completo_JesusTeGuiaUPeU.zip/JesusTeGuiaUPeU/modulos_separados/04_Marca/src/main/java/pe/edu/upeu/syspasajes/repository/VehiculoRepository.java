/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VehiculoRepository.java                                      │
 * │ CAPA    : REPOSITORY (acceso a datos)                                  │
 * │ MÓDULO  : MARCA (vehículos de cada marca)                              │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   SQL de la tabla "vehiculo":                                          │
 * │     listarPorMarca() → los vehículos de la marca elegida en la tabla   │
 * │     cambiarColor()   → guarda el nuevo color del vehículo              │
 * │     cambiarFoto()    → guarda (o quita) la foto del vehículo           │
 * │     guardar()        → agrega un vehículo nuevo a la marca             │
 * │     eliminar()       → quita un vehículo                               │
 * │     existePlaca()    → ¿ya hay otro vehículo con esa placa?            │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.config.ConexionBD;
import pe.edu.upeu.syspasajes.model.Vehiculo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VehiculoRepository {

    // ───── PASO 1: LISTAR los vehículos de una marca ─────
    public List<Vehiculo> listarPorMarca(Long idMarca) {
        List<Vehiculo> lista = new ArrayList<>();
        String sql = "SELECT * FROM vehiculo WHERE id_marca = ? ORDER BY placa";
        try (Connection cn = ConexionBD.abrir(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setLong(1, idMarca);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar vehículos: " + e.getMessage(), e);
        }
        return lista;
    }

    // ───── PASO 2: CAMBIAR el color de un vehículo ─────
    public void cambiarColor(Long idVehiculo, String colorHex) {
        actualizarCampo("UPDATE vehiculo SET color = ? WHERE id_vehiculo = ?", colorHex, idVehiculo);
    }

    // ───── PASO 3: CAMBIAR (o quitar con null) la foto de un vehículo ─────
    public void cambiarFoto(Long idVehiculo, String rutaFoto) {
        actualizarCampo("UPDATE vehiculo SET foto = ? WHERE id_vehiculo = ?", rutaFoto, idVehiculo);
    }

    // ───── PASO 4: AGREGAR un vehículo nuevo ─────
    public Vehiculo guardar(Vehiculo v) {
        String sql = "INSERT INTO vehiculo(placa, id_marca, modelo, tipo, propietario, celular, color, foto) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection cn = ConexionBD.abrir();
             PreparedStatement ps = cn.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, v.getPlaca());
            ps.setLong(2, v.getIdMarca());
            ps.setString(3, v.getModelo());
            ps.setString(4, v.getTipo());
            ps.setString(5, v.getPropietario());
            ps.setString(6, v.getCelular());
            ps.setString(7, v.getColor());
            ps.setString(8, v.getFoto());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) v.setIdVehiculo(keys.getLong(1));   // id generado por la base de datos
            }
            return v;
        } catch (SQLException e) {
            throw new RuntimeException("Error al guardar el vehículo: " + e.getMessage(), e);
        }
    }

    // ───── PASO 5: QUITAR un vehículo ─────
    public void eliminar(Long idVehiculo) {
        try (Connection cn = ConexionBD.abrir();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM vehiculo WHERE id_vehiculo = ?")) {
            ps.setLong(1, idVehiculo);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al eliminar el vehículo: " + e.getMessage(), e);
        }
    }

    // ───── PASO 6: ¿la placa ya existe? (no se pueden repetir placas) ─────
    public boolean existePlaca(String placa) {
        try (Connection cn = ConexionBD.abrir();
             PreparedStatement ps = cn.prepareStatement("SELECT COUNT(*) FROM vehiculo WHERE UPPER(placa) = UPPER(?)")) {
            ps.setString(1, placa);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar la placa: " + e.getMessage(), e);
        }
    }

    // ───── Ayudantes privados ─────
    private void actualizarCampo(String sql, String valor, Long id) {
        try (Connection cn = ConexionBD.abrir(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, valor);
            ps.setLong(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar el vehículo: " + e.getMessage(), e);
        }
    }

    /** Fila del ResultSet → objeto Vehiculo. */
    private Vehiculo mapear(ResultSet rs) throws SQLException {
        return new Vehiculo(
                rs.getLong("id_vehiculo"), rs.getString("placa"), rs.getLong("id_marca"),
                rs.getString("modelo"), rs.getString("tipo"), rs.getString("propietario"),
                rs.getString("celular"), rs.getString("color"), rs.getString("foto"));
    }
}
