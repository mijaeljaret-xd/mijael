/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MarcaApp.java                                                │
 * │ CAPA    : ARRANQUE de la aplicación                                    │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Es el "main" del módulo. En orden:                                   │
 * │     1) prepara la base de datos (tablas + usuarios + datos de ejemplo) │
 * │     2) crea los servicios (Repository → Service)                       │
 * │        (INYECCIÓN DE DEPENDENCIAS: cada uno recibe al anterior)        │
 * │     3) muestra la pantalla de INGRESO (login.fxml) con el candado      │
 * │     4) si el ingreso es correcto, muestra main_marca.fxml              │
 * │     5) el botón "Salir" vuelve al ingreso                              │
 * │   ► En IntelliJ ejecuta la clase Launcher (botón ▶ verde).             │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import pe.edu.upeu.syspasajes.config.ConexionBD;
import pe.edu.upeu.syspasajes.controller.LoginController;
import pe.edu.upeu.syspasajes.controller.MarcaController;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.repository.ConfigRepository;
import pe.edu.upeu.syspasajes.repository.MarcaRepository;
import pe.edu.upeu.syspasajes.repository.UsuarioRepository;
import pe.edu.upeu.syspasajes.repository.VehiculoRepository;
import pe.edu.upeu.syspasajes.service.ILoginService;
import pe.edu.upeu.syspasajes.service.IMarcaService;
import pe.edu.upeu.syspasajes.service.IVehiculoService;
import pe.edu.upeu.syspasajes.service.impl.LoginServiceImp;
import pe.edu.upeu.syspasajes.service.impl.MarcaServiceImp;
import pe.edu.upeu.syspasajes.service.impl.VehiculoServiceImp;

import java.io.IOException;

public class MarcaApp extends Application {   // HERENCIA: MarcaApp "es una" aplicación JavaFX

    private Stage ventana;
    private ILoginService loginServicio;
    private IMarcaService marcaServicio;
    private IVehiculoService vehiculoServicio;

    @Override
    public void start(Stage ventana) throws Exception {
        this.ventana = ventana;
        // ───── PASO 1: preparar la base de datos ─────
        ConexionBD.inicializar();

        // ───── PASO 2: crear las capas (Repository → Service) ─────
        loginServicio = new LoginServiceImp(new UsuarioRepository());
        marcaServicio = new MarcaServiceImp(new MarcaRepository());
        vehiculoServicio = new VehiculoServiceImp(new VehiculoRepository(), new ConfigRepository());

        // ───── PASO 3: primero la pantalla de ingreso ─────
        ventana.setTitle("Jesús te guía a la UPeU - Módulo Marca");
        mostrarLogin();
        ventana.show();
    }

    /** Pantalla de ingreso: usuario, contraseña y el candado animado. */
    private void mostrarLogin() throws IOException {
        LoginController controlador = new LoginController(loginServicio, this::mostrarMarca);
        ponerPantalla("/view/login.fxml", controlador, 520, 700);
    }

    // ───── PASO 4: ingreso correcto → pantalla de marcas ─────
    private void mostrarMarca(Usuario usuario) {
        try {
            MarcaController controlador = new MarcaController(marcaServicio, vehiculoServicio);
            ponerPantalla("/view/main_marca.fxml", controlador, 1120, 820);
            // PASO 5: le decimos quién entró y qué hacer al presionar "Salir"
            controlador.setSesion(usuario.getNombre(), usuario.getPerfil(), () -> {
                try {
                    mostrarLogin();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        } catch (IOException e) {
            throw new RuntimeException("No se pudo abrir la pantalla de marcas", e);
        }
    }

    /** Carga un FXML, le pone NUESTRO controlador, los colores (marca.css) y lo muestra. */
    private void ponerPantalla(String fxml, Object controlador, double ancho, double alto) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
        loader.setControllerFactory(tipo -> controlador);   // usa el controlador que ya tiene el servicio
        Parent raiz = loader.load();
        Scene escena = new Scene(raiz, ancho, alto);
        escena.getStylesheets().add(getClass().getResource("/css/marca.css").toExternalForm());
        ventana.setScene(escena);
        ventana.centerOnScreen();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
