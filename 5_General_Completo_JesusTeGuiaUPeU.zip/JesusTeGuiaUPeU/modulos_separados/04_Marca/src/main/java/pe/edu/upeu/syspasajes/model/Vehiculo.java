/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Vehiculo.java                                                │
 * │ CAPA    : MODEL (modelo de datos)                                      │
 * │ MÓDULO  : MARCA (vehículos de cada marca)                              │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Representa UN vehículo de la flota. Pertenece a una marca            │
 * │   (idMarca) y guarda lo que se muestra en la tarjeta del vehículo:     │
 * │     placa       → el letrero tipo placa peruana                        │
 * │     propietario → nombre junto al ícono de persona                     │
 * │     tipo        → AUTO (5 asientos) o VAN (11 asientos): cambia el     │
 * │                   dibujo                                               │
 * │     color       → color del dibujo (se cambia con el selector)         │
 * │     foto        → ruta de una foto real (opcional)                     │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

public class Vehiculo {

    // ───── PASO 1: atributos privados (ENCAPSULAMIENTO) ─────
    private Long idVehiculo;
    private String placa;
    private Long idMarca;
    private String modelo;
    private String tipo;          // "AUTO" o "VAN"
    private String propietario;
    private String celular;
    private String color;         // hexadecimal: "#1553C7"
    private String foto;          // ruta del archivo de imagen o null

    // ───── PASO 2: constructores ─────
    public Vehiculo() {
    }

    public Vehiculo(Long idVehiculo, String placa, Long idMarca, String modelo, String tipo,
                    String propietario, String celular, String color, String foto) {
        this.idVehiculo = idVehiculo;
        this.placa = placa;
        this.idMarca = idMarca;
        this.modelo = modelo;
        this.tipo = tipo;
        this.propietario = propietario;
        this.celular = celular;
        this.color = color;
        this.foto = foto;
    }

    // ───── PASO 3: getters y setters ─────
    public Long getIdVehiculo() { return idVehiculo; }
    public void setIdVehiculo(Long idVehiculo) { this.idVehiculo = idVehiculo; }
    public String getPlaca() { return placa; }
    public void setPlaca(String placa) { this.placa = placa; }
    public Long getIdMarca() { return idMarca; }
    public void setIdMarca(Long idMarca) { this.idMarca = idMarca; }
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getPropietario() { return propietario; }
    public void setPropietario(String propietario) { this.propietario = propietario; }
    public String getCelular() { return celular; }
    public void setCelular(String celular) { this.celular = celular; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public String getFoto() { return foto; }
    public void setFoto(String foto) { this.foto = foto; }

    // ───── PASO 4: ayudas para mostrar ─────
    /** "Auto · 5 asientos" o "Van · 11 asientos". */
    public String getTipoTexto() {
        return "VAN".equals(tipo) ? "Van · 11 asientos" : "Auto · 5 asientos";
    }

    public boolean tieneFoto() {
        return foto != null && !foto.isBlank();
    }
}
