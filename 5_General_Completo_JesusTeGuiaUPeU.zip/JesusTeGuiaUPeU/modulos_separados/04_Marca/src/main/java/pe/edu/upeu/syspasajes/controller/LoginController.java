/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : LoginController.java                                         │
 * │ CAPA    : CONTROLLER                                                   │
 * │ MÓDULO  : INGRESO (login)                                              │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Une la pantalla login.fxml con el servicio de ingreso:               │
 * │     1) al abrir, el candado se cierra solo (animación)                 │
 * │     2) botón Ingresar o tecla Enter → revisa usuario y contraseña      │
 * │     3) correcto  → el candado se abre y entra al módulo Marca          │
 * │        incorrecto → mensaje rojo y el candado tiembla                  │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import pe.edu.upeu.syspasajes.components.Candado;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.service.ILoginService;

import java.util.function.Consumer;

public class LoginController {

    // ───── PASO 1: lo que llega desde MarcaApp ─────
    private final ILoginService servicio;
    private final Consumer<Usuario> alIngresar;   // qué hacer cuando el ingreso es correcto

    // ───── PASO 2: los controles de login.fxml (mismo fx:id) ─────
    @FXML private StackPane cajaCandado;
    @FXML private TextField txtUsuario;
    @FXML private PasswordField txtClave;
    @FXML private TextField txtClaveVisible;   // la misma clave pero visible
    @FXML private CheckBox chkVer;
    @FXML private Button btnIngresar;
    @FXML private Label lblMensaje;

    private final Candado candado = new Candado();

    public LoginController(ILoginService servicio, Consumer<Usuario> alIngresar) {
        this.servicio = servicio;
        this.alIngresar = alIngresar;
    }

    // ───── PASO 3: se ejecuta solo al cargar la pantalla ─────
    @FXML
    public void initialize() {
        cajaCandado.getChildren().add(candado);
        // "Ver contraseña": los dos campos comparten el texto; se muestra uno u otro
        txtClaveVisible.textProperty().bindBidirectional(txtClave.textProperty());
        txtClaveVisible.visibleProperty().bind(chkVer.selectedProperty());
        txtClaveVisible.managedProperty().bind(chkVer.selectedProperty());
        txtClave.visibleProperty().bind(chkVer.selectedProperty().not());
        txtClave.managedProperty().bind(chkVer.selectedProperty().not());
        // Animación automática y cursor en "Usuario"
        Platform.runLater(() -> {
            candado.cerrarAuto();
            txtUsuario.requestFocus();
        });
    }

    // ───── PASO 4: botón Ingresar (onAction="#ingresar") o Enter ─────
    @FXML
    public void ingresar() {
        try {
            Usuario u = servicio.ingresar(txtUsuario.getText(), txtClave.getText());
            lblMensaje.getStyleClass().setAll("msg-ok");
            lblMensaje.setText("🔓 Bienvenido, " + u.getNombre());
            btnIngresar.setDisable(true);                 // evita doble clic
            candado.abrir(() -> alIngresar.accept(u));    // se abre y luego entra
        } catch (IllegalArgumentException ex) {
            lblMensaje.getStyleClass().setAll("msg-error");
            lblMensaje.setText("🔒 " + ex.getMessage());
            candado.sacudir();
            txtClave.clear();
            txtClave.requestFocus();
        }
    }
}
