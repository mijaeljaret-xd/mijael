/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ILoginService.java                                           │
 * │ CAPA    : SERVICE (interfaz)                                           │
 * │ MÓDULO  : INGRESO (login)                                              │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Contrato del ingreso: revisar usuario y contraseña.                  │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.model.Usuario;

public interface ILoginService {

    /**
     * Devuelve el usuario si los datos son correctos.
     * Si no, lanza IllegalArgumentException con el mensaje para mostrar.
     */
    Usuario ingresar(String usuario, String clave);
}
