/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MarcaServiceImp.java                                         │
 * │ CAPA    : SERVICE (implementación = reglas del negocio)                │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Aplica las REGLAS antes de tocar la base de datos:                   │
 * │     Regla 1: los datos deben ser válidos (Marca.validar()).            │
 * │     Regla 2: no puede haber dos marcas con el mismo nombre.            │
 * │     Regla 3: no se elimina una marca que tiene vehículos               │
 * │              (en ese caso se pone INACTIVO).                           │
 * │   Si una regla falla lanza una excepción con el mensaje para el        │
 * │   usuario; el controlador lo muestra en pantalla.                      │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import pe.edu.upeu.syspasajes.model.Marca;
import pe.edu.upeu.syspasajes.repository.MarcaRepository;
import pe.edu.upeu.syspasajes.service.IMarcaService;

import java.util.List;
import java.util.Optional;

public class MarcaServiceImp implements IMarcaService {   // "implements" = cumple el contrato

    // ───── PASO 1: el repositorio llega por el CONSTRUCTOR (inyección de dependencias) ─────
    private final MarcaRepository repo;

    public MarcaServiceImp(MarcaRepository repo) {
        this.repo = repo;
    }

    // ───── PASO 2: LISTAR ─────
    @Override
    public List<Marca> listar() {
        return repo.listar();
    }

    // ───── PASO 3: GUARDAR (con reglas 1 y 2) ─────
    @Override
    public Marca guardar(Marca marca) {
        limpiar(marca);
        validar(marca, null);          // null = es nueva, todavía no tiene id
        return repo.guardar(marca);
    }

    // ───── PASO 4: ACTUALIZAR (con reglas 1 y 2) ─────
    @Override
    public Marca actualizar(Marca marca) {
        if (marca.getIdMarca() == null) throw new IllegalArgumentException("Falta el id de la marca a actualizar");
        limpiar(marca);
        validar(marca, marca.getIdMarca());
        return repo.actualizar(marca);
    }

    // ───── PASO 5: ELIMINAR (con regla 3) ─────
    @Override
    public void eliminar(Long idMarca) {
        int vehiculos = repo.contarVehiculos(idMarca);
        if (vehiculos > 0) {
            throw new IllegalStateException("La marca tiene " + vehiculos
                    + " vehículo(s) registrado(s). No se puede eliminar: márquela como INACTIVO.");
        }
        repo.eliminar(idMarca);
    }

    @Override
    public Optional<Marca> buscarPorNombre(String nombre) {
        return repo.buscarPorNombre(nombre);
    }

    @Override
    public int contarVehiculos(Long idMarca) {
        return repo.contarVehiculos(idMarca);
    }

    // ───── Ayudantes privados ─────
    /** Quita espacios de más al nombre. */
    private void limpiar(Marca m) {
        if (m.getNombre() != null) m.setNombre(m.getNombre().trim());
    }

    /** Regla 1 (datos válidos) y Regla 2 (nombre sin repetir). */
    private void validar(Marca m, Long idActual) {
        String error = m.validar();                                  // Regla 1
        if (error != null) throw new IllegalArgumentException(error);
        Optional<Marca> otra = repo.buscarPorNombre(m.getNombre());   // Regla 2
        if (otra.isPresent() && !otra.get().getIdMarca().equals(idActual)) {
            throw new IllegalArgumentException("Ya existe la marca " + m.getNombre());
        }
    }
}
