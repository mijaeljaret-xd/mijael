/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Marca.java                                                   │
 * │ CAPA    : MODEL (modelo de datos)                                      │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Representa UNA marca de vehículo (Toyota, Hyundai, Kia, Nissan).     │
 * │   Cada atributo es una columna de la tabla "marca":                    │
 * │       idMarca    ↔ id_marca      (número automático)                   │
 * │       nombre     ↔ nombre        (obligatorio, máx. 30 letras)         │
 * │       estado     ↔ estado        (ACTIVO o INACTIVO)                   │
 * │   También sabe VALIDARSE a sí misma (método validar()).                │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

public class Marca {

    // ───── PASO 1: los ATRIBUTOS (privados = ENCAPSULAMIENTO) ─────
    // Nadie puede cambiarlos directamente; se usa get/set.
    private Long idMarca;
    private String nombre;
    private String estado;

    // ───── PASO 2: los CONSTRUCTORES ─────
    /** Constructor vacío: lo usa JavaFX y el repositorio. */
    public Marca() {
    }

    /** Constructor completo: crea la marca con todos sus datos de una vez. */
    public Marca(Long idMarca, String nombre, String estado) {
        this.idMarca = idMarca;
        this.nombre = nombre;
        this.estado = estado;
    }

    // ───── PASO 3: GETTERS y SETTERS (leer y cambiar cada atributo) ─────
    // La tabla de la pantalla usa los getters: columna "nombre" → getNombre().
    public Long getIdMarca() { return idMarca; }
    public void setIdMarca(Long idMarca) { this.idMarca = idMarca; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    // ───── PASO 4: VALIDACIÓN (reglas de los datos) ─────
    /**
     * Revisa que los datos estén bien ANTES de guardar.
     * @return null si todo está bien; si no, el mensaje de error para mostrar.
     */
    public String validar() {
        if (nombre == null || nombre.isBlank()) return "El nombre de la marca es obligatorio";
        if (nombre.trim().length() > 30) return "La marca admite máximo 30 caracteres";
        if (!"ACTIVO".equals(estado) && !"INACTIVO".equals(estado)) return "El estado debe ser ACTIVO o INACTIVO";
        return null;   // sin errores
    }

    // ───── PASO 5: toString() (POLIMORFISMO: sobrescribe el de Object) ─────
    /** Cuando la marca aparece en un ComboBox se ve solo su nombre: "Toyota". */
    @Override
    public String toString() {
        return nombre;
    }
}
