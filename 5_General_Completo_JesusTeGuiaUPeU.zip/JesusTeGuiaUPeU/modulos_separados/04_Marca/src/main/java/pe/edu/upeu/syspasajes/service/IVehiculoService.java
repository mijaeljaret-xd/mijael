/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IVehiculoService.java                                        │
 * │ CAPA    : SERVICE (interfaz = "contrato")                              │
 * │ MÓDULO  : MARCA (vehículos y apariencia)                               │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   QUÉ se puede hacer con los vehículos de una marca y con el color     │
 * │   del tablero.                                                         │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.model.Vehiculo;

import java.util.List;

public interface IVehiculoService {

    /** Color del tablero si nunca se cambió: azul oscuro del proyecto. */
    String COLOR_TABLERO_DEFECTO = "#0A2A66";

    /** Vehículos de la marca elegida. */
    List<Vehiculo> listarPorMarca(Long idMarca);

    /** Cambia el color del vehículo (formato #RRGGBB). */
    void cambiarColor(Vehiculo vehiculo, String colorHex);

    /** Pone una foto al vehículo (ruta) o la quita (null). */
    void cambiarFoto(Vehiculo vehiculo, String rutaFoto);

    /** Agrega un vehículo a una marca (valida placa, modelo, propietario, celular y color). */
    Vehiculo agregar(Vehiculo vehiculo);

    /** Quita un vehículo de la flota. */
    void eliminar(Vehiculo vehiculo);

    /** Color guardado del tablero. */
    String colorTablero();

    /** Guarda el nuevo color del tablero. */
    void guardarColorTablero(String colorHex);
}
