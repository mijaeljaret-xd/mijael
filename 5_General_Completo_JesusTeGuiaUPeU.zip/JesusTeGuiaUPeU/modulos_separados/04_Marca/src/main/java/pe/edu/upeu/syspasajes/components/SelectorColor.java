/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : SelectorColor.java                                           │
 * │ CAPA    : COMPONENTES visuales                                         │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Lista desplegable que SOLO muestra los colores básicos (ColorBasico) │
 * │   con un cuadradito del color y su nombre:  ■ Rojo                     │
 * │   Se usa para el color del vehículo y para el color del tablero.       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.scene.control.ComboBox;
import javafx.scene.control.ListCell;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import pe.edu.upeu.syspasajes.model.ColorBasico;

import java.util.List;

public class SelectorColor extends ComboBox<ColorBasico> {   // HERENCIA: es un ComboBox

    /**
     * @param opciones     colores que se pueden elegir (ColorBasico.paraVehiculo() o paraTablero())
     * @param colorActual  código guardado; se marca el color de la lista más parecido
     */
    public SelectorColor(List<ColorBasico> opciones, String colorActual) {
        getItems().setAll(opciones);
        setValue(ColorBasico.masCercano(colorActual, opciones));
        setCellFactory(lista -> new Celda());   // cómo se ve cada opción de la lista
        setButtonCell(new Celda());             // cómo se ve la opción elegida
        setPrefWidth(160);
    }

    /** Hex del color elegido, ej. "#C62828". */
    public String getHex() {
        return getValue() == null ? null : getValue().getHex();
    }

    /** Fila de la lista: cuadradito de color + nombre (POLIMORFISMO: sobrescribe updateItem). */
    private static class Celda extends ListCell<ColorBasico> {
        @Override
        protected void updateItem(ColorBasico c, boolean vacio) {
            super.updateItem(c, vacio);
            if (vacio || c == null) {
                setText(null);
                setGraphic(null);
            } else {
                Rectangle cuadro = new Rectangle(16, 16, Color.web(c.getHex()));
                cuadro.setArcWidth(4);
                cuadro.setArcHeight(4);
                cuadro.setStroke(Color.web("#8A94A8"));
                setGraphic(cuadro);
                setText(c.getNombre());
            }
        }
    }
}
