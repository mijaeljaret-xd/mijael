/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MarcaRepository.java                                         │
 * │ CAPA    : REPOSITORY (acceso a datos)                                  │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Es el ÚNICO lugar donde se escribe SQL para la tabla "marca".        │
 * │   Convierte filas de la base de datos en objetos Marca y viceversa.    │
 * │     listar()          → SELECT * FROM marca                            │
 * │     buscarPorId()     → SELECT ... WHERE id_marca = ?                  │
 * │     buscarPorNombre() → SELECT ... WHERE UPPER(nombre) = UPPER(?)      │
 * │     guardar()         → INSERT INTO marca ...                          │
 * │     actualizar()      → UPDATE marca SET ...                           │
 * │     eliminar()        → DELETE FROM marca ...                          │
 * │     contarVehiculos() → SELECT COUNT(*) FROM vehiculo ...              │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.config.ConexionBD;
import pe.edu.upeu.syspasajes.model.Marca;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MarcaRepository {

    // ───── PASO 1: LEER todas las marcas (la "R" de CRUD) ─────
    public List<Marca> listar() {
        List<Marca> lista = new ArrayList<>();
        String sql = "SELECT * FROM marca ORDER BY nombre";
        // try-with-resources: la conexión se cierra sola al terminar, aunque haya error
        try (Connection cn = ConexionBD.abrir();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {            // recorre fila por fila
                lista.add(mapear(rs));     // cada fila → un objeto Marca
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar marcas: " + e.getMessage(), e);
        }
        return lista;
    }

    // ───── PASO 2: BUSCAR una marca ─────
    public Optional<Marca> buscarPorId(Long id) {
        return buscarUna("SELECT * FROM marca WHERE id_marca = ?", id);
    }

    /** Sin importar mayúsculas: "toyota" encuentra "Toyota" (para no repetir nombres). */
    public Optional<Marca> buscarPorNombre(String nombre) {
        return buscarUna("SELECT * FROM marca WHERE UPPER(nombre) = UPPER(?)", nombre);
    }

    // ───── PASO 3: GUARDAR una marca nueva (la "C" de CRUD) ─────
    public Marca guardar(Marca m) {
        // Los "?" son PARÁMETROS: el valor viaja aparte del SQL → evita la INYECCIÓN SQL
        String sql = "INSERT INTO marca(nombre, estado) VALUES (?, ?)";
        try (Connection cn = ConexionBD.abrir();
             PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, m.getNombre());       // 1er "?"
            ps.setString(2, m.getEstado());       // 2do "?"
            ps.executeUpdate();
            // La base de datos genera el id (1, 2, 3...): lo leemos y se lo damos al objeto
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) m.setIdMarca(keys.getLong(1));
            }
            return m;
        } catch (SQLException e) {
            throw new RuntimeException("Error al guardar la marca: " + e.getMessage(), e);
        }
    }

    // ───── PASO 4: ACTUALIZAR una marca (la "U" de CRUD) ─────
    public Marca actualizar(Marca m) {
        String sql = "UPDATE marca SET nombre = ?, estado = ? WHERE id_marca = ?";
        try (Connection cn = ConexionBD.abrir(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, m.getNombre());
            ps.setString(2, m.getEstado());
            ps.setLong(3, m.getIdMarca());
            ps.executeUpdate();
            return m;
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar la marca: " + e.getMessage(), e);
        }
    }

    // ───── PASO 5: ELIMINAR una marca (la "D" de CRUD) ─────
    public void eliminar(Long id) {
        try (Connection cn = ConexionBD.abrir();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM marca WHERE id_marca = ?")) {
            ps.setLong(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al eliminar la marca: " + e.getMessage(), e);
        }
    }

    // ───── PASO 6: CONTAR cuántos vehículos usan la marca (para la regla de eliminar) ─────
    public int contarVehiculos(Long idMarca) {
        try (Connection cn = ConexionBD.abrir();
             PreparedStatement ps = cn.prepareStatement("SELECT COUNT(*) FROM vehiculo WHERE id_marca = ?")) {
            ps.setLong(1, idMarca);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al contar vehículos: " + e.getMessage(), e);
        }
    }

    // ───── Ayudantes privados ─────
    /** Ejecuta un SELECT que devuelve como máximo una fila. */
    private Optional<Marca> buscarUna(String sql, Object valor) {
        try (Connection cn = ConexionBD.abrir(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setObject(1, valor);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapear(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar la marca: " + e.getMessage(), e);
        }
    }

    /** Convierte la fila actual del ResultSet en un objeto Marca (columna → atributo). */
    private Marca mapear(ResultSet rs) throws SQLException {
        return new Marca(
                rs.getLong("id_marca"),
                rs.getString("nombre"),
                rs.getString("estado"));
    }
}
