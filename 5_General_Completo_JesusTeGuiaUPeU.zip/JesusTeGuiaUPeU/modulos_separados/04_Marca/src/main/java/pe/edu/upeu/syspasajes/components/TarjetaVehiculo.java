/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : TarjetaVehiculo.java                                         │
 * │ CAPA    : COMPONENTES visuales                                         │
 * │ MÓDULO  : MARCA (tarjeta de cada vehículo)                             │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Arma la TARJETA que se ve debajo de la tabla de marcas:              │
 * │     ┌─────────────────────────────┐                                    │
 * │     │   [ dibujo o foto ]         │  ← DibujoVehiculo o la foto        │
 * │     │   [ TAX-101 ]               │  ← placa                           │
 * │     │   👤 Mijael … · 917651371   │  ← ícono del propietario           │
 * │     │   Yaris · Auto · 5 asientos │                                    │
 * │     │   Color: [■ Rojo ▾]         │  ← solo colores básicos            │
 * │     │ [Foto…] [Sin foto] [Quitar] │  ← foto / dibujo / quitar vehículo │
 * │     └─────────────────────────────┘                                    │
 * │   Los botones avisan al controlador (interfaz Acciones), que es quien  │
 * │   llama al servicio y guarda en la base de datos.                      │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.SVGPath;
import pe.edu.upeu.syspasajes.model.ColorBasico;
import pe.edu.upeu.syspasajes.model.Vehiculo;

import java.io.File;

public class TarjetaVehiculo extends VBox {   // HERENCIA: la tarjeta "es un" VBox

    /** Lo que la tarjeta le pide al controlador (el controlador decide qué hacer). */
    public interface Acciones {
        void cambiarColor(Vehiculo v, Color nuevo);
        void elegirFoto(Vehiculo v);
        void quitarFoto(Vehiculo v);
        void eliminarVehiculo(Vehiculo v);
    }

    private static final double ANCHO_DIBUJO = 210;
    private final StackPane marcoImagen = new StackPane();
    private final Vehiculo vehiculo;

    public TarjetaVehiculo(Vehiculo v, Acciones acciones) {
        this.vehiculo = v;
        getStyleClass().add("tarjeta-vehiculo");
        setSpacing(8);
        setAlignment(Pos.TOP_CENTER);
        setPrefWidth(250);

        // ───── PASO 1: la imagen (foto si tiene, si no el dibujo) ─────
        marcoImagen.setPrefSize(ANCHO_DIBUJO + 10, 110);
        marcoImagen.getStyleClass().add("marco-imagen");
        refrescarImagen();

        // ───── PASO 2: la placa ─────
        Node placa = crearPlaca(v.getPlaca());

        // ───── PASO 3: el propietario con su ícono ─────
        Label nombre = new Label(v.getPropietario());
        nombre.getStyleClass().add("propietario");
        nombre.setWrapText(true);
        Label celular = new Label(v.getCelular() == null ? "" : "Cel. " + v.getCelular());
        celular.getStyleClass().add("dato");
        HBox propietario = new HBox(8, crearIconoPropietario(), new VBox(1, nombre, celular));
        propietario.setAlignment(Pos.CENTER_LEFT);

        Label modelo = new Label(v.getModelo() + " · " + v.getTipoTexto());
        modelo.getStyleClass().add("dato");

        // ───── PASO 4: el selector de color del vehículo (solo colores básicos) ─────
        SelectorColor selector = new SelectorColor(ColorBasico.paraVehiculo(), v.getColor());
        selector.getStyleClass().add("selector-color");
        selector.setOnAction(e -> {
            acciones.cambiarColor(vehiculo, Color.web(selector.getHex()));
            refrescarImagen();                      // vuelve a dibujar con el color nuevo
        });
        HBox filaColor = new HBox(8, new Label("Color:"), selector);
        filaColor.setAlignment(Pos.CENTER_LEFT);

        // ───── PASO 5: botones de foto ─────
        Button btnFoto = new Button("📷 Foto…");
        Button btnQuitar = new Button("Sin foto");
        Button btnEliminar = new Button("🗑 Quitar");
        btnFoto.getStyleClass().add("btn-fila");
        btnQuitar.getStyleClass().add("btn-fila");
        btnEliminar.getStyleClass().add("btn-fila-peligro");
        btnFoto.setOnAction(e -> { acciones.elegirFoto(vehiculo); refrescarImagen(); });
        btnQuitar.setOnAction(e -> { acciones.quitarFoto(vehiculo); refrescarImagen(); });
        btnEliminar.setOnAction(e -> acciones.eliminarVehiculo(vehiculo));   // el controlador confirma y recarga
        HBox filaFoto = new HBox(6, btnFoto, btnQuitar, btnEliminar);

        getChildren().addAll(marcoImagen, placa, propietario, modelo, filaColor, filaFoto);
    }

    /** Muestra la foto si existe el archivo; si no, el dibujo con el color actual. */
    private void refrescarImagen() {
        Node imagen;
        File archivo = vehiculo.tieneFoto() ? new File(vehiculo.getFoto()) : null;
        if (archivo != null && archivo.exists()) {
            ImageView iv = new ImageView(new Image(archivo.toURI().toString(), ANCHO_DIBUJO, 105, true, true));
            imagen = iv;
        } else {
            imagen = DibujoVehiculo.crear(vehiculo.getTipo(), Color.web(vehiculo.getColor()), ANCHO_DIBUJO);
        }
        marcoImagen.getChildren().setAll(imagen);
    }

    /** Placa: franja de color del tablero arriba (sin país) y el número en grande. */
    private static Node crearPlaca(String numero) {
        Region franja = new Region();
        franja.getStyleClass().add("placa-franja");
        franja.setPrefHeight(6);
        franja.setMaxWidth(Double.MAX_VALUE);
        Label num = new Label(numero);
        num.getStyleClass().add("placa-numero");
        VBox placa = new VBox(franja, num);
        placa.setAlignment(Pos.CENTER);
        placa.getStyleClass().add("placa");
        placa.setMaxWidth(130);
        return placa;
    }

    /** Ícono de persona (cabeza + hombros) dentro de un círculo dorado. */
    private static Node crearIconoPropietario() {
        SVGPath persona = new SVGPath();
        persona.setContent("M12 12a5 5 0 1 0 0-10a5 5 0 0 0 0 10zm0 2c-5 0-9 2.5-9 6v2h18v-2c0-3.5-4-6-9-6z");
        persona.setFill(Color.WHITE);
        Circle fondo = new Circle(18);
        fondo.getStyleClass().add("icono-fondo");   // el color sale del CSS (dorado)
        return new StackPane(fondo, persona);
    }
}
