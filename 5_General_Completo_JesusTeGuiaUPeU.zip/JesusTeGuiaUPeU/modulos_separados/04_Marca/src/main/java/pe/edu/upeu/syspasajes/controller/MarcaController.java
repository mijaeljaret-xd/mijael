/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MarcaController.java                                         │
 * │ CAPA    : CONTROLLER (controla la pantalla)                            │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Une la pantalla (main_marca.fxml) con las reglas (los servicios):    │
 * │     · llena la tabla con las marcas                                    │
 * │     · Guardar / Modificar / Eliminar / Cancelar / Buscar               │
 * │     · al elegir una marca en la tabla muestra SUS VEHÍCULOS en         │
 * │       tarjetas: dibujo o foto, placa, ícono del propietario y          │
 * │       selector para cambiar el COLOR del vehículo                      │
 * │     · botón "+ Agregar vehículo" y botón "Quitar" de cada tarjeta      │
 * │     · muestra quién ingresó y el botón "Salir" (vuelve al ingreso)     │
 * │     · selector "Color del tablero" (solo colores básicos): cambia el   │
 * │       color de la cabecera,                                            │
 * │       la tabla y los botones (y lo recuerda)                           │
 * │   Cada variable con @FXML tiene el mismo nombre que el fx:id del FXML. │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import pe.edu.upeu.syspasajes.components.DialogoVehiculo;
import pe.edu.upeu.syspasajes.components.SelectorColor;
import pe.edu.upeu.syspasajes.model.ColorBasico;
import pe.edu.upeu.syspasajes.components.TarjetaVehiculo;
import pe.edu.upeu.syspasajes.model.Marca;
import pe.edu.upeu.syspasajes.model.Vehiculo;
import pe.edu.upeu.syspasajes.service.IMarcaService;
import pe.edu.upeu.syspasajes.service.IVehiculoService;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MarcaController implements TarjetaVehiculo.Acciones {

    // ───── PASO 1: los SERVICIOS llegan por el constructor (los pasa MarcaApp) ─────
    private final IMarcaService servicio;
    private final IVehiculoService vehiculoServicio;

    public MarcaController(IMarcaService servicio, IVehiculoService vehiculoServicio) {
        this.servicio = servicio;
        this.vehiculoServicio = vehiculoServicio;
    }

    // ───── PASO 2: los controles de la pantalla (@FXML = mismo nombre que el fx:id) ─────
    @FXML private BorderPane raiz;                 // la ventana completa (para el color del tablero)
    @FXML private HBox cajaTablero;                // aquí se pone el selector "Color del tablero"
    @FXML private Label lblUsuario;                // "👤 Ronaldo · ADMINISTRADOR"
    @FXML private TextField txtNombre;
    @FXML private ComboBox<String> cbxEstado;
    @FXML private TextField txtBuscar;
    @FXML private Button btnGuardar;
    @FXML private Label lblMensaje;
    @FXML private TableView<Marca> tabla;
    @FXML private TableColumn<Marca, Long> colId;
    @FXML private TableColumn<Marca, String> colNombre;
    @FXML private TableColumn<Marca, Integer> colVehiculos;
    @FXML private TableColumn<Marca, String> colEstado;
    @FXML private TableColumn<Marca, Void> colAcciones;
    @FXML private Label lblVehiculos;              // título "Vehículos de Toyota (2)"
    @FXML private FlowPane panelVehiculos;         // aquí van las tarjetas
    @FXML private Button btnAgregarVehiculo;       // "+ Agregar vehículo"

    private SelectorColor cpTablero;                  // selector de colores básicos del tablero
    private Runnable alSalir = () -> { };             // qué hacer al tocar "Salir" (lo define MarcaApp)
    private List<Marca> todas = new ArrayList<>();   // copia de las marcas (para filtrar rápido)
    private Long idEditando = null;                   // null = marca nueva · número = se está editando

    // ───── PASO 3: initialize() se ejecuta SOLO al abrir la pantalla ─────
    @FXML
    public void initialize() {
        cbxEstado.getItems().setAll("ACTIVO", "INACTIVO");
        cbxEstado.getSelectionModel().select("ACTIVO");

        // Cada columna lee un atributo con su getter: "nombre" → getNombre()
        colId.setCellValueFactory(new PropertyValueFactory<>("idMarca"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        // Columna calculada: cuántos vehículos tiene la marca
        colVehiculos.setCellValueFactory(c ->
                new ReadOnlyObjectWrapper<>(servicio.contarVehiculos(c.getValue().getIdMarca())));
        crearBotonesDeFila();

        // Al elegir una fila de la tabla → mostrar los vehículos de esa marca
        tabla.getSelectionModel().selectedItemProperty().addListener((obs, antes, marca) -> mostrarVehiculos(marca));

        // Buscar mientras se escribe
        txtBuscar.textProperty().addListener((obs, antes, ahora) -> filtrar());
        tabla.setPlaceholder(new Label("No hay marcas registradas"));

        // Color del tablero guardado (o el azul marino por defecto): selector con SOLO colores básicos
        String colorGuardado = vehiculoServicio.colorTablero();
        cpTablero = new SelectorColor(ColorBasico.paraTablero(), colorGuardado);
        cpTablero.setOnAction(e -> cambiarColorTablero());
        cajaTablero.getChildren().add(cpTablero);
        aplicarColorTablero(cpTablero.getHex());

        listar();
        if (!tabla.getItems().isEmpty()) tabla.getSelectionModel().selectFirst();   // muestra la 1.ª marca
    }

    // ───── PASO 4: LISTAR (pide las marcas al servicio y llena la tabla) ─────
    private void listar() {
        todas = servicio.listar();
        filtrar();
    }

    /** Muestra solo las marcas cuyo nombre contiene lo escrito en Buscar. */
    private void filtrar() {
        String f = txtBuscar.getText() == null ? "" : txtBuscar.getText().trim().toLowerCase();
        tabla.setItems(FXCollections.observableArrayList(todas.stream()
                .filter(m -> f.isEmpty() || m.getNombre().toLowerCase().contains(f))
                .toList()));
    }

    // ───── PASO 5: GUARDAR (botón Guardar / Actualizar · onAction="#guardar") ─────
    @FXML
    public void guardar() {
        // 5.1 Se arma un objeto Marca con lo escrito en el formulario
        Marca m = new Marca(idEditando, txtNombre.getText(), cbxEstado.getSelectionModel().getSelectedItem());
        try {
            // 5.2 El servicio aplica las reglas y guarda (o actualiza)
            if (idEditando == null) {
                servicio.guardar(m);
                mensaje("Marca " + m.getNombre() + " registrada correctamente", false);
            } else {
                servicio.actualizar(m);
                mensaje("Marca " + m.getNombre() + " actualizada correctamente", false);
            }
            // 5.3 Se limpia el formulario y se recarga la tabla
            limpiar();
            listar();
        } catch (RuntimeException ex) {
            // 5.4 Si una regla falla, se muestra el mensaje en rojo y NO se guarda nada
            mensaje(ex.getMessage(), true);
        }
    }

    // ───── PASO 6: MODIFICAR (botón de cada fila) → pasa los datos al formulario ─────
    private void editar(Marca m) {
        idEditando = m.getIdMarca();
        txtNombre.setText(m.getNombre());
        cbxEstado.getSelectionModel().select(m.getEstado());
        btnGuardar.setText("Actualizar");
        mensaje("Editando la marca " + m.getNombre(), false);
        txtNombre.requestFocus();
    }

    // ───── PASO 7: ELIMINAR (botón de cada fila) → confirma y elimina ─────
    private void eliminar(Marca m) {
        Alert pregunta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Eliminar la marca " + m.getNombre() + "?", ButtonType.OK, ButtonType.CANCEL);
        pregunta.setHeaderText(null);
        pregunta.setTitle("Confirmar");
        if (pregunta.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) return;
        try {
            servicio.eliminar(m.getIdMarca());
            if (m.getIdMarca().equals(idEditando)) limpiar();
            mensaje("Marca " + m.getNombre() + " eliminada", false);
            listar();
        } catch (RuntimeException ex) {
            mensaje(ex.getMessage(), true);   // por ejemplo: "La marca tiene 2 vehículo(s)…"
        }
    }

    // ───── PASO 8: LIMPIAR el formulario (botón Cancelar · onAction="#limpiar") ─────
    @FXML
    public void limpiar() {
        idEditando = null;
        txtNombre.clear();
        cbxEstado.getSelectionModel().select("ACTIVO");
        btnGuardar.setText("Guardar");
    }

    // ───── PASO 9: VEHÍCULOS de la marca elegida (tarjetas con dibujo, placa y propietario) ─────
    private void mostrarVehiculos(Marca marca) {
        panelVehiculos.getChildren().clear();
        btnAgregarVehiculo.setDisable(marca == null);
        if (marca == null) {
            lblVehiculos.setText("Elige una marca en la tabla para ver sus vehículos");
            return;
        }
        List<Vehiculo> lista = vehiculoServicio.listarPorMarca(marca.getIdMarca());
        lblVehiculos.setText("Vehículos de " + marca.getNombre() + " (" + lista.size() + ")");
        if (lista.isEmpty()) {
            panelVehiculos.getChildren().add(avisoSinVehiculos(marca));   // aviso + botón para agregar
        }
        for (Vehiculo v : lista) {
            panelVehiculos.getChildren().add(new TarjetaVehiculo(v, this));   // "this" recibe los clics de la tarjeta
        }
    }

    /** Tarjeta gris que aparece cuando la marca no tiene vehículos (por ejemplo, Kia). */
    private VBox avisoSinVehiculos(Marca marca) {
        Label titulo = new Label("Todavía no hay vehículos de " + marca.getNombre());
        titulo.getStyleClass().add("propietario");
        Label ayuda = new Label("Toca «+ Agregar vehículo» para registrar uno con su placa, propietario y color.");
        ayuda.getStyleClass().add("dato");
        ayuda.setWrapText(true);
        Button agregar = new Button("+ Agregar vehículo");
        agregar.getStyleClass().add("btn-principal");
        agregar.setOnAction(e -> agregarVehiculo());
        VBox caja = new VBox(8, pe.edu.upeu.syspasajes.components.DibujoVehiculo.crear("AUTO", Color.web("#D3DDEF"), 160),
                titulo, ayuda, agregar);
        caja.setAlignment(Pos.CENTER);
        caja.setPrefWidth(320);
        caja.getStyleClass().add("aviso-vacio");
        return caja;
    }

    // ───── PASO 9b: AGREGAR un vehículo a la marca elegida (botón · onAction="#agregarVehiculo") ─────
    @FXML
    public void agregarVehiculo() {
        Marca marca = tabla.getSelectionModel().getSelectedItem();
        if (marca == null) {
            mensaje("Primero elige una marca en la tabla", true);
            return;
        }
        boolean guardado = DialogoVehiculo.abrir(tabla.getScene().getWindow(), marca, vehiculoServicio::agregar);
        if (guardado) {
            mensaje("Vehículo agregado a " + marca.getNombre(), false);
            tabla.refresh();               // actualiza la columna "Vehículos"
            mostrarVehiculos(marca);
        }
    }

    // ───── PASO 10: lo que piden las tarjetas (interfaz TarjetaVehiculo.Acciones) ─────
    @Override
    public void cambiarColor(Vehiculo v, Color nuevo) {
        try {
            vehiculoServicio.cambiarColor(v, aHex(nuevo));
            mensaje("Color de " + v.getPlaca() + ": " + ColorBasico.masCercano(aHex(nuevo), ColorBasico.paraVehiculo()).getNombre(), false);
        } catch (RuntimeException ex) {
            mensaje(ex.getMessage(), true);
        }
    }

    @Override
    public void elegirFoto(Vehiculo v) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Foto del vehículo " + v.getPlaca());
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        File f = fc.showOpenDialog(tabla.getScene().getWindow());
        if (f == null) return;                                       // canceló
        try {
            vehiculoServicio.cambiarFoto(v, f.getAbsolutePath());
            mensaje("Foto de " + v.getPlaca() + " actualizada", false);
        } catch (RuntimeException ex) {
            mensaje(ex.getMessage(), true);
        }
    }

    @Override
    public void eliminarVehiculo(Vehiculo v) {
        Alert pregunta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Quitar el vehículo " + v.getPlaca() + " de " + v.getPropietario() + "?", ButtonType.OK, ButtonType.CANCEL);
        pregunta.setHeaderText(null);
        pregunta.setTitle("Confirmar");
        if (pregunta.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) return;
        vehiculoServicio.eliminar(v);
        mensaje("Vehículo " + v.getPlaca() + " quitado", false);
        tabla.refresh();
        mostrarVehiculos(tabla.getSelectionModel().getSelectedItem());
    }

    @Override
    public void quitarFoto(Vehiculo v) {
        vehiculoServicio.cambiarFoto(v, null);
        mensaje("Se volvió a mostrar el dibujo de " + v.getPlaca(), false);
    }

    // ───── PASO 11: COLOR DEL TABLERO ─────
    /** Selector de la cabecera (onAction="#cambiarColorTablero"). */
    public void cambiarColorTablero() {
        String hex = cpTablero.getHex();
        vehiculoServicio.guardarColorTablero(hex);   // se recuerda para la próxima vez
        aplicarColorTablero(hex);
        mensaje("Color del tablero: " + cpTablero.getValue().getNombre(), false);
    }

    /** Botón "Restablecer" (onAction="#restablecerTablero"): vuelve al azul marino original. */
    @FXML
    public void restablecerTablero() {
        cpTablero.setValue(ColorBasico.AZUL_MARINO);   // dispara cambiarColorTablero()
    }

    // ───── PASO 12: SESIÓN (quién ingresó) ─────
    /** MarcaApp lo llama después del ingreso: muestra el usuario y guarda qué hacer al salir. */
    public void setSesion(String nombre, String perfil, Runnable alSalir) {
        lblUsuario.setText("👤 " + nombre + " · " + perfil);
        this.alSalir = alSalir;
    }

    /** Botón "Salir" (onAction="#salir"): vuelve a la pantalla de ingreso. */
    @FXML
    public void salir() {
        alSalir.run();
    }

    /**
     * El CSS usa la variable "-color-tablero" en la cabecera, la tabla y los botones.
     * Al poner el estilo en la raíz, TODOS esos lugares cambian de color a la vez.
     */
    private void aplicarColorTablero(String hex) {
        raiz.setStyle("-color-tablero: " + hex + ";");
    }

    // ───── Ayudantes ─────
    /** Color de JavaFX → texto "#RRGGBB". */
    private static String aHex(Color c) {
        return String.format("#%02X%02X%02X",
                (int) Math.round(c.getRed() * 255), (int) Math.round(c.getGreen() * 255), (int) Math.round(c.getBlue() * 255));
    }

    /** Crea en la última columna los botones "Modificar" y "Eliminar" de cada fila. */
    private void crearBotonesDeFila() {
        colAcciones.setCellFactory(col -> new TableCell<>() {
            private final Button btnEditar = new Button("Modificar");
            private final Button btnBorrar = new Button("Eliminar");
            private final HBox caja = new HBox(6, btnEditar, btnBorrar);
            {
                btnEditar.getStyleClass().add("btn-fila");
                btnBorrar.getStyleClass().add("btn-fila-peligro");
                btnEditar.setOnAction(e -> editar(getTableView().getItems().get(getIndex())));
                btnBorrar.setOnAction(e -> eliminar(getTableView().getItems().get(getIndex())));
            }
            @Override
            protected void updateItem(Void item, boolean vacio) {
                super.updateItem(item, vacio);
                setGraphic(vacio ? null : caja);
            }
        });
    }

    /** Mensaje bajo el formulario: azul si salió bien, rojo si hubo error. */
    private void mensaje(String texto, boolean esError) {
        lblMensaje.setText(texto);
        lblMensaje.getStyleClass().removeAll("msg-ok", "msg-error");
        lblMensaje.getStyleClass().add(esError ? "msg-error" : "msg-ok");
    }
}
