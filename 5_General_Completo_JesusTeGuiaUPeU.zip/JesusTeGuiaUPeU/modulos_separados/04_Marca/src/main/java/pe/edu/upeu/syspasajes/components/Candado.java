/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Candado.java                                                 │
 * │ CAPA    : COMPONENTES visuales                                         │
 * │ MÓDULO  : INGRESO (login)                                              │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Dibuja un CANDADO con figuras de JavaFX y lo ANIMA solo:             │
 * │     cerrarAuto() → al abrir la ventana el candado baja y se cierra     │
 * │                    con un "clic" (rebote).                             │
 * │     abrir(...)   → contraseña correcta: el arco sube y gira (abierto)  │
 * │                    y luego entra al sistema.                           │
 * │     sacudir()    → contraseña incorrecta: el candado tiembla en rojo.  │
 * │   ► Para cambiar sus colores edita AZUL / DORADO / ROJO de abajo.      │
 * │   ► Para cambiar el tamaño cambia ESCALA.                              │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Interpolator;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Candado extends Group {   // HERENCIA: el candado "es un" grupo de figuras

    // ───── PASO 1: colores y tamaño ─────
    private static final Color AZUL = Color.web("#0A2A66");
    private static final Color DORADO = Color.web("#D4A017");
    private static final Color ROJO = Color.web("#C62828");
    private static final Color VERDE = Color.web("#2E7D32");
    private static final double ESCALA = 1.6;
    private static final double ANGULO_ABIERTO = -20;   // cuánto gira el arco al abrirse

    // ───── PASO 2: las piezas ─────
    private final SVGPath arco = new SVGPath();                       // el "gancho" de arriba
    private final Rectangle cuerpo = new Rectangle(0, 30, 64, 50);   // la caja
    private final Circle ojo = new Circle(32, 50, 6);                // cerradura
    private final Rectangle ranura = new Rectangle(29, 52, 6, 14);
    private final Rotate giro = new Rotate(0, 12, 46);                // gira sobre la pata izquierda

    public Candado() {
        arco.setContent("M12,46 L12,22 A20,20 0 0 1 52,22 L52,46");
        arco.setFill(null);
        arco.setStroke(DORADO);
        arco.setStrokeWidth(8);
        arco.setStrokeLineCap(StrokeLineCap.ROUND);
        arco.getTransforms().add(giro);

        cuerpo.setArcWidth(14);
        cuerpo.setArcHeight(14);
        cuerpo.setFill(AZUL);
        cuerpo.setStroke(DORADO);
        cuerpo.setStrokeWidth(3);

        ojo.setFill(DORADO);
        ranura.setFill(DORADO);

        // Marco invisible: el tamaño del grupo no cambia mientras el arco se mueve (así no "salta")
        Rectangle marco = new Rectangle(-14, -30, 92, 114);
        marco.setFill(Color.TRANSPARENT);

        getChildren().addAll(marco, arco, cuerpo, ojo, ranura);
        setScaleX(ESCALA);
        setScaleY(ESCALA);
    }

    // ───── PASO 3: se cierra SOLO al mostrar la pantalla ─────
    public void cerrarAuto() {
        arco.setTranslateY(-14);   // empieza abierto (arco arriba)
        giro.setAngle(ANGULO_ABIERTO);
        new Timeline(
                new KeyFrame(Duration.millis(250),
                        new KeyValue(arco.translateYProperty(), -14), new KeyValue(giro.angleProperty(), ANGULO_ABIERTO)),
                new KeyFrame(Duration.millis(650),
                        new KeyValue(giro.angleProperty(), 0, Interpolator.EASE_OUT)),
                new KeyFrame(Duration.millis(900),
                        new KeyValue(arco.translateYProperty(), 2, Interpolator.EASE_IN)),     // baja con fuerza
                new KeyFrame(Duration.millis(1000),
                        new KeyValue(arco.translateYProperty(), 0, Interpolator.EASE_OUT))     // "clic"
        ).play();
    }

    // ───── PASO 4: se abre SOLO cuando la contraseña es correcta ─────
    /** @param alTerminar lo que se hace cuando termina de abrirse (entrar al sistema) */
    public void abrir(Runnable alTerminar) {
        cuerpo.setStroke(VERDE);
        ojo.setFill(VERDE);
        ranura.setFill(VERDE);
        Timeline t = new Timeline(
                new KeyFrame(Duration.ZERO,
                        new KeyValue(arco.translateYProperty(), 0), new KeyValue(giro.angleProperty(), 0)),
                new KeyFrame(Duration.millis(350),
                        new KeyValue(arco.translateYProperty(), -14, Interpolator.EASE_OUT)),   // sube
                new KeyFrame(Duration.millis(700),
                        new KeyValue(giro.angleProperty(), ANGULO_ABIERTO, Interpolator.EASE_OUT)), // gira
                new KeyFrame(Duration.millis(1000)));                                           // pausa
        t.setOnFinished(e -> alTerminar.run());
        t.play();
    }

    // ───── PASO 5: tiembla cuando hay error ─────
    public void sacudir() {
        cuerpo.setStroke(ROJO);
        TranslateTransition temblor = new TranslateTransition(Duration.millis(60), this);
        temblor.setFromX(-8);
        temblor.setToX(8);
        temblor.setCycleCount(6);
        temblor.setAutoReverse(true);
        temblor.setOnFinished(e -> {
            setTranslateX(0);
            cuerpo.setStroke(DORADO);
        });
        temblor.play();
    }
}
