/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ColorBasico.java                                             │
 * │ CAPA    : MODEL (enumeración)                                          │
 * │ MÓDULO  : MARCA (colores permitidos)                                   │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Lista FIJA de colores básicos (los más usados en Perú).              │
 * │   Los selectores de color solo muestran estos colores:                 │
 * │     · paraVehiculo() → colores de carrocería más comunes en los autos  │
 * │       y combis del Perú (blanco, plata, negro, rojo, amarillo taxi…)   │
 * │     · paraTablero()  → colores oscuros para la cabecera y la tabla     │
 * │       (con letras blancas encima se leen bien)                         │
 * │   ► Para agregar un color: añade una línea  NOMBRE("Texto", "#RRGGBB", │
 * │     usoVehiculo, usoTablero)  y aparece solo en los selectores.        │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public enum ColorBasico {

    //            nombre visible      código     ¿vehículo?  ¿tablero?
    BLANCO       ("Blanco",           "#F5F5F5", true,  false),
    PLATA        ("Plata",            "#C0C0C0", true,  false),
    GRIS         ("Gris",             "#707070", true,  true),
    NEGRO        ("Negro",            "#1C1C1C", true,  true),
    ROJO         ("Rojo",             "#C62828", true,  true),
    AZUL         ("Azul",             "#1553C7", true,  true),
    AZUL_MARINO  ("Azul marino",      "#0A2A66", true,  true),   // color del proyecto (por defecto)
    VERDE        ("Verde",            "#2E7D32", true,  true),
    AMARILLO     ("Amarillo taxi",    "#F9C80E", true,  false),
    GUINDA       ("Guinda",           "#6D1A2B", true,  true);

    // ───── PASO 1: datos de cada color ─────
    private final String nombre;
    private final String hex;
    private final boolean vehiculo;
    private final boolean tablero;

    ColorBasico(String nombre, String hex, boolean vehiculo, boolean tablero) {
        this.nombre = nombre;
        this.hex = hex;
        this.vehiculo = vehiculo;
        this.tablero = tablero;
    }

    public String getNombre() { return nombre; }
    public String getHex() { return hex; }

    // ───── PASO 2: listas para cada selector ─────
    public static List<ColorBasico> paraVehiculo() {
        return Arrays.stream(values()).filter(c -> c.vehiculo).toList();
    }

    public static List<ColorBasico> paraTablero() {
        return Arrays.stream(values()).filter(c -> c.tablero).toList();
    }

    // ───── PASO 3: buscar el color de la lista más parecido a un código ─────
    /** Si en la base de datos hay un color que no está en la lista, se elige el más cercano. */
    public static ColorBasico masCercano(String hex, List<ColorBasico> opciones) {
        int[] a = rgb(hex);
        return opciones.stream()
                .min(Comparator.comparingInt(c -> distancia(a, rgb(c.hex))))
                .orElse(AZUL_MARINO);
    }

    private static int[] rgb(String hex) {
        try {
            int v = Integer.parseInt(hex.replace("#", ""), 16);
            return new int[]{(v >> 16) & 255, (v >> 8) & 255, v & 255};
        } catch (RuntimeException e) {
            return new int[]{10, 42, 102};   // si el código está mal, azul marino
        }
    }

    private static int distancia(int[] a, int[] b) {
        int r = a[0] - b[0], g = a[1] - b[1], bl = a[2] - b[2];
        return r * r + g * g + bl * bl;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
