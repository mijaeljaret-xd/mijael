/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IMarcaService.java                                           │
 * │ CAPA    : SERVICE (interfaz = "contrato")                              │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Dice QUÉ se puede hacer con las marcas, sin decir CÓMO.              │
 * │   El controlador solo conoce esta interfaz (bajo acoplamiento):        │
 * │   se podría cambiar la implementación sin tocar la pantalla.           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.model.Marca;

import java.util.List;
import java.util.Optional;

public interface IMarcaService {

    /** Todas las marcas ordenadas por nombre. */
    List<Marca> listar();

    /** Guarda una marca nueva (valida y revisa que el nombre no se repita). */
    Marca guardar(Marca marca);

    /** Cambia los datos de una marca existente. */
    Marca actualizar(Marca marca);

    /** Elimina una marca SOLO si ningún vehículo la usa. */
    void eliminar(Long idMarca);

    /** Busca por nombre sin importar mayúsculas. */
    Optional<Marca> buscarPorNombre(String nombre);

    /** Cuántos vehículos usan la marca. */
    int contarVehiculos(Long idMarca);
}
