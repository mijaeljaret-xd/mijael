/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Usuario.java                                                 │
 * │ CAPA    : MODEL                                                        │
 * │ MÓDULO  : INGRESO (login)                                              │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Persona que puede ingresar al sistema con usuario y contraseña.      │
 * │   La contraseña NO se guarda: se guarda su código cifrado (claveHash). │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

public class Usuario {

    private Long idUsuario;
    private String usuario;      // con lo que ingresa: "Ronaldo"
    private String nombre;       // nombre completo para mostrar
    private String claveHash;    // contraseña cifrada con SHA-256
    private String perfil;       // ADMINISTRADOR o TAXISTA

    public Usuario() {
    }

    public Usuario(Long idUsuario, String usuario, String nombre, String claveHash, String perfil) {
        this.idUsuario = idUsuario;
        this.usuario = usuario;
        this.nombre = nombre;
        this.claveHash = claveHash;
        this.perfil = perfil;
    }

    public Long getIdUsuario() { return idUsuario; }
    public String getUsuario() { return usuario; }
    public String getNombre() { return nombre; }
    public String getClaveHash() { return claveHash; }
    public String getPerfil() { return perfil; }
}
