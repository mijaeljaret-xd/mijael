/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : DialogoVehiculo.java                                         │
 * │ CAPA    : COMPONENTES visuales                                         │
 * │ MÓDULO  : MARCA (agregar un vehículo)                                  │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Ventana para AGREGAR un vehículo a la marca elegida:                 │
 * │   placa, modelo, tipo (auto/van), propietario, celular y color.        │
 * │   Mientras eliges el tipo o el color, la vista previa se redibuja.     │
 * │   Al tocar "Guardar" se llama a la función "guardar" que le pasa el    │
 * │   controlador; si una regla falla, el error se muestra en rojo y la    │
 * │   ventana NO se cierra (así no se pierde lo escrito).                  │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Window;
import pe.edu.upeu.syspasajes.model.ColorBasico;
import pe.edu.upeu.syspasajes.model.Marca;
import pe.edu.upeu.syspasajes.model.Vehiculo;

import java.util.function.Consumer;

public final class DialogoVehiculo {

    private DialogoVehiculo() {
    }

    /**
     * Abre la ventana.
     * @param marca    marca a la que pertenecerá el vehículo
     * @param guardar  función que guarda (lanza excepción con el mensaje si una regla falla)
     * @return true si se guardó
     */
    public static boolean abrir(Window dueño, Marca marca, Consumer<Vehiculo> guardar) {
        // ───── PASO 1: los campos ─────
        TextField txtPlaca = new TextField();
        txtPlaca.setPromptText("ABC-123");
        TextField txtModelo = new TextField();
        txtModelo.setPromptText("Yaris, Hiace…");
        ComboBox<String> cbxTipo = new ComboBox<>();
        cbxTipo.getItems().setAll("AUTO", "VAN");
        cbxTipo.getSelectionModel().select("AUTO");
        TextField txtPropietario = new TextField();
        txtPropietario.setPromptText("Nombre completo del dueño");
        TextField txtCelular = new TextField();
        txtCelular.setPromptText("9xxxxxxxx (opcional)");
        SelectorColor cpColor = new SelectorColor(ColorBasico.paraVehiculo(), ColorBasico.BLANCO.getHex());
        Label lblError = new Label();
        lblError.getStyleClass().add("msg-error");
        lblError.setWrapText(true);

        // ───── PASO 2: vista previa del dibujo (cambia con el tipo y el color) ─────
        StackPane vista = new StackPane();
        vista.getStyleClass().add("marco-imagen");
        vista.setPrefSize(220, 110);
        Runnable redibujar = () -> vista.getChildren().setAll(
                DibujoVehiculo.crear(cbxTipo.getValue(), Color.web(cpColor.getHex()), 200));
        cbxTipo.setOnAction(e -> redibujar.run());
        cpColor.setOnAction(e -> redibujar.run());
        redibujar.run();

        // ───── PASO 3: ordenar los campos en una cuadrícula ─────
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(8);
        grid.addRow(0, new Label("Placa *"), txtPlaca);
        grid.addRow(1, new Label("Modelo *"), txtModelo);
        grid.addRow(2, new Label("Tipo *"), cbxTipo);
        grid.addRow(3, new Label("Propietario *"), txtPropietario);
        grid.addRow(4, new Label("Celular"), txtCelular);
        grid.addRow(5, new Label("Color"), cpColor);
        VBox contenido = new VBox(12, vista, grid, lblError);
        contenido.setAlignment(Pos.TOP_CENTER);
        contenido.setPadding(new Insets(10));
        contenido.setPrefWidth(380);

        // ───── PASO 4: la ventana con los botones Guardar y Cancelar ─────
        Dialog<ButtonType> d = new Dialog<>();
        d.setTitle("Agregar vehículo");
        d.setHeaderText("Nuevo vehículo de la marca " + marca.getNombre());
        if (dueño != null) {
            d.initOwner(dueño);
            // usa los mismos colores (CSS) que la ventana principal
            d.getDialogPane().getStylesheets().addAll(dueño.getScene().getStylesheets());
            d.getDialogPane().setStyle(dueño.getScene().getRoot().getStyle());   // color del tablero actual
        }
        d.getDialogPane().getStyleClass().add("raiz");
        ButtonType btGuardar = new ButtonType("Guardar", ButtonBar.ButtonData.OK_DONE);
        d.getDialogPane().getButtonTypes().addAll(btGuardar, ButtonType.CANCEL);
        d.getDialogPane().setContent(contenido);
        Node botonGuardar = d.getDialogPane().lookupButton(btGuardar);
        botonGuardar.getStyleClass().add("btn-principal");

        // ───── PASO 5: al tocar Guardar → validar y guardar; si falla, NO cerrar ─────
        botonGuardar.addEventFilter(ActionEvent.ACTION, e -> {
            Vehiculo v = new Vehiculo(null, txtPlaca.getText(), marca.getIdMarca(), txtModelo.getText(),
                    cbxTipo.getValue(), txtPropietario.getText(), txtCelular.getText(),
                    cpColor.getHex(), null);
            try {
                guardar.accept(v);          // el controlador llama al servicio (aplica las reglas)
            } catch (RuntimeException ex) {
                lblError.setText(ex.getMessage());
                e.consume();                // consume = la ventana no se cierra
            }
        });
        return d.showAndWait().orElse(ButtonType.CANCEL) == btGuardar;
    }

}
