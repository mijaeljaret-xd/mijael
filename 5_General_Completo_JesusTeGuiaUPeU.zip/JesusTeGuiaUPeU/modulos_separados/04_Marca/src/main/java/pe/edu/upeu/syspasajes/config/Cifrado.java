/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Cifrado.java                                                 │
 * │ CAPA    : CONFIG (utilidad)                                            │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Convierte una contraseña en un código SHA-256 (64 letras/números).   │
 * │   En la base de datos se guarda ESE código, nunca la contraseña.       │
 * │   Al ingresar se cifra lo que escribió el usuario y se comparan los    │
 * │   dos códigos: si son iguales, la contraseña es correcta.              │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.config;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class Cifrado {

    private Cifrado() {
    }

    public static String sha256(String texto) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(texto.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));   // cada byte → 2 caracteres hex
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 no disponible", e);
        }
    }
}
