/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Launcher.java                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Ejecuta MarcaApp desde IntelliJ sin el error                         │
 * │   "faltan los componentes de JavaFX runtime".                          │
 * │   (Ese error sale cuando el main está en una clase que extiende        │
 * │    Application; este lanzador lo evita).                               │
 * │   ► Clic derecho en este archivo → Run 'Launcher.main()'.              │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes;

public class Launcher {
    public static void main(String[] args) {
        MarcaApp.main(args);
    }
}
