/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ConfigRepository.java                                        │
 * │ CAPA    : REPOSITORY (acceso a datos)                                  │
 * │ MÓDULO  : MARCA (ajustes de la pantalla)                               │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Guarda y lee ajustes con forma "clave = valor" en la tabla config.   │
 * │   Se usa para recordar el COLOR DEL TABLERO aunque cierres la app.     │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.config.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConfigRepository {

    // ───── PASO 1: LEER un ajuste (si no existe devuelve el valor por defecto) ─────
    public String leer(String clave, String porDefecto) {
        try (Connection cn = ConexionBD.abrir();
             PreparedStatement ps = cn.prepareStatement("SELECT valor FROM config WHERE clave = ?")) {
            ps.setString(1, clave);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : porDefecto;
            }
        } catch (SQLException e) {
            return porDefecto;
        }
    }

    // ───── PASO 2: GUARDAR un ajuste (MERGE = inserta o reemplaza) ─────
    public void guardar(String clave, String valor) {
        try (Connection cn = ConexionBD.abrir();
             PreparedStatement ps = cn.prepareStatement("MERGE INTO config (clave, valor) KEY (clave) VALUES (?, ?)")) {
            ps.setString(1, clave);
            ps.setString(2, valor);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("No se pudo guardar el ajuste: " + e.getMessage(), e);
        }
    }
}
