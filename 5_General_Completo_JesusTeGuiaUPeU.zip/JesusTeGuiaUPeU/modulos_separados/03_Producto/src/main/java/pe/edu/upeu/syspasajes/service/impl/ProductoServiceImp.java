/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ProductoServiceImp.java                                      │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : PRODUCTO                                                     │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Precio del pasaje según el producto y actualización de salidas       │
 * │   futuras.                                                             │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Producto;
import pe.edu.upeu.syspasajes.repository.ICrudGenericoRepository;
import pe.edu.upeu.syspasajes.repository.ProductoRepository;
import pe.edu.upeu.syspasajes.service.IProductoService;

import java.util.List;

public class ProductoServiceImp extends CrudGenericoServiceImp<Producto, Long> implements IProductoService {

    private final ProductoRepository productoRepository;

    public ProductoServiceImp(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    @Override
    protected ICrudGenericoRepository<Producto, Long> getRepo() {
        return productoRepository;
    }

    @Override
    public List<Producto> listarActivos() {
        return productoRepository.listarActivos();
    }

    @Override
    public double precioPara(TipoVehiculo tipo, Sentido sentido) {
        if (tipo == null) return 0.0;
        if (sentido == null) return tipo.getPrecioSugerido();
        return productoRepository.buscarTarifa(tipo, sentido)
                .map(Producto::getPrecio)
                .orElse(tipo.getPrecioSugerido());
    }

    @Override
    public int aplicarPrecioASalidasFuturas(Producto p) {
        if (p == null || !"ACTIVO".equals(p.getEstado())) return 0;
        return productoRepository.aplicarPrecioASalidasFuturas(p.getTipoVehiculo(), p.getSentido(), p.getPrecio());
    }
}
