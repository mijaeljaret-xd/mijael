/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : TipoVehiculo.java                                            │
 * │ CAPA    : Enumeración                                                  │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Flota: Auto de 5 asientos (4 pasajeros) y Van de 11 asientos         │
 * │   (10 pasajeros), con su precio sugerido.                              │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.enums;

import lombok.Getter;

/**
 * Tipos de vehículo de la flota.
 *  - TAXI  = Auto de 5 asientos  → se venden 4 (el 5.º es del conductor).
 *  - COMBI = Van  de 11 asientos → se venden 10 (el 11.º es del conductor).
 * ► Para vender 5 y 11 cambia el segundo número (asientos) por 5 y 11.
 */
@Getter
public enum TipoVehiculo {
    //     texto   asientos que se venden   precio   asientos totales
    TAXI("Auto", 4, 3.00, 5),
    COMBI("Van", 10, 1.50, 11);

    private final String descripcion;
    private final int asientos;
    private final double precioSugerido;
    private final int asientosTotales;

    TipoVehiculo(String descripcion, int asientos, double precioSugerido, int asientosTotales) {
        this.descripcion = descripcion;
        this.asientos = asientos;
        this.precioSugerido = precioSugerido;
        this.asientosTotales = asientosTotales;
    }

    @Override
    public String toString() {
        return descripcion + " (" + asientosTotales + " asientos: " + asientos + " pasajeros)";
    }
}
