/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ClienteController.java                                       │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : CLIENTE                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Pantalla Clientes: registrar, buscar, modificar y eliminar           │
 * │   clientes por DNI, con consulta a RENIEC.                             │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import pe.edu.upeu.syspasajes.components.ColumnInfo;
import pe.edu.upeu.syspasajes.components.TableViewHelper;
import pe.edu.upeu.syspasajes.components.Toast;
import pe.edu.upeu.syspasajes.components.ToltipCustom;
import pe.edu.upeu.syspasajes.dto.PersonaDto;
import pe.edu.upeu.syspasajes.enums.TipoDocumento;
import pe.edu.upeu.syspasajes.model.Cliente;
import pe.edu.upeu.syspasajes.service.IClienteService;
import pe.edu.upeu.syspasajes.utils.ConsultaDNI;

import java.util.*;
import java.util.function.Consumer;

/** MÓDULO CLIENTE - CRUD de clientes (se identifican con su DNI). */
public class ClienteController {

    private final IClienteService cs;
    private final ConsultaDNI cDni;

    @FXML TextField txtDni, txtNombres, txtTelefono, txtEmail, txtDireccion, txtFiltroDato;
    @FXML ComboBox<TipoDocumento> cbxTipoDoc;
    @FXML Button btnGuardar, btnReniec;
    @FXML Label lbnMsg, lblTotal;
    @FXML private TableView<Cliente> tableView;
    @FXML private AnchorPane miContenedor;

    private Validator validator;
    private final ToltipCustom ttc = new ToltipCustom();
    private List<Cliente> lista = new ArrayList<>();
    /** DNI del cliente que se está editando (null = nuevo). */
    private String dniCE = null;

    public ClienteController(IClienteService cs, ConsultaDNI cDni) {
        this.cs = cs;
        this.cDni = cDni;
    }

    @FXML
    public void initialize() {
        dniCE = null;
        validator = Validation.buildDefaultValidatorFactory().getValidator();
        cbxTipoDoc.getItems().setAll(TipoDocumento.values());
        cbxTipoDoc.getSelectionModel().select(TipoDocumento.DNI);
        txtFiltroDato.textProperty().addListener((o, a, n) -> filtrar());

        TableViewHelper<Cliente> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Documento", new ColumnInfo("dni", 95.0));
        columns.put("Tipo", new ColumnInfo("tipoDocumentoTexto", 70.0));
        columns.put("Nombres y apellidos", new ColumnInfo("nombres", 230.0));
        columns.put("Celular", new ColumnInfo("telefono", 95.0));
        columns.put("Correo", new ColumnInfo("email", 170.0));
        columns.put("Dirección", new ColumnInfo("direccion", 180.0));
        Consumer<Cliente> updateAction = this::editForm;
        Consumer<Cliente> deleteAction = c -> {
            if (!confirmar("¿Eliminar al cliente " + c.getNombres() + "?")) return;
            try {
                cs.delete(c.getDni());
                Toast.mostrar(stage(), "Cliente eliminado correctamente", Toast.EXITO);
                if (Objects.equals(dniCE, c.getDni())) clearForm();
            } catch (Exception ex) {
                Toast.mostrar(stage(), "No se puede eliminar: " + ex.getMessage(), Toast.ERROR);
            }
            listar();
        };
        helper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        tableView.setPlaceholder(new Label("No hay clientes registrados"));
        lbnMsg.setText("");
        listar();
    }

    public void listar() {
        lista = cs.findAll();
        filtrar();
    }

    private void filtrar() {
        String f = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        List<Cliente> filtrados = lista.stream()
                .filter(c -> f.isEmpty() || c.getDni().contains(f) || c.getNombres().toLowerCase().contains(f))
                .toList();
        tableView.setItems(FXCollections.observableArrayList(filtrados));
        lblTotal.setText(filtrados.size() + " cliente(s)");
    }

    /** Busca el DNI en RENIEC (en segundo plano) para llenar los nombres. */
    @FXML
    public void consultarReniec() {
        String dni = txt(txtDni);
        if (!dni.matches("\\d{8}")) {
            error(txtDni, "Escriba un DNI de 8 dígitos para consultar RENIEC");
            return;
        }
        Optional<Cliente> existe = cs.buscar(dni);
        if (existe.isPresent() && dniCE == null) {
            editForm(existe.get());
            Toast.mostrar(stage(), "El cliente ya está registrado. Puede modificar sus datos.", Toast.INFO);
            return;
        }
        btnReniec.setDisable(true);
        btnReniec.setText("Buscando...");
        Task<PersonaDto> tarea = new Task<>() {
            @Override
            protected PersonaDto call() {
                return cDni.consultarDNI(dni);
            }
        };
        tarea.setOnSucceeded(ev -> {
            restaurarBoton();
            PersonaDto p = tarea.getValue();
            if (p != null && p.getNombre() != null && !p.getNombre().isBlank()) {
                txtNombres.setText(p.getNombre() + " " + p.getApellidoPaterno() + " " + p.getApellidoMaterno());
                Toast.mostrar(stage(), "Datos encontrados en RENIEC", Toast.EXITO);
            } else {
                Toast.mostrar(stage(), "No se encontró en RENIEC. Escriba los nombres.", Toast.AVISO);
            }
        });
        tarea.setOnFailed(ev -> {
            restaurarBoton();
            Toast.mostrar(stage(), "Sin conexión con RENIEC. Escriba los nombres.", Toast.AVISO);
        });
        Thread hilo = new Thread(tarea, "consulta-dni-cliente");
        hilo.setDaemon(true);
        hilo.start();
    }

    private void restaurarBoton() {
        btnReniec.setDisable(false);
        btnReniec.setText("RENIEC");
    }

    @FXML
    public void validarFormulario() {
        limpiarError();
        String tel = txt(txtTelefono), email = txt(txtEmail), dir = txt(txtDireccion);
        Cliente formulario = Cliente.builder()
                .dni(txt(txtDni))
                .nombres(txt(txtNombres).toUpperCase())
                .telefono(tel.isEmpty() ? null : tel)
                .email(email.isEmpty() ? null : email)
                .direccion(dir.isEmpty() ? null : dir)
                .tipoDocumento(cbxTipoDoc.getSelectionModel().getSelectedItem())
                .build();
        List<ConstraintViolation<Cliente>> errores = new ArrayList<>(validator.validate(formulario));
        errores.sort(Comparator.comparing(v -> v.getPropertyPath().toString()));
        if (!errores.isEmpty()) {
            ConstraintViolation<Cliente> e = errores.get(0);
            Control c = switch (e.getPropertyPath().toString()) {
                case "nombres" -> txtNombres;
                case "telefono" -> txtTelefono;
                case "email" -> txtEmail;
                case "direccion" -> txtDireccion;
                case "tipoDocumento" -> cbxTipoDoc;
                default -> txtDni;
            };
            error(c, e.getMessage());
            return;
        }
        if (formulario.getTipoDocumento() == TipoDocumento.DNI && !formulario.getDni().matches("\\d{8}")) {
            error(txtDni, "El DNI debe tener exactamente 8 dígitos");
            return;
        }
        try {
            if (dniCE != null) {
                cs.update(dniCE, formulario);
                Toast.mostrar(stage(), "Cliente actualizado correctamente", Toast.EXITO);
            } else {
                if (cs.buscar(formulario.getDni()).isPresent()) {
                    error(txtDni, "Ya existe un cliente con el documento " + formulario.getDni());
                    return;
                }
                cs.save(formulario);
                Toast.mostrar(stage(), "Cliente registrado correctamente", Toast.EXITO);
            }
            clearForm();
            lbnMsg.setText("Formulario guardado");
            lbnMsg.setStyle("-fx-text-fill: #1553c7; -fx-font-size: 14px;");
            listar();
        } catch (Exception ex) {
            lbnMsg.setText("Error al guardar: " + ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
        }
    }

    public void editForm(Cliente c) {
        limpiarError();
        dniCE = c.getDni();
        txtDni.setText(c.getDni());
        txtDni.setEditable(false); // el DNI es la clave: no se cambia
        txtNombres.setText(c.getNombres());
        txtTelefono.setText(c.getTelefono() == null ? "" : c.getTelefono());
        txtEmail.setText(c.getEmail() == null ? "" : c.getEmail());
        txtDireccion.setText(c.getDireccion() == null ? "" : c.getDireccion());
        cbxTipoDoc.getSelectionModel().select(c.getTipoDocumento());
        btnGuardar.setText("Actualizar");
        lbnMsg.setText("Editando cliente " + c.getDni());
        lbnMsg.setStyle("-fx-text-fill: #1565c0; -fx-font-size: 14px;");
    }

    @FXML
    public void clearForm() {
        txtDni.clear();
        txtDni.setEditable(true);
        txtNombres.clear();
        txtTelefono.clear();
        txtEmail.clear();
        txtDireccion.clear();
        cbxTipoDoc.getSelectionModel().select(TipoDocumento.DNI);
        dniCE = null;
        btnGuardar.setText("Guardar");
        lbnMsg.setText("");
        limpiarError();
    }

    private void error(Control c, String msg) {
        ttc.marcarError(c, msg);
        lbnMsg.setText(msg);
        lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
        Platform.runLater(c::requestFocus);
    }

    private void limpiarError() {
        List.of(txtDni, txtNombres, txtTelefono, txtEmail, txtDireccion, cbxTipoDoc).forEach(ttc::limpiarCampo);
    }

    private String txt(TextField tf) {
        return tf.getText() == null ? "" : tf.getText().trim();
    }

    private boolean confirmar(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, mensaje, ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Confirmación");
        alert.setHeaderText(null);
        return alert.showAndWait().filter(b -> b == ButtonType.OK).isPresent();
    }

    private Stage stage() {
        return (Stage) miContenedor.getScene().getWindow();
    }
}
