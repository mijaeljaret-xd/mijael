/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IClienteService.java                                         │
 * │ CAPA    : Servicio (interfaz)                                          │
 * │ MÓDULO  : CLIENTE                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Qué se puede hacer con clientes: CRUD, autocompletado y búsqueda     │
 * │   por DNI.                                                             │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.dto.ModeloDataAutocomplet;
import pe.edu.upeu.syspasajes.model.Cliente;

import java.util.List;
import java.util.Optional;

/** MÓDULO CLIENTE - reglas de negocio. */
public interface IClienteService extends ICrudGenericoService<Cliente, String> {
    List<ModeloDataAutocomplet> listAutoCompletCliente();
    Optional<Cliente> buscar(String dni);
    int contarVentas(String dni);
}
