/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ConsultaDNI.java                                             │
 * │ CAPA    : Utilidad                                                     │
 * │ MÓDULO  : CLIENTE                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Consulta los nombres de un DNI en RENIEC para llenar el formulario   │
 * │   solo.                                                                │
 * │     1) API de Decolecta (RENIEC) con el token de application.properties│
 * │        (api.ruc.token: el mismo token sirve para DNI y RUC).           │
 * │     2) Si no hay token o falla: página eldni.com (plan B).             │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.utils;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import pe.edu.upeu.syspasajes.dto.PersonaDto;

import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConsultaDNI {

    // API de RENIEC (Decolecta). Se le agrega el DNI al final
    private static final String URL_API = "https://api.decolecta.com/v1/reniec/dni?numero=";

    private final String token = leerToken();
    private HttpClient http;

    public PersonaDto consultarDNI(String dni) {
        if (dni == null || !dni.matches("\\d{8}")) return new PersonaDto();
        PersonaDto api = consultarApi(dni);                    // 1) RENIEC por API
        if (api != null) return api;
        return consultarEldni(dni);                            // 2) plan B
    }

    /** RENIEC por la API de Decolecta: devuelve null si no hay token, internet o el DNI no existe. */
    private PersonaDto consultarApi(String dni) {
        if (token == null || token.isBlank()) return null;
        try {
            if (http == null) http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
            HttpRequest req = HttpRequest.newBuilder(URI.create(URL_API + dni))
                    .timeout(Duration.ofSeconds(10))
                    .header("Authorization", "Bearer " + token)
                    .header("Accept", "application/json")
                    .GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) return null;
            String nombres = campoJson(resp.body(), "first_name");
            if (nombres == null || nombres.isBlank()) return null;
            PersonaDto p = new PersonaDto();
            p.setDni(dni);
            p.setNombre(nombres);
            String pat = campoJson(resp.body(), "first_last_name");
            String mat = campoJson(resp.body(), "second_last_name");
            p.setApellidoPaterno(pat == null ? "" : pat);
            p.setApellidoMaterno(mat == null ? "" : mat);
            return p;
        } catch (Exception e) {
            return null;
        }
    }

    /** Plan B: página eldni.com (lee la tabla de resultados). */
    private PersonaDto consultarEldni(String dni) {
        PersonaDto personaDto = new PersonaDto();
        String url = "https://eldni.com/pe/buscar-datos-por-dni";
        try {
            // Primero: GET para obtener el _token del formulario
            Connection.Response getResponse = Jsoup.connect(url).method(Connection.Method.GET).execute();
            Document doc = getResponse.parse();
            String tk = doc.select("input[name=_token]").attr("value");
            // Luego: POST con el DNI y el token
            Connection.Response postResponse = Jsoup.connect(url)
                    .cookies(getResponse.cookies())
                    .data("_token", tk)
                    .data("dni", dni)
                    .method(Connection.Method.POST)
                    .ignoreContentType(true)
                    .execute();
            Element fila = Jsoup.parse(postResponse.body()).select("table tbody tr").first();
            if (fila != null) {
                Elements celdas = fila.select("td");
                personaDto.setDni(celdas.get(0).text());
                personaDto.setNombre(celdas.get(1).text());
                personaDto.setApellidoPaterno(celdas.get(2).text());
                personaDto.setApellidoMaterno(celdas.get(3).text());
            }
        } catch (Exception e) {
            // sin internet: se escriben los nombres a mano
        }
        return personaDto;
    }

    private static String campoJson(String json, String campo) {
        Matcher m = Pattern.compile("\"" + campo + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(json);
        return m.find() ? m.group(1).replace("\\\"", "\"").trim() : null;
    }

    private static String leerToken() {
        try (InputStream in = ConsultaDNI.class.getResourceAsStream("/application.properties")) {
            if (in == null) return "";
            Properties p = new Properties();
            p.load(in);
            return p.getProperty("api.ruc.token", "").trim();
        } catch (Exception e) {
            return "";
        }
    }

    public static void main(String[] args) {
        PersonaDto p = new ConsultaDNI().consultarDNI("43631919");
        System.out.println(p.getDni() + "  " + p.getNombre() + "  " + p.getApellidoPaterno());
    }
}
