/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ClienteServiceImp.java                                       │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : CLIENTE                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Reglas de clientes: no se elimina un cliente que ya tiene            │
 * │   comprobantes.                                                        │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.edu.upeu.syspasajes.dto.ModeloDataAutocomplet;
import pe.edu.upeu.syspasajes.model.Cliente;
import pe.edu.upeu.syspasajes.repository.ICrudGenericoRepository;
import pe.edu.upeu.syspasajes.repository.ClienteRepository;
import pe.edu.upeu.syspasajes.service.IClienteService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ClienteServiceImp extends CrudGenericoServiceImp<Cliente, String> implements IClienteService {

    private static final Logger logger = LoggerFactory.getLogger(ClienteServiceImp.class);
    private final ClienteRepository clienteRepository;

    public ClienteServiceImp(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    @Override
    protected ICrudGenericoRepository<Cliente, String> getRepo() {
        return clienteRepository;
    }

    @Override
    public List<ModeloDataAutocomplet> listAutoCompletCliente() {
        List<ModeloDataAutocomplet> lista = new ArrayList<>();
        try {
            for (Cliente p : clienteRepository.findAll()) {
                ModeloDataAutocomplet data = new ModeloDataAutocomplet();
                data.setIdx(p.getDni());
                data.setNameDysplay(p.getNombres());
                data.setOtherData(p.getTipoDocumento().name() + ";" + (p.getTelefono() == null ? "" : p.getTelefono()));
                lista.add(data);
            }
        } catch (Exception e) {
            logger.error("Error listando clientes", e);
        }
        return lista;
    }

    @Override
    public Optional<Cliente> buscar(String dni) {
        return clienteRepository.findById(dni);
    }

    @Override
    public int contarVentas(String dni) {
        return clienteRepository.contarVentas(dni);
    }

    /** No se elimina un cliente que ya tiene comprobantes emitidos. */
    @Override
    public void delete(String dni) {
        if (clienteRepository.contarVentas(dni) > 0) {
            throw new IllegalStateException("El cliente tiene ventas registradas y no se puede eliminar.");
        }
        super.delete(dni);
    }
}
