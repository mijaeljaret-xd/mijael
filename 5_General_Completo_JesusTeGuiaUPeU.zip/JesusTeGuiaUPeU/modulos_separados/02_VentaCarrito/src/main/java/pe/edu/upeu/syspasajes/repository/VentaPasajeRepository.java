/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VentaPasajeRepository.java                                   │
 * │ CAPA    : Repositorio (base de datos)                                  │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Guarda la venta completa en una sola transacción, numera B001/F001   │
 * │   y busca la razón social de un RUC.                                   │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.dto.VentaResumen;
import pe.edu.upeu.syspasajes.enums.MetodoPago;
import pe.edu.upeu.syspasajes.model.Boleto;
import pe.edu.upeu.syspasajes.model.VentaCarrito;
import pe.edu.upeu.syspasajes.model.Cliente;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.model.VentaPasaje;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class VentaPasajeRepository extends AbstractJpaRepository<VentaPasaje, Long> {

    @Override protected String getTableName() { return "venta_pasaje"; }
    @Override protected String getPkColumn()  { return "id_venta"; }

    private static final String SELECT_JOIN =
            "SELECT v.*, p.nombres, p.telefono, p.email, p.direccion, p.tipo_documento " +
            "FROM venta_pasaje v JOIN cliente p ON v.dni = p.dni ";

    @Override
    public List<VentaPasaje> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY v.id_venta DESC");
    }

    @Override
    public Optional<VentaPasaje> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE v.id_venta = ?", id);
    }

    @Override
    protected VentaPasaje mapRow(ResultSet rs) throws SQLException {
        Cliente p = ClienteRepository.mapCliente(rs);
        Usuario u = new Usuario();
        u.setIdUsuario(rs.getLong("id_usuario"));

        VentaPasaje v = new VentaPasaje();
        v.setId(rs.getLong("id_venta"));
        v.setPrecioBase(rs.getDouble("precio_base"));
        v.setIgv(rs.getDouble("igv"));
        v.setDescuento(rs.getDouble("descuento"));
        v.setPrecioTotal(rs.getDouble("precio_total"));
        v.setSerie(rs.getString("serie"));
        v.setNumDoc(rs.getString("num_doc"));
        v.setTipoDoc(rs.getString("tipo_doc"));
        v.setRuc(rs.getString("ruc"));
        v.setRazonSocial(rs.getString("razon_social"));
        v.setMetodoPago(MetodoPago.valueOf(rs.getString("metodo_pago")));
        v.setNroOperacion(rs.getString("nro_operacion"));
        v.setMontoRecibido(rs.getDouble("monto_recibido"));
        v.setVuelto(rs.getDouble("vuelto"));
        v.setFechaVenta(rs.getObject("fecha_venta", LocalDateTime.class));
        v.setCliente(p);
        v.setIdUsuario(u);
        return v;
    }

    @Override
    protected VentaPasaje insert(Connection conn, VentaPasaje e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO venta_pasaje(precio_base,igv,descuento,precio_total,serie,num_doc,tipo_doc,ruc,razon_social," +
                "metodo_pago,nro_operacion,monto_recibido,vuelto,fecha_venta,dni,id_usuario) " +
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                e.getPrecioBase(), e.getIgv(), e.getDescuento(), e.getPrecioTotal(),
                e.getSerie(), e.getNumDoc(), e.getTipoDoc(), e.getRuc(), e.getRazonSocial(),
                e.getMetodoPago().name(), e.getNroOperacion(), e.getMontoRecibido(), e.getVuelto(),
                e.getFechaVenta(), e.getCliente().getDni(), e.getIdUsuario().getIdUsuario());
        e.setId(id);
        return e;
    }

    @Override
    protected VentaPasaje updateRow(Connection conn, VentaPasaje e) throws SQLException {
        executeUpdate(conn,
                "UPDATE venta_pasaje SET precio_base=?,igv=?,descuento=?,precio_total=?,serie=?,num_doc=?,tipo_doc=?," +
                "ruc=?,razon_social=?,metodo_pago=?,nro_operacion=?,monto_recibido=?,vuelto=?," +
                "fecha_venta=?,dni=?,id_usuario=? WHERE id_venta=?",
                e.getPrecioBase(), e.getIgv(), e.getDescuento(), e.getPrecioTotal(),
                e.getSerie(), e.getNumDoc(), e.getTipoDoc(), e.getRuc(), e.getRazonSocial(),
                e.getMetodoPago().name(), e.getNroOperacion(), e.getMontoRecibido(), e.getVuelto(),
                e.getFechaVenta(), e.getCliente().getDni(), e.getIdUsuario().getIdUsuario(), e.getId());
        return e;
    }

    /** Razón social usada en la última factura emitida con ese RUC (para llenarla sola). */
    public Optional<String> ultimaRazonSocial(String ruc) {
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT razon_social FROM venta_pasaje WHERE ruc = ? AND razon_social IS NOT NULL ORDER BY id_venta DESC LIMIT 1")) {
            ps.setString(1, ruc);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.ofNullable(rs.getString(1)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error buscando la razón social", e);
        }
    }

    /** Siguiente número correlativo de la serie (B001 boletas, F001 facturas). */
    private String siguienteNumero(Connection conn, String serie) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT COALESCE(MAX(CAST(num_doc AS INTEGER)), 0) + 1 FROM venta_pasaje WHERE serie = ?")) {
            ps.setString(1, serie);
            try (ResultSet rs = ps.executeQuery()) {
                long n = rs.next() ? rs.getLong(1) : 1;
                return String.format("%08d", n);
            }
        }
    }

    /**
     * Registra la venta COMPLETA en una sola transacción:
     *  1) cabecera (venta_pasaje) con su número correlativo por serie (B001 / F001),
     *  2) un boleto por cada asiento del carrito,
     *  3) elimina esas reservas del carrito.
     * Si algo falla (por ejemplo, un asiento ya fue vendido) se hace rollback y no se guarda nada.
     */
    public VentaPasaje registrarVentaCompleta(VentaPasaje venta, List<VentaCarrito> items) {
        try (Connection conn = openConnection()) {
            conn.setAutoCommit(false);
            try {
                venta.setNumDoc(siguienteNumero(conn, venta.getSerie()));
                insert(conn, venta);

                List<Boleto> boletos = new ArrayList<>();
                for (VentaCarrito item : items) {
                    // La reserva debe seguir existiendo (pudo vencer mientras se cobraba)
                    int borrados;
                    try (PreparedStatement ps = conn.prepareStatement(
                            "DELETE FROM venta_carrito WHERE id_carrito = ?")) {
                        ps.setLong(1, item.getIdCarrito());
                        borrados = ps.executeUpdate();
                    }
                    if (borrados != 1) {
                        throw new SQLException("La reserva del asiento " + item.getNroAsiento()
                                + " ya venció. Vuelva a elegir el asiento.");
                    }
                    long idBoleto = executeInsertGetKey(conn,
                            "INSERT INTO boleto(id_venta,id_viaje,nro_asiento,precio) VALUES(?,?,?,?)",
                            venta.getId(), item.getViaje().getIdViaje(), item.getNroAsiento(), item.getPrecio());
                    boletos.add(Boleto.builder()
                            .idBoleto(idBoleto)
                            .venta(venta)
                            .viaje(item.getViaje())
                            .nroAsiento(item.getNroAsiento())
                            .precio(item.getPrecio())
                            .build());
                }
                conn.commit();
                venta.setBoletos(boletos);
                return venta;
            } catch (SQLException | RuntimeException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    /** Historial de ventas entre dos fechas (inclusive). */
    public List<VentaResumen> listarResumen(LocalDate desde, LocalDate hasta) {
        String sql = "SELECT v.id_venta, v.serie, v.num_doc, v.tipo_doc, v.metodo_pago, v.fecha_venta, v.dni, p.nombres, u.usuario, " +
                "v.descuento, v.precio_total, " +
                "(SELECT COUNT(*) FROM boleto b WHERE b.id_venta = v.id_venta) AS cantidad " +
                "FROM venta_pasaje v " +
                "JOIN cliente p ON v.dni = p.dni " +
                "JOIN usuario u ON v.id_usuario = u.id_usuario " +
                "WHERE v.fecha_venta >= ? AND v.fecha_venta < ? " +
                "ORDER BY v.id_venta DESC";
        List<VentaResumen> lista = new ArrayList<>();
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setObject(1, desde.atStartOfDay());
            ps.setObject(2, hasta.plusDays(1).atStartOfDay());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(VentaResumen.builder()
                            .idVenta(rs.getLong("id_venta"))
                            .comprobante(rs.getString("serie") + "-" + rs.getString("num_doc"))
                            .tipoComprobante(rs.getString("tipo_doc"))
                            .metodoPago(MetodoPago.valueOf(rs.getString("metodo_pago")).getDescripcion())
                            .fechaVenta(rs.getObject("fecha_venta", LocalDateTime.class))
                            .dni(rs.getString("dni"))
                            .cliente(rs.getString("nombres"))
                            .vendedor(rs.getString("usuario"))
                            .cantidadPasajes(rs.getInt("cantidad"))
                            .descuento(rs.getDouble("descuento"))
                            .total(rs.getDouble("precio_total"))
                            .build());
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error consultando el historial de ventas", e);
        }
        return lista;
    }
}
