/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VentaCarritoRepository.java                                  │
 * │ CAPA    : Repositorio (base de datos)                                  │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   SQL del carrito: reservar asientos, listar por DNI, vaciar y         │
 * │   borrar reservas vencidas.                                            │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.model.VentaCarrito;
import pe.edu.upeu.syspasajes.model.Usuario;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public class VentaCarritoRepository extends AbstractJpaRepository<VentaCarrito, Long> {

    @Override protected String getTableName() { return "venta_carrito"; }
    @Override protected String getPkColumn()  { return "id_carrito"; }

    private static final String SELECT_JOIN =
            "SELECT c.id_carrito, c.dni, c.nro_asiento, c.precio, c.estado, c.id_usuario, c.fecha_reg, " +
            "cl.nombres AS cliente_nombres, " +
            ViajeRepository.VIAJE_COLS +
            "FROM venta_carrito c " +
            "JOIN viaje vi ON c.id_viaje = vi.id_viaje " +
            "LEFT JOIN cliente cl ON c.dni = cl.dni " +
            ViajeRepository.JOIN_VEHICULO;

    @Override
    public List<VentaCarrito> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY c.fecha_reg DESC, c.id_carrito");
    }

    @Override
    public Optional<VentaCarrito> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE c.id_carrito = ?", id);
    }

    @Override
    protected VentaCarrito mapRow(ResultSet rs) throws SQLException {
        Usuario u = new Usuario();
        u.setIdUsuario(rs.getLong("id_usuario"));
        return VentaCarrito.builder()
                .idCarrito(rs.getLong("id_carrito"))
                .dni(rs.getString("dni"))
                .nombreCliente(rs.getString("cliente_nombres"))
                .nroAsiento(rs.getInt("nro_asiento"))
                .precio(rs.getDouble("precio"))
                .estado(rs.getInt("estado"))
                .idUsuario(u)
                .fechaReg(rs.getObject("fecha_reg", LocalDateTime.class))
                .viaje(ViajeRepository.mapViaje(rs, false))
                .build();
    }

    @Override
    protected VentaCarrito insert(Connection conn, VentaCarrito e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO venta_carrito(dni,id_viaje,nro_asiento,precio,estado,id_usuario,fecha_reg) VALUES(?,?,?,?,?,?,?)",
                e.getDni(), e.getViaje().getIdViaje(), e.getNroAsiento(), e.getPrecio(), e.getEstado(),
                e.getIdUsuario().getIdUsuario(), e.getFechaReg());
        e.setIdCarrito(id);
        return e;
    }

    @Override
    protected VentaCarrito updateRow(Connection conn, VentaCarrito e) throws SQLException {
        executeUpdate(conn,
                "UPDATE venta_carrito SET dni=?,id_viaje=?,nro_asiento=?,precio=?,estado=?,fecha_reg=? WHERE id_carrito=?",
                e.getDni(), e.getViaje().getIdViaje(), e.getNroAsiento(), e.getPrecio(), e.getEstado(),
                e.getFechaReg(), e.getIdCarrito());
        return e;
    }

    public List<VentaCarrito> listaCarritoCliente(String dni) {
        return executeQuery(SELECT_JOIN + "WHERE c.dni = ? ORDER BY vi.fecha, vi.hora_salida, c.nro_asiento", dni);
    }

    public void deleteByDni(String dni) {
        executeUpdateStandalone("DELETE FROM venta_carrito WHERE dni = ?", dni);
    }

    /** Libera las reservas que superaron el tiempo límite. Devuelve cuántas se borraron. */
    public int liberarReservasVencidas(LocalDateTime limite) {
        return executeUpdateStandalone("DELETE FROM venta_carrito WHERE fecha_reg < ?", limite);
    }
}
