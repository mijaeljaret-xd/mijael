/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IVentaPasajeService.java                                     │
 * │ CAPA    : Servicio (interfaz)                                          │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Registrar la venta (boleta o factura), validar RUC, generar RUC 10   │
 * │   y el texto del comprobante.                                          │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.dto.DatosPago;
import pe.edu.upeu.syspasajes.dto.VentaResumen;
import pe.edu.upeu.syspasajes.model.Boleto;
import pe.edu.upeu.syspasajes.model.VentaPasaje;

import java.time.LocalDate;
import java.util.List;

public interface IVentaPasajeService extends ICrudGenericoService<VentaPasaje, Long> {
    double TASA_IGV = 0.18;

    /** Convierte el carrito del cliente en una venta (boleta o factura) con sus boletos (transacción). */
    VentaPasaje registrarVenta(String dni, Long idUsuario, double descuento, DatosPago pago);
    List<VentaResumen> listarResumen(LocalDate desde, LocalDate hasta);
    List<Boleto> listarBoletos(Long idVenta);
    /** RUC 10 de persona natural que corresponde a un DNI ("10" + DNI + dígito verificador). */
    String rucDeDni(String dni);
    /** true si el RUC tiene 11 dígitos, empieza en 10/15/17/20 y su dígito verificador (módulo 11) cuadra. */
    boolean rucValido(String ruc);
    /** Razón social conocida para un RUC: el cliente dueño del RUC 10 o la empresa de una factura anterior. */
    java.util.Optional<String> buscarRazonSocial(String ruc);
    /** Texto imprimible del comprobante (boleta o factura). */
    String generarTextoBoleta(VentaPasaje venta);
}
