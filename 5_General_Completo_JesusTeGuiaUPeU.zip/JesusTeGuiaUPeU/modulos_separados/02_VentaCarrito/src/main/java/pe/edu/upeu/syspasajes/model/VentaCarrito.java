/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VentaCarrito.java                                            │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Asiento reservado en el carrito antes de pagar (dura 15 minutos).    │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/** MÓDULO VENTA CARRITO: asiento reservado en el carrito antes de pagar (dura 15 minutos). */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VentaCarrito {
    private Long idCarrito;
    private String dni;
    /** Nombre del cliente (dato de consulta con JOIN, no es columna). */
    private String nombreCliente;
    private Viaje viaje;
    private Integer nroAsiento;
    private Double precio;
    private int estado;
    private Usuario idUsuario;
    private LocalDateTime fechaReg;

    public String getRutaTexto() {
        return viaje == null ? "" : viaje.getRutaTexto();
    }

    public String getSalidaTexto() {
        return viaje == null ? "" : viaje.getFechaTexto() + " " + viaje.getHoraTexto();
    }

    public String getVehiculoTexto() {
        return viaje == null ? "" : viaje.getTipoTexto() + " " + viaje.getPlaca();
    }

    public String getReservadoTexto() {
        return fechaReg == null ? "" : fechaReg.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM HH:mm"));
    }

    /** Minutos que le quedan a la reserva antes de liberarse sola. */
    public long getMinutosRestantes() {
        if (fechaReg == null) return 0;
        long usados = java.time.Duration.between(fechaReg, LocalDateTime.now()).toMinutes();
        return Math.max(0, 15 - usados);
    }

    public String getPrecioTexto() {
        return String.format("S/ %.2f", precio == null ? 0.0 : precio);
    }
}
