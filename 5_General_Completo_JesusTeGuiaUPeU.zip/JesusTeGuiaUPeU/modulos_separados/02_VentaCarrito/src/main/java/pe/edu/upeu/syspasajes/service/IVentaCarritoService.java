/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IVentaCarritoService.java                                    │
 * │ CAPA    : Servicio (interfaz)                                          │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Reservar asientos 15 minutos, listar y vaciar el carrito.            │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.model.VentaCarrito;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.model.Viaje;

import java.util.Collection;
import java.util.List;

public interface IVentaCarritoService extends ICrudGenericoService<VentaCarrito, Long> {
    /** Minutos que dura la reserva de un asiento en el carrito. */
    int MINUTOS_RESERVA = 15;

    List<VentaCarrito> listaCarritoCliente(String dni);
    void deleteCarAll(String dni);
    /** Reserva los asientos y devuelve los que NO se pudieron reservar (ya ocupados). */
    List<Integer> reservarAsientos(String dni, Viaje viaje, Collection<Integer> asientos, Usuario usuario);
    int liberarReservasVencidas();
}
