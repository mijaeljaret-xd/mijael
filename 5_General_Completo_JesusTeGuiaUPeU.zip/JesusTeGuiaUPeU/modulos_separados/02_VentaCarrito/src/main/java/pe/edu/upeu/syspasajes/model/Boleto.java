/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Boleto.java                                                  │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : Venta                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Detalle de la venta: un boleto por cada asiento vendido.             │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/** Detalle de la venta: un boleto por cada asiento vendido. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Boleto {
    private Long idBoleto;
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private VentaPasaje venta;
    private Viaje viaje;
    private Integer nroAsiento;
    private Double precio;

    public String getRutaTexto() {
        return viaje == null ? "" : viaje.getRutaTexto();
    }

    public String getSalidaTexto() {
        return viaje == null ? "" : viaje.getFechaTexto() + " " + viaje.getHoraTexto();
    }

    public String getVehiculoTexto() {
        return viaje == null ? "" : viaje.getTipoTexto() + " " + viaje.getPlaca();
    }

    public String getPrecioTexto() {
        return String.format("S/ %.2f", precio == null ? 0.0 : precio);
    }
}
