/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : DialogoComprobante.java                                      │
 * │ CAPA    : Componente visual                                            │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Ventana que muestra la BOLETA o FACTURA con tres botones:            │
 * │     · Imprimir   → abre el diálogo de impresión (impresora o PDF).     │
 * │     · WhatsApp   → manda la reserva al celular del taxista.            │
 * │     · Copiar     → copia el texto del comprobante.                     │
 * │   La usan: Vender pasaje, Panel del cliente e Historial.               │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.geometry.Insets;
import javafx.print.PageLayout;
import javafx.print.PrinterJob;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.stage.Window;
import pe.edu.upeu.syspasajes.model.VentaPasaje;
import pe.edu.upeu.syspasajes.utils.AvisoTaxista;

public final class DialogoComprobante {

    // Colores del sistema: azul, blanco y dorado
    private static final String AZUL = "#1553C7", AZUL_OSCURO = "#0A2A66", DORADO = "#D4A017";

    private DialogoComprobante() {
    }

    /**
     * Muestra el comprobante.
     * @param venta      venta con sus boletos cargados
     * @param texto      texto de la boleta/factura (IVentaPasajeService.generarTextoBoleta)
     * @param titulo     título de la ventana
     * @param cabecera   texto grande de arriba
     * @param owner      ventana dueña (puede ser null)
     */
    public static void mostrar(VentaPasaje venta, String texto, String titulo, String cabecera, Window owner) {
        TextArea area = new TextArea(texto);
        area.setEditable(false);
        area.setFont(Font.font("Monospaced", 13));
        area.setPrefSize(490, 420);

        Button btnImprimir = boton("🖨  Imprimir " + (venta.esFactura() ? "factura" : "boleta"), AZUL, "white");
        btnImprimir.setOnAction(e -> imprimir(texto, owner));

        Button btnCopiar = boton("Copiar texto", "white", AZUL_OSCURO);
        btnCopiar.setOnAction(e -> {
            ClipboardContent c = new ClipboardContent();
            c.putString(texto);
            Clipboard.getSystemClipboard().setContent(c);
            btnCopiar.setText("✓ Copiado");
        });

        FlowPane acciones = new FlowPane(8, 8, btnImprimir, btnCopiar);

        // ---- Aviso de reserva para cada taxista de la venta ----
        FlowPane avisos = new FlowPane(8, 8);
        for (AvisoTaxista.Aviso a : AvisoTaxista.avisosDe(venta)) {
            if (a.telefono() == null || a.telefono().isBlank()) continue;
            String nombre = a.conductor().split("\\s+")[0];
            Button b = boton("WhatsApp a " + nombre + " (" + a.placa() + ")", DORADO, AZUL_OSCURO);
            b.setOnAction(e -> {
                if (!AvisoTaxista.abrirWhatsApp(a)) {
                    ClipboardContent c = new ClipboardContent();
                    c.putString(a.mensaje());
                    Clipboard.getSystemClipboard().setContent(c);
                    b.setText("Mensaje copiado: péguelo en WhatsApp");
                }
            });
            avisos.getChildren().add(b);
        }

        VBox contenido = new VBox(10, acciones, area);
        if (!avisos.getChildren().isEmpty()) {
            Label lbl = new Label("Aviso de reserva al taxista (queda guardado y se puede enviar a su celular):");
            lbl.setStyle("-fx-text-fill: " + AZUL_OSCURO + "; -fx-font-weight: bold;");
            contenido.getChildren().addAll(lbl, avisos);
        }
        contenido.setPadding(new Insets(4));

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(cabecera);
        alert.getDialogPane().setContent(contenido);
        alert.getDialogPane().setStyle("-fx-background-color: white; -fx-border-color: " + DORADO + "; -fx-border-width: 3 0 0 0;");
        alert.setResizable(true);
        if (owner != null) alert.initOwner(owner);
        alert.showAndWait();
    }

    /** Imprime el comprobante en la impresora elegida (ticketera, impresora normal o "Microsoft Print to PDF"). */
    public static boolean imprimir(String texto, Window owner) {
        PrinterJob job = PrinterJob.createPrinterJob();
        if (job == null) {
            new Alert(Alert.AlertType.WARNING, "No se encontró ninguna impresora instalada.").showAndWait();
            return false;
        }
        if (!job.showPrintDialog(owner)) return false;          // el usuario canceló
        Text hoja = new Text(texto);
        hoja.setFont(Font.font("Monospaced", 10));
        PageLayout pl = job.getJobSettings().getPageLayout();
        double ancho = hoja.getLayoutBounds().getWidth();
        if (ancho > pl.getPrintableWidth()) {                  // se achica para que entre en tickets de 58/80 mm
            double s = pl.getPrintableWidth() / ancho;
            hoja.getTransforms().add(new Scale(s, s));
        }
        boolean ok = job.printPage(hoja);
        if (ok) job.endJob();
        return ok;
    }

    private static Button boton(String texto, String fondo, String letra) {
        Button b = new Button(texto);
        b.setStyle("-fx-background-color: " + fondo + "; -fx-text-fill: " + letra + "; -fx-font-weight: bold;"
                + "-fx-background-radius: 6; -fx-border-color: " + AZUL + "; -fx-border-radius: 6; -fx-padding: 7 12; -fx-cursor: hand;");
        return b;
    }
}
